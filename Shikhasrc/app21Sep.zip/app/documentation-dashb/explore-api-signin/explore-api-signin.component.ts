import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-explore-api-signin',
  templateUrl: './explore-api-signin.component.html',
  styleUrls: ['./explore-api-signin.component.css']
})
export class ExploreApiSigninComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
