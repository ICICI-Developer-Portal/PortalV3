import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-production-onboarding',
  templateUrl: './production-onboarding.component.html',
  // styleUrls: ['./production-onboarding.component.css']
})
export class ProductionOnboardingComponent implements OnInit {

  constructor(private router:Router) {
  }

  ngOnInit() {
  }

}
