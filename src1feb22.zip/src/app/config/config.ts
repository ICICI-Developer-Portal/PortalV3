export class Config {
	 //public apiUrl = 'http://localhost:8080/rest/';
//   public apiUrl = 'https://developer.icicibank.com/rest/';
	 public apiUrl = 'http://10.78.25.173:8080/rest/';
	 
	  public UAT_apiUrl ='https://developer.icicibank.com/ROOT_UAT/rest/';

	  public allowedIdForApiList= ["461738","469904","474221","231240","BAN255139","BAN255141","BAN255142"];
}