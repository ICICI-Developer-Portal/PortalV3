import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Toast, ToasterService } from 'angular2-toaster';
import { DataTableResource } from 'angular7-data-table';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { Config } from '../config/config';
import { DashboardService } from 'src/app/services';
@Component({
  selector: 'app-api-detail-dashboard',
  templateUrl: './api-detail-dashboard.component.html',
  styleUrls: ['./api-detail-dashboard.component.css']
})
export class ApiDetailDashboardComponent implements OnInit {

  ApiDetailsData:[];
  totalCount:any;
  allowedId:any=[];
  constructor(
    private router: Router,
    private dashboardService: DashboardService,
    private HttpClient: HttpClient,
    private config: Config,
  ) { 
    this.allowedId = config.allowedIdForApiList;
  }

  ngOnInit() {
    let userId= localStorage.getItem("username");
    if(this.allowedId.includes(userId)){
        console.log("allowed");
    }else{
      console.log("Not allowed");
    }
     this.dashboardService.getApiDetailList().subscribe((data: any) => {
     console.log(data)
      let obj = JSON.parse(data._body);
      this.totalCount = obj.apiCount;
      this.ApiDetailsData = obj.apiData;
       //  console.log(treeData );
     
    },
      err => {
        console.log('err', err);
        //this.router.navigate(['error']);
        //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      }); 
  }
  downloadFile() {
    
     this.dashboardService.getApiDetailFileDownload().subscribe((data: any) => {
     console.log(data);
     console.log(data._body);
     let obj = data._body;
     // this.ApiDetailsData = JSON.parse(data._body);
       //  console.log(treeData );
       this.downloadCSV(obj,"ApiDetailFile");
     
    },
      err => {
        console.log('err', err);
        //this.router.navigate(['error']);
        //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      }); 
  }
  downloadCSV(csvData, fileName) {
    var localblob = new Blob([csvData], { type: "text/csv" });
    let dwldLink = document.createElement("a");
    let url = window.URL.createObjectURL(localblob);
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", url);
    dwldLink.setAttribute("download", fileName + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }
}

