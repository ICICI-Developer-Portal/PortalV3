import { Injectable } from "@angular/core";
import {
  Http,
  Headers,
  RequestOptions,
  Response,
  RequestMethod
} from "@angular/http";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
import { Config } from "../config/config";
import { Alert } from "selenium-webdriver";

import { Observable, fromEvent, merge, of, Subject, Subscription } from "rxjs";
import { timeout, catchError, map, mapTo } from "rxjs/operators";

@Injectable()
export class DashboardService {
  apiUrl: string;
  private user_id = new Subject<any>();
  private user_name = new Subject<any>();
  private environmentData = new Subject<any>();
  constructor(
    private http: Http,
    private config: Config,
    private HttpClient: HttpClient,
    private router: Router
  ) {
    this.apiUrl = config.apiUrl;
  }
 
  // getTreeData() {
  //   let headers = new Headers({
  //     "Content-Type": "application/x-www-form-urlencoded"
  //   });
  //   let options = new RequestOptions({ headers: headers });
  //   return this.http.get(
  //     "https://apigwuat.icicibank.com:8443/api/v0/GetTree?ID=0",
  //     options
  //   );
  // }
  //"https://developer.icicibank.com/ROOT_UAT/rest/getMenuTree?ID=0"
  getMenuTreeData() {
    return this.http.get(
      this.apiUrl+"getMenuTree?ID=0"
    );
  }
  getEnvironment(): Observable<any> {
    return this.environmentData.asObservable();
  }
  sendEnvironment(env: string) {
    this.environmentData.next(env);
  }
  getLastTabId(json) {
    var query = "";
    var key;
    for (key in json) {
      query +=
        encodeURIComponent(key) + "=" + encodeURIComponent(json[key]) + "&";
    }
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded"
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.apiUrl + "getLastTabId", query, options);
  }
  insertApiData(json) {
    
    let headers = new Headers({
      "Content-Type": "application/json",
      "username":localStorage.getItem("username"),
      "fullName": localStorage.getItem("Firstname"),
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.apiUrl + "createAPI", json, options);
  }
  insertBranchData(json) {
    
    let headers = new Headers({
      "Content-Type": "application/json",
      "username":localStorage.getItem("username"),
      "fullName": localStorage.getItem("Firstname"),
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.apiUrl + "createPMTreeBranch", json, options);
  }
  insertRootData(json) {
    
    let headers = new Headers({
      "Content-Type": "application/json",
      "username":localStorage.getItem("username"),
      "fullName": localStorage.getItem("Firstname"),
    });
    let options = new RequestOptions({ headers: headers });
    return this.http.post(this.apiUrl + "createPMTreeRoot", json, options);
  }
  getApiTransations() {
    
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded"

    });
    let options = new RequestOptions({ headers: headers });
      return this.http.post(this.apiUrl + "getApiTransations", options);
      
  }
  getDocFileDownload(json) {
    var query = "";
    var key;
    for (key in json) {
      query +=
        encodeURIComponent(key) + "=" + encodeURIComponent(json[key]) + "&";
    }
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded",
      "userName": localStorage.getItem("username"),
      "fullName": localStorage.getItem("Firstname"),
      "Token": localStorage.getItem("jwt")

    });
    let options = new RequestOptions({ headers: headers });
      return this.http.post(this.apiUrl + "getDocFileDownload",query, options);
      
  }
  getAPIResponsePacket(json) {
    var query = "";
    var key;
    for (key in json) {
      query +=
        encodeURIComponent(key) + "=" + encodeURIComponent(json[key]) + "&";
    }
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded"

    });
    let options = new RequestOptions({ headers: headers });
      return this.http.post(this.apiUrl + "getApiSampleResponse",query, options);
      
  }
  hasDBAdminAccess(json) {
    var query = "";
    var key;
    for (key in json) {
      query +=
        encodeURIComponent(key) + "=" + encodeURIComponent(json[key]) + "&";
    }
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded"

    });
    let options = new RequestOptions({ headers: headers });
      return this.http.post(this.apiUrl + "hasDBAdminAccess",query, options);
      
  }
  /* Api detail service ArunBala | 11thJan2022 */

  getApiDetailList() {
    var query = "";
    
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded"

    });
    let options = new RequestOptions({ headers: headers });
     return this.http.post("https://developer.icicibank.com/ROOTDIY/rest/" + "getListOfApiDetailInfo",query, options);
     // return this.http.post(this.apiUrl + "getListOfApiDetailInfo",query, options);
  }
  getApiDetailFileDownload() {
    var query = "";
    
    let headers = new Headers({
      "Content-Type": "application/x-www-form-urlencoded"

    });
    let options = new RequestOptions({ headers: headers });
     return this.http.post("https://developer.icicibank.com/ROOTDIY/rest/" + "getApiDetailFileDownload",query, options);
    //  return this.http.post(this.apiUrl + "getApiDetailFileDownload",query, options);
  }
}
