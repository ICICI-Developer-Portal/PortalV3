import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SandboxAPIsComponent } from './sandbox-apis.component';

describe('SandboxAPIsComponent', () => {
  let component: SandboxAPIsComponent;
  let fixture: ComponentFixture<SandboxAPIsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SandboxAPIsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SandboxAPIsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
