import { Component, OnInit } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import {

  HttpEventType,
  HttpErrorResponse
} from "@angular/common/http";
import { Http } from '@angular/http';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { LoginService } from '../services';



@Component({
  selector: 'app-sandbox-apis',
  templateUrl: './sandbox-apis.component.html',
  styleUrls: ['./sandbox-apis.component.css']
})
export class SandboxApisComponent implements OnInit {

  data:any = []
  constructor(private HttpClient: HttpClient,
    private http2: HttpClient,
    private adm: LoginService,
    private spinnerService: Ng4LoadingSpinnerService,
    private http: Http) { }

  ngOnInit() {
 
      const formData = new FormData();
      formData.append("url", 'http://34.93.3.223/icici-drupal/web/json/published-api-products'); //1
      this.HttpClient.post<any>(

    
        "https://developer.icicibank.com/rest/restProxy1",
  
        formData
  
      ).subscribe(
  
        res => { 
          console.log(res);
          this.data = res;
        },

        err => {
          console.log('err', err);
          this.spinnerService.hide();
        });
  }

  goToDrupal(){
    let data1 =  window.sessionStorage.getItem("DrupalData");
    if(data1 == null || data1==undefined){
      alert("Login to test API");
      return false;
    }
    let data = JSON.parse(data1);
  const apiData = {
    "request": {
      "FirstName": data.FirstName,
      "LastName": data.LastName,
      "Useremail": data.Useremail,
      "Username": data.Username,
    },
  };
  let obj = {};
  obj["issuePacket"] = JSON.stringify(apiData);
  this.spinnerService.show();
  //Ex: Basic base64_encode(username:password)
  this.adm.saveDataToDrupal(obj)
    .subscribe(
      (data:any) => {
          var response= JSON.parse(data._body);
          console.log(response.message);
          response = response.message ;
          console.log(atob(response.response));
          let path = atob(response.response);
          window.open(
            path,
            '_blank' // <- This is what makes it open in a new window.
          );
          this.spinnerService.hide();
        //  window.location.href = "http://34.93.3.223/icici-drupal/web/explore-apis";
      },
      err => {
        console.log('err', err);
        this.spinnerService.hide();
       // this.router.navigate(['error']);
      });
  
  
   }

}
