//import { Component, OnInit, TemplateRef, Pipe, ɵConsole } from "@angular/core";
import { Component, OnInit, TemplateRef, ViewChild, ViewChildren, ElementRef, QueryList, EventEmitter, Output, Input } from '@angular/core';

import { DashboardService, LoginService } from "src/app/services";
import { NgxXml2jsonService } from "ngx-xml2json";
import { BsModalRef, BsModalService } from "ngx-bootstrap";
import { DomSanitizer } from "@angular/platform-browser";
import { ActivatedRoute } from "@angular/router";
import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
import { CONSTANTS } from 'config/application-constant';
import { Router } from "@angular/router";
import { ToasterService, Toast } from 'angular2-toaster';

declare var $: any;
@Component({
  selector: "app-branch-details",
  templateUrl: "./branch-details.component.html"
  //styleUrls: ['./branch-details.component.css']
})
export class BranchDetailsComponent implements OnInit {
  id: any;
  resp: any;
  description: any;
  branchId: any;
  obj: any;
  image:any;
  file:any;
  faq:any = false;
  faqEazypay:any= false;
  eazypay:any ;
  compositpay:any;
  faqObj:any;
  faqHeader:any;
  faqObjQues:any=[];
  faqObjQues_eazy:any=[];
  faqObjAns:any=[];
  faqObjAns_eazy:any=[];
  faqObjList:any;
  faqHeaderList:any;
  base64data:any;

  /** @class BranchDetailsComponent
   * @constructor
   */
  constructor(
    private route: ActivatedRoute,
    private adm: LoginService,
    private ngxXml2jsonService: NgxXml2jsonService,
    private modalService: BsModalService,
    private sanitizer: DomSanitizer,
    private spinnerService: Ng4LoadingSpinnerService,
    private router: Router,
    private toasterService: ToasterService,
    private dashboardService: DashboardService,
    
  ) {
    this.route.params.subscribe(params => {
      this.branchId = params["id"];
      this.newApplication();
      let num = this.branchId;
      if(num === "201" || num === 201 ){
        this.faq= false;
        this.faqEazypay= true;
        this.eazypay= true;
        this.compositpay= false;
        
      }else if(num === "207" || num === 207){
        this.faq= true;
        this.faqEazypay= false;
        this.compositpay= true;
        this.eazypay= false;
      }else{
        this.faq= false;
        this.eazypay= false;
        this.compositpay= false;
        this.faqEazypay= false;
      }
      if(num === "177" || num === 177){
        this.image = "https://developer.icicibank.com/assets/images/BBPS.png";
      }
    });
  }
  constants = CONSTANTS;
  ngOnInit() {
    this.spinnerService.hide();
    this.adm.faq().subscribe((data:any)=> {
      this.faqObjList = data._body;
      this.faqObjList= this.faqObjList.replace(/\\n/g, "\\\\n")
      this.faqObj = JSON.parse(this.faqObjList);
     for (var i  in this.faqObj){
       if(this.faqObj[i][0] ==='Eazypay'){
          this.faqObjQues_eazy.push(this.faqObj[i][1])
          this.faqObjAns_eazy.push(this.faqObj[i][2])
          this.faqObjAns_eazy= this.faqObjAns_eazy.map(function(str) {
            return str.replace(/\\n/g, '\n')
          });
       }else if(this.faqObj[i][0] ==='CompositeAPI'){
          this.faqObjQues.push(this.faqObj[i][1])
          this.faqObjAns.push(this.faqObj[i][2])
          this.faqObjAns= this.faqObjAns.map(function(str) {
            return str.replace(/\\n/g, '\n')
          });
      }
      
      }
      //this.faqHeaderList = JSON.parse(this.faqObjList)
     // this.faqHeader = this.faqHeaderList["1"][0]

     $('ul li a[data-toggle="tab"]').removeClass('active');
     $('ul li a[data-toggle="tab"]').removeClass('show');
    
     $('ul li a[data-toggle="dropdown"]').removeClass('active');
     $('ul li a[data-toggle="dropdown"]').removeClass('show');
     $('ul li .documetationClass').addClass('active');
  },
  err => {
    console.log('err', err);
   // this.router.navigate(['error']);
    this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    
  },)

  }
 
  /** get branch node details
   * @class BranchDetailsComponent
   * @method newApplication
   */
  newApplication() {
    this.spinnerService.show();
    this.adm.api_description(this.branchId).subscribe((data: any) => {
      var response = data._body;
      this.spinnerService.hide();
      this.obj = JSON.parse(response);
      this.resp = this.obj[0].TAB_NAME;
      this.description = this.obj[0].DESCRIPTION;
      this.image = this.obj[0].IMAGE_URL;
      this.file = this.obj[0].FILE_URL;
      console.log("image=="+this.image+"file==="+this.file);
      if(this.branchId === "177" || this.branchId === 177){
        this.image = "https://developer.icicibank.com/assets/images/BBPS.png";
      }
   //   this.image= "/u1/APIGateway/developerPortalDocsUpload/isan.jpg";
   this.image=  "/u1/APIGateway/developerPortalDocsUpload/IFITechnew.png";
      let index = this.image.indexOf("https");
      if(index > -1){

        
      }else if(this.image && this.image !== "" && this.image !== " "){
           let json = {
              path:this.image
            }
            let that = this;
            let filename =  this.image.substring(this.image.lastIndexOf('/') + 1);
            this.adm.downloadImage(json).subscribe((data: any) => {
              let certificate = data._body;
              console.log(data._body);

              var blob = new Blob([certificate], {
                type: "image/jpeg"
              });
           //   saveAs(blob, filename);
              this.createImageFromBlob(blob);
            //  this.image = certificate;
            /*  const reader = new FileReader();
              reader.onload = (e) => this.image = reader.result;
              reader.readAsDataURL(new Blob([certificate])); */ 

          //   let objectURL = 'data:image/png;base64,' + data._body;
           //   this.image = this.sanitizer.bypassSecurityTrustUrl(objectURL);
              /* var base64String = this._arrayBufferToBase64(certificate);
              this.base64data = base64String;
              console.log("base64String"+ base64String);
              this.myFunc(); */
              /*   var reader = new FileReader();
                reader.readAsDataURL(new Blob([certificate]));
                reader.onloadend = function() {
                   that.base64data = reader.result;
                   that.myFunc();
                } */
               // this.myFunc(); 
            },
            err => {
              console.log('err', err);
            
            });
      }
    },
    err => {
      console.log('err', err);
     // this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }

  createImageFromBlob(image: Blob) {
    let reader = new FileReader();
    reader.addEventListener("load",
      () => {
          this.image = reader.result;
      },
      false);

    if (image) {
      if (image.type !== "application/pdf")
        reader.readAsDataURL(image);
    }
  }
  _arrayBufferToBase64( buffer ) {
    var binary = '';
    var bytes = new Uint8Array( buffer );
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode( bytes[ i ] );
    }
    return window.btoa( binary );
}
  myFunc(){
    let mySrc = this.sanitizer.bypassSecurityTrustUrl('data:image/png;base64,' + this.base64data);
    this.image = mySrc;
    console.log("mySrc=="+mySrc);
  }
  
   /** get branch node details
   * @class BranchDetailsComponent
   * @method downloadFile
   */
  downloadFile() {

    if(this.faqEazypay){
      this.file = "https://developer.icicibank.com/assets/documents/Eazypay.zip";
    }
    if(this.branchId === "177" || this.branchId === 177 ){
      this.file = "https://developer.icicibank.com/assets/documents/BBPS.pdf";
    }
    let path = this.file;
    let filename =  path.substring(path.lastIndexOf('/') + 1);
    let index = path.indexOf("https");
    if(index > -1){
      this.adm.downloadFromURL(path).subscribe((data: any) => {
        console.log(data);
        let certificate = data._body;
        console.log(data._body);
        var blob = new Blob([certificate], {
          type: "text/pdf"
        });
        saveAs(blob,filename);
      },
      err => {
        console.log('err', err);
       
      });
    
    }else
    {
        let json = {
              path:path
            }

            this.dashboardService.getDocFileDownload(json).subscribe((data: any) => {
              console.log(data);
              let certificate = data._body;
              console.log(data._body);
              var blob = new Blob([certificate], {
                type: "text/pdf"
              });
              saveAs(blob,filename);
            },
            err => {
              console.log('err', err);
            
            });
          
    }
  } 
  dounloadImage(){
    let path ='';
    let dwldLink = document.createElement("a");
    
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", path);
    //dwldLink.setAttribute("download", fileName + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  }
   /** get branch node details
   * @class BranchDetailsComponent
   * @method downloadFAQ
   */
  downloadFAQ() {
    
    let dwldLink = document.createElement("a");
    
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", "https://developer.icicibank.com/assets/documents/UPI Merchant Integrations FAQs - Consolidated.docx");
    //dwldLink.setAttribute("download", fileName + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  } 
  toastrmsg(type ,title) {
    var toast: Toast = {
      type: type,
      title:"",
      body:title,
      showCloseButton: true 
    }; 
    this.toasterService.pop(toast);
  }     
  goToDrupal(){
    let data1 =  window.sessionStorage.getItem("DrupalData");
    if(data1 == null || data1==undefined){
      alert("Login to test API");
      return false;
    }
    let data = JSON.parse(data1);
  const apiData = {
    "request": {
      "FirstName": data.FirstName,
      "LastName": data.LastName,
      "Useremail": data.Useremail,
      "Username": data.Username,
    },
  };
  let obj = {};
  obj["issuePacket"] = JSON.stringify(apiData);
  this.spinnerService.show();
  //Ex: Basic base64_encode(username:password)
  this.adm.saveDataToDrupal(obj)
    .subscribe(
      (data:any) => {
          var response= JSON.parse(data._body);
          console.log(response.message);
          response = response.message ;
          console.log(atob(response.response));
          let path = atob(response.response);
          window.open(
            path,
            '_blank' // <- This is what makes it open in a new window.
          );
          this.spinnerService.hide();
        //  window.location.href = "http://34.93.3.223/icici-drupal/web/explore-apis";
      },
      err => {
        console.log('err', err);
        this.spinnerService.hide();
       // this.router.navigate(['error']);
      });
  
  
   }
}
