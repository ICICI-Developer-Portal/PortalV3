import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilterPipe'
})
export class SearchFilterPipePipe implements PipeTransform {

  // transform(value: any, args?: any): any {
  //   return null;
  // }

  // transform(items: any, emailSearch:string): any {
  //   if(items.length === 0 || emailSearch === ''){
  //      return items;
  //   }
  //   const resultArray = [];
  //   for(const item of items) {
  //     if(item.title == emailSearch){
  //        resultArray.push(item);
  //     }
  //    }
  //    return resultArray;
  //   }
  
  transform(value: string[], emailSearch: string) {
    if (!emailSearch || emailSearch === '') {
        return value;
    }
    return value.filter(item => -1 < item.toLowerCase().indexOf(emailSearch.toLowerCase()));
}
}
