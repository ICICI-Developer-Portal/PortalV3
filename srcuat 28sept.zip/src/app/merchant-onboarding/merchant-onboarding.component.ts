import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-onboarding',
  templateUrl: './merchant-onboarding.component.html',
  styleUrls: ['./merchant-onboarding.component.css']
})
export class MerchantOnboardingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
