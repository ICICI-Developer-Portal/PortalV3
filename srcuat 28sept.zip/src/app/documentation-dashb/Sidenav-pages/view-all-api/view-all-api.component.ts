import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services';
import { ActivatedRoute, Router } from '@angular/router';
import { forEach } from '@angular/router/src/utils/collection';
import { ToasterService, Toast } from 'angular2-toaster';
// import { HttpClientModule } from '@angular/common/http';
declare var $:any;

@Component({
  selector: 'app-view-all-api',
  templateUrl: './view-all-api.component.html',
  //styleUrls: ['./view-all-api.component.css']
})
export class ViewAllApiComponent implements OnInit {
   seartext:any;
  APIListV: string; 
  appNameList =[];
  AppId:any={};
dataBody= 
  [
    {
        "ApiId": "130",
        "ApiDomain": "Payments",
        "ApiName": "Validate Address UPI 1.0",
        "ApiDesc": "This API will be used by the application customer wants to add a beneficiary within PSP application (for sending & collecting money) OR at the time of transaction when initiating Pay to ad-hoc VPA / Collect from ad-hoc VPA request.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/validateaddress"
    },
    {
        "ApiId": "131",
        "ApiDomain": "Payments",
        "ApiName": "Common Pay Request  UPI 1.0",
        "ApiDesc": "This common API will support to initiate a pay request to virtual address and Global recipients (IFSC + Account no / Mobile + MMD / Aadhaar + IIN).",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/portal/upi/common-pay-request"
    },
    {
        "ApiId": "132",
        "ApiDomain": "Payments",
        "ApiName": "Balance Inquiry  UPI 1.0",
        "ApiDesc": "API will return the balance details of the Account +IFSC mapped to VPA. Same API will cater to give Customer existence.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/balanceenquiry"
    },
    {
        "ApiId": "133",
        "ApiDomain": "Payments",
        "ApiName": "Collect Request UPI 1.0",
        "ApiDesc": "API will initiate a Collect request from the virtual address. Amount will be credited to the Account mapped to VPA which is identified by Account + IFSC.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/collectrequest"
    },
    {
        "ApiId": "134",
        "ApiDomain": "Payments",
        "ApiName": "Change MPIN UPI 1.0",
        "ApiDesc": "API will change account MPIN. Account will be identified by Account + IFSC mapped to VPA.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/changepin"
    },
    {
        "ApiId": "135",
        "ApiDomain": "Payments",
        "ApiName": "Collect Auth UPI 1.0",
        "ApiDesc": "This API will approve or reject Collect request initiated by some Payee to user identified by Mobile",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/CollectAuth"
    },
    {
        "ApiId": "136",
        "ApiDomain": "Payments",
        "ApiName": "Merchant Pay Request UPI 1.0",
        "ApiDesc": "This API will initiate a pay request to Merchant virtual address.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/portal/upi/collect-merchant-request"
    },
    {
        "ApiId": "137",
        "ApiDomain": "Payments",
        "ApiName": "Pay Request Global UPI 1.0",
        "ApiDesc": "This API will initiate a pay request to global address.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/payRequestGlobal"
    },
    {
        "ApiId": "138",
        "ApiDomain": "Payments",
        "ApiName": "Pay Request UPI 1.0",
        "ApiDesc": "API will initiate a pay request to virtual address.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/PayRequest"
    },
    {
        "ApiId": "139",
        "ApiDomain": "Payments",
        "ApiName": "Merchant Collect Request UPI 1.0",
        "ApiDesc": "Merchant Application can initiate Collect request from Customer VPA (Payer VPA).",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/merchantcollect"
    },
    {
        "ApiId": "140",
        "ApiDomain": "Payments",
        "ApiName": "Transaction Status UPI 1.0",
        "ApiDesc": "API will return the status of the transaction based on the “seq-no” of the original transaction.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/transactionstatus"
    },
    {
        "ApiId": "141",
        "ApiDomain": "Payments",
        "ApiName": "Get Transaction Details UPI 1.0",
        "ApiDesc": "This API is leveraged to fetch the complete transaction details on basis of VPA",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/GetTransactionDetails"
    },
    {
        "ApiId": "142",
        "ApiDomain": "Payments",
        "ApiName": "Get Transaction History UPI 1.0",
        "ApiDesc": "This API is leveraged to fetch the all transactions  on basis of VPA",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/GetTransactionHistory"
    },
    {
        "ApiId": "207",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Offers",
        "ApiDesc": "This API is used for checking offers of the customer.",
        "ApiSubDomain": "Accounting Services",
        "SandboxUrl": "api/v0/getoffers"
    },
    {
        "ApiId": "208",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Mini Statement",
        "ApiDesc": "This API is used for checking the mini statement of customer.",
        "ApiSubDomain": "Current Account",
        "SandboxUrl": "api/v0/ministatement"
    },
    {
        "ApiId": "209",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Check Balance",
        "ApiDesc": "This API is used to show the account balance (check balance) of saving account number or credit card.",
        "ApiSubDomain": "Savings Account",
        "SandboxUrl": "api/v0/checkbalance"
    },
    {
        "ApiId": "210",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Block Card",
        "ApiDesc": "This API is used to block the  card temporary or permanently.",
        "ApiSubDomain": "Savings Account",
        "SandboxUrl": "api/v0/blockcard"
    },
    {
        "ApiId": "211",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Unblock Card",
        "ApiDesc": "This API is used to unblock the cards.",
        "ApiSubDomain": "Savings Account",
        "SandboxUrl": "api/v0/unblockcard"
    },
    {
        "ApiId": "212",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Card Status",
        "ApiDesc": "This API is used to check the status of card.",
        "ApiSubDomain": "Savings Account",
        "SandboxUrl": "api/v0/Cardstatus"
    },
    {
        "ApiId": "213",
        "ApiDomain": "Building Blocks",
        "ApiName": "Amount Validation",
        "ApiDesc": "This API is used to fetch the operator of the mobile number and validate the amount of recharge.",
        "ApiSubDomain": "Accounting Services",
        "SandboxUrl": "api/v0/amountvalidation"
    },
    {
        "ApiId": "214",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Account Numbers",
        "ApiDesc": "This API is used to fetch the account numbers and userId mapped with the provided mobile number.",
        "ApiSubDomain": "Savings Account",
        "SandboxUrl": "api/v0/getaccountnumbers"
    },
    {
        "ApiId": "215",
        "ApiDomain": "Building Blocks",
        "ApiName": "Generate OTP",
        "ApiDesc": "This API is used to create the OTP and the OTP will be send to customer mobile number.",
        "ApiSubDomain": "Accounting Services",
        "SandboxUrl": "api/v0/otpgeneration"
    },
    {
        "ApiId": "216",
        "ApiDomain": "Building Blocks",
        "ApiName": "OTP Verification",
        "ApiDesc": "This API will be used to verify the OTP which was send to customer Mobile number.",
        "ApiSubDomain": "Accounting Services",
        "SandboxUrl": "api/v0/eotp/verify"
    },
    {
        "ApiId": "217",
        "ApiDomain": "Building Blocks",
        "ApiName": "Mobile Recharge",
        "ApiDesc": "This API is used to do the mobile recharge by debiting the provided account number.",
        "ApiSubDomain": "Accounting Services",
        "SandboxUrl": "api/v0/otpverification"
    },
    {
        "ApiId": "300",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Application Processing ",
        "ApiDesc": "This API is used for processing the application entered by the customer",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/ApplicationProcessing"
    },
    {
        "ApiId": "301",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Activation",
        "ApiDesc": "This API is used for card activation",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cardActivation"
    },
    {
        "ApiId": "302",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Mini Statement/ Recent Transactions Details",
        "ApiDesc": "This API is used for retrieving total Debit and Credit amount, Ledger Balance, Available Balance, recent 10 transactions details, Pre-Authentication Hold Amount and Pre-Authentication Transaction details",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": " api/v0/miniStatementTransactionsDetails"
    },
    {
        "ApiId": "303",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card To Card Transfer",
        "ApiDesc": "This API is used for transferring the amount between two cards.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cardToCardTransfer"
    },
    {
        "ApiId": "304",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Topup",
        "ApiDesc": "This API is used to reload specific amount on a card.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": " api/v0/cardTopup"
    },
    {
        "ApiId": "305",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Instant Debit",
        "ApiDesc": "This API is used to debit specific amount on a card.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cardInstantDebit"
    },
    {
        "ApiId": "306",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Limit Verification",
        "ApiDesc": "This API is used to verify customer limit before reloading specific amount on a card.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/limitVerification"
    },
    {
        "ApiId": "307",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Contact Info",
        "ApiDesc": " This API is used to update cardholders contact information in CMS. The below mentioned information can be updated using API. \nPhysical Address\nMailing Address\nEmail Address\nPhone Numbers",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/contactInfo"
    },
    {
        "ApiId": "308",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Info Enquiry",
        "ApiDesc": "This API is used to retrieve cardholders contact information which is available in CMS. ",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/personalInfoEnquiry"
    },
    {
        "ApiId": "309",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Information Enquiry",
        "ApiDesc": "This API is used to retrieve cardholder’s card information which is available in CMS.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/PrePaidCardsCardInformationEnquiry"
    },
    {
        "ApiId": "310",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Monthly Statement",
        "ApiDesc": " This API is used to retrieve all the financial transactions and Pre-authentication transactions happened in current month.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": " api/v0/monthlyStatement"
    },
    {
        "ApiId": "311",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Block / Unblock",
        "ApiDesc": " This API is used for blocking and de-blocking of card.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cardBlockUnblock"
    },
    {
        "ApiId": "312",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Transaction Enquiry",
        "ApiDesc": "This API is used for getting details of any transactions. ",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/transactionEnquiry"
    },
    {
        "ApiId": "313",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Linked Mobile",
        "ApiDesc": "This API is used for getting details of any transactions. ",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/LinkedMobile"
    },
    {
        "ApiId": "314",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Sale",
        "ApiDesc": "To check non personalized card activation is working.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cardSale"
    },
    {
        "ApiId": "315",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Upgrade Card (Virtual to Physical)",
        "ApiDesc": "This API is used for getting new physical card.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/upgardeVirtualCardWithPhysicalCard"
    },
    {
        "ApiId": "316",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Account Statement",
        "ApiDesc": "This API is used for retrieving total Debit and Credit transaction details for particular months, Ledger Balance, Available Balance.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/accountstatement"
    },
    {
        "ApiId": "317",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Fetch Card Verification Value",
        "ApiDesc": "This API is used for getting verification value for card. ",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cvvGeneration"
    },
    {
        "ApiId": "318",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Close",
        "ApiDesc": "This API is used to close the customer card.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": " api/v0/cardClose"
    },
    {
        "ApiId": "319",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Credit Freeze to Active",
        "ApiDesc": "This API is used for change the card status from CRFREEZE to ACTIVE Status.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/crFreezeToActive"
    },
    {
        "ApiId": "320",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Passive to Active",
        "ApiDesc": "This API is used for change the card status from PASSIVE to ACTIVE Status.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/passiveToActive"
    },
    {
        "ApiId": "321",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Issuance",
        "ApiDesc": "This API is used for issuing the new card to customer.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/cardIssuance"
    },
    {
        "ApiId": "322",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Update/Change PIN",
        "ApiDesc": "This API is used for changing or update the customer PIN.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/updatePin"
    },
    {
        "ApiId": "323",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Buyer Number Linked",
        "ApiDesc": "This API is used to link the buyer number.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/buyernumberlinked"
    },
    {
        "ApiId": "324",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Periodic Statement",
        "ApiDesc": "This API is used for getting the periodic statement for the customer.",
        "ApiSubDomain": "Pre-Paid Cards",
        "SandboxUrl": "api/v0/periodicStatement"
    },
    {
        "ApiId": "401",
        "ApiDomain": "Building Blocks",
        "ApiName": "eOTP Creation",
        "ApiDesc": "This API will be used for OTP creation. OTP will be sent on customer number.",
        "ApiSubDomain": "e-OTP",
        "SandboxUrl": "api/v0/eotp/create"
    },
    {
        "ApiId": "402",
        "ApiDomain": "Building Blocks",
        "ApiName": "eOTP Validation",
        "ApiDesc": "This API will be used for OTP Validation.",
        "ApiSubDomain": "e-OTP",
        "SandboxUrl": "api/v0/eotp/verify"
    },
    {
        "ApiId": "431",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Offer On Account",
        "ApiDesc": "This API is used get the offers of various ICICI Bank Products mapped to customer on the basis of account number",
        "ApiSubDomain": "Bank Offers",
        "SandboxUrl": "api/v0/getoffer"
    },
    {
        "ApiId": "432",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Offer On Customer ID",
        "ApiDesc": "This API is used for getting the offers various ICICI Bank Products mapped to customer on the basis of Customer ID.",
        "ApiSubDomain": "Bank Offers",
        "SandboxUrl": "api/v0/getofferoncustid"
    },
    {
        "ApiId": "433",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Offer On Mobile",
        "ApiDesc": "This API is used for getting offers various ICICI Bank Products mapped to customer on the basis of mobile number.",
        "ApiSubDomain": "Bank Offers",
        "SandboxUrl": "api/v0/getofferonmobile"
    },
    {
        "ApiId": "434",
        "ApiDomain": "Building Blocks",
        "ApiName": "Pre Approved Offers",
        "ApiDesc": "This API is used get the pre-approved mapped to customer on the basis of application number.",
        "ApiSubDomain": "Bank Offers",
        "SandboxUrl": "api/v0/preapprovedoffers"
    },
    {
        "ApiId": "435",
        "ApiDomain": "Building Blocks",
        "ApiName": "Block Offer",
        "ApiDesc": "This API is used to block the offers which are already availed by the customer.",
        "ApiSubDomain": "Bank Offers",
        "SandboxUrl": "api/v0/blockoffer"
    },
    {
        "ApiId": "436",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Account Creation",
        "ApiDesc": "This API will be used to create the pay later accounts for the customer post OTP verification.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/acctcreation"
    },
    {
        "ApiId": "437",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Application Status Check",
        "ApiDesc": "This API will be used to check the status of pay-later account by mobile number or transaction id.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/applstatuscheck"
    },
    {
        "ApiId": "438",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Paylater Balance Inquiry ",
        "ApiDesc": "This API will be used for balance inquiry in ICICI Bank PayLater A/c. ",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/balinquiry"
    },
    {
        "ApiId": "439",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Bill Inquiry ",
        "ApiDesc": "This API will be used for bill inquiry in ICICI Bank PayLater A/c.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/billinquiry"
    },
    {
        "ApiId": "440",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Statement ",
        "ApiDesc": "This API will be used to check the statement (mini and detailed) of ICICI Bank PayLater A/c. ",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/stmts"
    },
    {
        "ApiId": "441",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Pay Dues ",
        "ApiDesc": "This API will be used to make Pay Dues of ICICI Bank PayLater A/c.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/paydues"
    },
    {
        "ApiId": "442",
        "ApiDomain": "Loans And Cards",
        "ApiName": "OD A/c Discovery",
        "ApiDesc": "This API will be used for OD account discovery basis on the mobile number.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/paylater/fetchaccountno"
    },
    {
        "ApiId": "501",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Offer Fetch API ",
        "ApiDesc": "This API is used to display the offer details with EMI & interest rate.",
        "ApiSubDomain": "Loan Top-Up",
        "SandboxUrl": "api/v0/offerfetch"
    },
    {
        "ApiId": "502",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Generate Agreement Letter",
        "ApiDesc": "This API is used to generate agreement letter in the form of pdf. ",
        "ApiSubDomain": "Loan Top-Up",
        "SandboxUrl": "api/v0/genpdf"
    },
    {
        "ApiId": "503",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Loan Top-Up Disbursement  ",
        "ApiDesc": "This API is used to for loan disbursement.",
        "ApiSubDomain": "Loan Top-Up",
        "SandboxUrl": "api/v0/loandisbursement"
    },
    {
        "ApiId": "600",
        "ApiDomain": "Building Blocks",
        "ApiName": "Document Upload",
        "ApiDesc": "This API is used to access ICICI Bank file repository to save documents, files and help in providing viewing restrictions as well. API makes it easier in pushing the document using JSON request.",
        "ApiSubDomain": "File upload",
        "SandboxUrl": "api/v0/omnidocs/fileUpload"
    },
    {
        "ApiId": "601",
        "ApiDomain": "Payments",
        "ApiName": "QR Code",
        "ApiDesc": "This API is used to generate a reference ID which is required in QR code generation",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/QR"
    },
    {
        "ApiId": "602",
        "ApiDomain": "Payments",
        "ApiName": "Collect Pay ",
        "ApiDesc": "This API is used to generate the collect pay request for payee. Collect pay approval request will be sent to PSP app",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/collectpay"
    },
    {
        "ApiId": "603",
        "ApiDomain": "Payments",
        "ApiName": "Transaction Status ",
        "ApiDesc": "This API is used for checking the status of the transaction.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/transactionstatus"
    },
    {
        "ApiId": "604",
        "ApiDomain": "Payments",
        "ApiName": "Refund ",
        "ApiDesc": "This API is used for refund of the transaction.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/refund"
    },
    {
        "ApiId": "605",
        "ApiDomain": "Payments",
        "ApiName": "Callback Status ",
        "ApiDesc": "This API is used to check the callback status.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": " api/v0/eazypay/CallbackStatus"
    },
    {
        "ApiId": "606",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Loan  Generate OTP",
        "ApiDesc": "This API is leveraged to create and deliver OTP as SMS for authentication or confirmation as required in the process.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/plotpcreation"
    },
    {
        "ApiId": "607",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Loan Get Offer ",
        "ApiDesc": "This API is used to provides the details of the loan offer that is available for the customer based on the bank's evaluation process. For PL, the API shows the available PL offer to the customer.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/plgetoffer"
    },
    {
        "ApiId": "608",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Loan Eligibility Check",
        "ApiDesc": "This API is used to enables the customer to change the offered loan amount or tenure based on the requirement and submit the changed loan offer for evaluation.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/pleligibilitycheck"
    },
    {
        "ApiId": "609",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Loan Bank Statement Upload ",
        "ApiDesc": "This API is leveraged to upload bank statements of customer to bank for verification process  which is used for underwriting.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/plbankstatementupload"
    },
    {
        "ApiId": "610",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Loan Document Upload ",
        "ApiDesc": "This API is used to leveraged to upload documents required as per the process.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/plfileupload"
    },
    {
        "ApiId": "611",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Personal Loan Disbursement",
        "ApiDesc": "This API is leveraged to initiate the loan disbursement process. This API initiates the process of disbursement , booking , updating and successful / failure update to the customer.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/plloandisbursement"
    },
    {
        "ApiId": "612",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Auto Loan Generate OTP",
        "ApiDesc": "This API is leveraged to create and deliver OTP as SMS for authentication or confirmation as required in the process.",
        "ApiSubDomain": "Auto Loan",
        "SandboxUrl": "api/v0/OtpCreation"
    },
    {
        "ApiId": "613",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Auto Loan Get Offer ",
        "ApiDesc": "This API provides the details of the loan offer that is available for the customer based on the bank's  evaluation process. For AL , the API shows the available AL offer to the customer",
        "ApiSubDomain": "Auto Loan",
        "SandboxUrl": "api/v0/GetOffers"
    },
    {
        "ApiId": "614",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Auto Loan Eligibility Check",
        "ApiDesc": "This API enables the customer to change the offered loan amount or tenure based on the requirement and submit the changed loan offer for evaluation.",
        "ApiSubDomain": "Auto Loan",
        "SandboxUrl": "api/v0/eligibilityCheck"
    },
    {
        "ApiId": "615",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Auto Loan Bank Statement Upload ",
        "ApiDesc": "This API is leveraged to upload bank statements of customer to bank for verification process  which is used for underwriting.",
        "ApiSubDomain": "Auto Loan",
        "SandboxUrl": "api/v0/bankStatmentUpload"
    },
    {
        "ApiId": "1376",
        "ApiDomain": "Building Blocks",
        "ApiName": "Net Balance",
        "ApiDesc": "This API Fetches the Net balance account details.",
        "ApiSubDomain": "Dashboard Widgets",
        "SandboxUrl": "v1/dashboardwidgets/banks/users/customaccounts/netbalance"
    },
    {
        "ApiId": "1377",
        "ApiDomain": "Building Blocks",
        "ApiName": "What’s New Widget",
        "ApiDesc": "This API is used to fetch the latest features available for the user on dashboard under what’s new widget.",
        "ApiSubDomain": "Dashboard Widgets",
        "SandboxUrl": "v1/dashboardwidgets/banks/users/customdashboard/widgets/whatsnew"
    },
    {
        "ApiId": "1378",
        "ApiDomain": "Building Blocks",
        "ApiName": "Top Services Widget",
        "ApiDesc": "This API is used to fetch the top services list available for the user on dashboard under top services widget.",
        "ApiSubDomain": "Dashboard Widgets",
        "SandboxUrl": "v1/dashboardwidgets/banks/users/customdashboard/widgets/topservices"
    },
    {
        "ApiId": "1379",
        "ApiDomain": "Building Blocks",
        "ApiName": "RM Contact Details Widget",
        "ApiDesc": "This API is used to fetch the RM Details available for the user on dashboard under top services widget.",
        "ApiSubDomain": "Dashboard Widgets",
        "SandboxUrl": "v1/dashboardwidgets/banks/users/customdashboard/widgets/rmdetails"
    },
    {
        "ApiId": "1380",
        "ApiDomain": "Building Blocks",
        "ApiName": "CIBIL Score Range Widget",
        "ApiDesc": "This API is used to fetch the CIBIL score range for the user on dashboard under top services widget.",
        "ApiSubDomain": "Dashboard Widgets",
        "SandboxUrl": "v1/dashboardwidgets/banks/users/customdashboard/widgets/getcibilscore"
    },
    {
        "ApiId": "616",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Auto Loan Document Upload ",
        "ApiDesc": "This API is leveraged to upload documents required as per the process",
        "ApiSubDomain": "Auto Loan",
        "SandboxUrl": "api/v0/fileUpload"
    },
    {
        "ApiId": "617",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Auto Loan Sanction Letter",
        "ApiDesc": "This API is used to generate the sanction letter for the selected loan.",
        "ApiSubDomain": "Auto Loan",
        "SandboxUrl": "api/v0/PDFGenerator"
    },
    {
        "ApiId": "618",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Get Loan Account Details",
        "ApiDesc": "This API is used to get the loan details on the Account.",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/getLoanAccountDetails"
    },
    {
        "ApiId": "619",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Repayment Details",
        "ApiDesc": "This API is used for Repayment Details of Loan",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/repaymentDetails"
    },
    {
        "ApiId": "620",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Profile Information",
        "ApiDesc": "This API is used to get Profile Information of Loan Account Holder",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/profileInformation"
    },
    {
        "ApiId": "621",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Disbursement Details",
        "ApiDesc": "This API is used to know the Disbursement Details of the given Loan account holder",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/disbursementDetails"
    },
    {
        "ApiId": "622",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Loan Credential Verification Check",
        "ApiDesc": "This API is used for Loan credential verification against Loan Account Number.",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/loanCredentialVerificationCheck"
    },
    {
        "ApiId": "623",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Get IT Certificate",
        "ApiDesc": "This API will be used to get IT certificate based on given Loan.",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/getITCertificate"
    },
    {
        "ApiId": "624",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Overdue Outstanding",
        "ApiDesc": "This API will be used for Over Due Outstanding details of given Loan at given time.",
        "ApiSubDomain": "Management",
        "SandboxUrl": "api/v0/overdueOutstanding"
    },
    {
        "ApiId": "625",
        "ApiDomain": "Corporate API Suite",
        "ApiName": "Agent Login",
        "ApiDesc": "This API is used by the agent to login, no authorization header is required to invoke this API. In case the user has not reset his password at least once, this API will provide agent data with password reset flag.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/agentLogin"
    },
    {
        "ApiId": "626",
        "ApiDomain": "Payments",
        "ApiName": "Reset Password",
        "ApiDesc": "This API is used to reset the password.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/resetPassword"
    },
    {
        "ApiId": "627",
        "ApiDomain": "Payments",
        "ApiName": "Fetch Last ’N’ Transaction ",
        "ApiDesc": "This API is used to fetch last N number of transactions done by the agent.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/fetchLastNTransaction"
    },
    {
        "ApiId": "628",
        "ApiDomain": "Payments",
        "ApiName": "Transaction Metrics",
        "ApiDesc": "This API is used to fetch some important transactional information for a time.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/transactionMetrics"
    },
    {
        "ApiId": "629",
        "ApiDomain": "Payments",
        "ApiName": "Get Paid Bill",
        "ApiDesc": "This API is used to fetch total number of bills paid by the agent.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getPaidBill"
    },
    {
        "ApiId": "630",
        "ApiDomain": "Payments",
        "ApiName": "Get Category List",
        "ApiDesc": "This API is used to fetch the categories of the BBPS billers.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getCategoryList"
    },
    {
        "ApiId": "631",
        "ApiDomain": "Payments",
        "ApiName": "Get Biller List",
        "ApiDesc": "This API is used to fetch a biller from a selected category.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getBillerList"
    },
    {
        "ApiId": "632",
        "ApiDomain": "Payments",
        "ApiName": "Get Sub-Biller List",
        "ApiDesc": "This API is used to fetch the derived biller list where billers are sub part of a bigger merchant.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getSubBillerList"
    },
    {
        "ApiId": "633",
        "ApiDomain": "Payments",
        "ApiName": "Check Bill Fetch Support ",
        "ApiDesc": "This API is used to determine whether biller supports bill fetch and/or adhoc payments only.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/checkBillFetchSupport"
    },
    {
        "ApiId": "634",
        "ApiDomain": "Payments",
        "ApiName": "Get Biller Customer Parameters",
        "ApiDesc": "This API is used to fetch the customer parameter fields for a selected leaf node biller.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getBillerCustomerParameters"
    },
    {
        "ApiId": "635",
        "ApiDomain": "Payments",
        "ApiName": "Fetch Bill",
        "ApiDesc": "This API is used to fetch bill against a biller after providing the proper customer parameter fields.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/fetchBill"
    },
    {
        "ApiId": "636",
        "ApiDomain": "Payments",
        "ApiName": "Fetch Bill By Previous Transaction Ref ID ",
        "ApiDesc": "This API is used to fetch bill data by previous transaction ref id. ",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/fetchBillByPreviousTransactionRefId"
    },
    {
        "ApiId": "637",
        "ApiDomain": "Payments",
        "ApiName": "Validate Customer Parameters (Pay-Only Biller)",
        "ApiDesc": "This API is used to determine whether the customer parameters entered by user are correct.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/validateCustomerParameters"
    },
    {
        "ApiId": "638",
        "ApiDomain": "Payments",
        "ApiName": "Validate Payment Amount",
        "ApiDesc": "This API is used to validate payable amount of a biller.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/validatePaymentAmount"
    },
    {
        "ApiId": "639",
        "ApiDomain": "Payments",
        "ApiName": "Get Tax Amount",
        "ApiDesc": "This API is used to calculate all kind of taxes.  ",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getTaxAmount"
    },
    {
        "ApiId": "640",
        "ApiDomain": "Payments",
        "ApiName": "Generate Transaction Reference ID",
        "ApiDesc": "This API is used to generate a unique reference id for transaction.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/generateTransactionReferenceId"
    },
    {
        "ApiId": "641",
        "ApiDomain": "Payments",
        "ApiName": "Pay Bill (Fetch & Pay Bill)",
        "ApiDesc": "This API is used to fetch and pay, after bill fetch this API is used for payment.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/payBillFetchPayBill"
    },
    {
        "ApiId": "642",
        "ApiDomain": "Payments",
        "ApiName": "Pay Bill (Pay Only)",
        "ApiDesc": "This API is used to payment for pay only amount.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/payBillPayOnly"
    },
    {
        "ApiId": "643",
        "ApiDomain": "Payments",
        "ApiName": "Get Customer Transactions",
        "ApiDesc": "This API is used to search previous transaction. This API will provide data either by transaction ref id directly or by mobile number.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getCustomerTransactions"
    },
    {
        "ApiId": "644",
        "ApiDomain": "Payments",
        "ApiName": "Get Transaction Complaint Dispositions",
        "ApiDesc": "This API is used to fetch disposition list. These dispositions are used to raise transaction type complaint. ",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getTransactionComplaintDispositions"
    },
    {
        "ApiId": "645",
        "ApiDomain": "Payments",
        "ApiName": "Get Service Reasons ",
        "ApiDesc": "This API is used to fetch service reasons. These services are used to raise service type complaint.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getServiceReasons"
    },
    {
        "ApiId": "646",
        "ApiDomain": "Payments",
        "ApiName": "Get Complaint Status",
        "ApiDesc": "This API is used to fetch complaint status which already raised. Both the service and transaction type complaint can be searched using this API.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getComplaintStatus"
    },
    {
        "ApiId": "647",
        "ApiDomain": "Payments",
        "ApiName": "Raise Complaint",
        "ApiDesc": "This API is used to raise complaint. Both type of complaint (service & transaction) can be raised by this single API.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/raiseComplaint"
    },
    {
        "ApiId": "648",
        "ApiDomain": "Payments",
        "ApiName": "Get All Billers (All Biller List)",
        "ApiDesc": "This API is used to provide basic information of all BBPS billers.",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/v0/getAllBillers"
    },
    {
        "ApiId": "701",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Direct FD Creation",
        "ApiDesc": "This API is used to verify OTP. On successful verification it will create FD, as per type of FD’s.",
        "ApiSubDomain": "Fixed Deposit",
        "SandboxUrl": "api/v0/directFDCreation"
    },
    {
        "ApiId": "702",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "FD Creation",
        "ApiDesc": "This API is used to create FD, as per type of FD’s.",
        "ApiSubDomain": "Fixed Deposit",
        "SandboxUrl": "api/v0/fdCreation"
    },
    {
        "ApiId": "703",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "View FD Details",
        "ApiDesc": "This API is used to view FD numbers.",
        "ApiSubDomain": "Fixed Deposit",
        "SandboxUrl": "api/v0/viewFdDetails"
    },
    {
        "ApiId": "704",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "FD Closure",
        "ApiDesc": "This API is used to Closing FD/RD Account ",
        "ApiSubDomain": "Fixed Deposit",
        "SandboxUrl": "api/v0/fdClosure"
    },
    {
        "ApiId": "705",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "RD Creation",
        "ApiDesc": "This service will validate OTP entered by customer. On successful validation create RD using inputs provided by customer such as account no, amount, tenure and installment start date",
        "ApiSubDomain": "Recurring Deposit",
        "SandboxUrl": "api/v0/rdCreation"
    },
    {
        "ApiId": "706",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "RD Closure",
        "ApiDesc": "This API is used to Close  RD Account ",
        "ApiSubDomain": "Recurring Deposit",
        "SandboxUrl": "api/v0/rdClosure"
    },
    {
        "ApiId": "707",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "View RD Details",
        "ApiDesc": "This API is used to view  RD numbers.",
        "ApiSubDomain": "Recurring Deposit",
        "SandboxUrl": "api/v0/viewRDdDetails"
    },
    {
        "ApiId": "708",
        "ApiDomain": "Business Banking",
        "ApiName": "Registration",
        "ApiDesc": "This API is used for registration of company account with partner/aggregator.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/Registration/SV"
    },
    {
        "ApiId": "709",
        "ApiDomain": "Business Banking",
        "ApiName": "Registration Status",
        "ApiDesc": "This API is used to check status of registration of company account with partner/aggregator.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/RegistrationStatus/SV"
    },
    {
        "ApiId": "710",
        "ApiDomain": "Business Banking",
        "ApiName": "Registration callback",
        "ApiDesc": "This API is used to send automatic update on successful registration of company account with partner/aggregator.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/registrationcallback"
    },
    {
        "ApiId": "711",
        "ApiDomain": "Business Banking",
        "ApiName": "De-Registration ",
        "ApiDesc": "This API is used for deregistering the account.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/Deregistration/SV"
    },
    {
        "ApiId": "712",
        "ApiDomain": "Business Banking",
        "ApiName": "OTP Creation for Transaction ",
        "ApiDesc": "This API is used to create OTP which is used for transaction.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/Create/SV"
    },
    {
        "ApiId": "713",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction ",
        "ApiDesc": "This API is used to make payment with-in bank and outside bank (RTGS, NEFT, IMPS).",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/Transaction/SV"
    },
    {
        "ApiId": "714",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction Status",
        "ApiDesc": "This API is used for transaction inquiry.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/TransactionInquiry/SV"
    },
    {
        "ApiId": "715",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction Callback",
        "ApiDesc": "This API gives transaction status.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/TransactionCallback/SV"
    },
    {
        "ApiId": "716",
        "ApiDomain": "Business Banking",
        "ApiName": "Validate Registered Account",
        "ApiDesc": "This API is used for validating linked accounts.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/ValidateLinkedAccount/SV"
    },
    {
        "ApiId": "717",
        "ApiDomain": "Business Banking",
        "ApiName": "Fetch Register Mobile No",
        "ApiDesc": "This API is used for fetching the mobile number linked to the account",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/MobileFetch/SV"
    },
    {
        "ApiId": "718",
        "ApiDomain": "Business Banking",
        "ApiName": "Account Balance Fetch ",
        "ApiDesc": "This API is used for checking account balance.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/BalanceInquiry/SV"
    },
    {
        "ApiId": "719",
        "ApiDomain": "Business Banking",
        "ApiName": "Account Bank statement ",
        "ApiDesc": "This API is used to get bank statement.",
        "ApiSubDomain": "CIB",
        "SandboxUrl": "api/v0/corporate/CIB/AccountStatemant/SV"
    },
    {
        "ApiId": "720",
        "ApiDomain": "Business Banking",
        "ApiName": "InstaOD offer check ",
        "ApiDesc": "This API is to check for instant unsecured business loan(Overdraft) facility on the basis of account number.",
        "ApiSubDomain": "Unsecured Overdraft",
        "SandboxUrl": "api/v0/corporate/CIB/lop/SV"
    },
    {
        "ApiId": "721",
        "ApiDomain": "Business Banking",
        "ApiName": "Avail Insta OD Offer",
        "ApiDesc": "This API provide URL to avail instant overdraft facility offered by bank.",
        "ApiSubDomain": "Unsecured Overdraft",
        "SandboxUrl": "api/v0/corporate/CIB/InstaOD/SV"
    },
    {
        "ApiId": "731",
        "ApiDomain": "Building Blocks",
        "ApiName": "Generate OTP",
        "ApiDesc": "This API will be used to create the OTP and the OTP will be send to customer Mobile Number.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/OTPCreation"
    },
    {
        "ApiId": "732",
        "ApiDomain": "Building Blocks",
        "ApiName": "OTP Verification",
        "ApiDesc": "This API will be used to verify the OTP.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/OTPVerification"
    },
    {
        "ApiId": "733",
        "ApiDomain": "Building Blocks",
        "ApiName": "Face Reader",
        "ApiDesc": "This API will be used in scanning face image and predict details such as smoker/non smoker, age etc.  ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/faceScanDataUri"
    },
    {
        "ApiId": "734",
        "ApiDomain": "Building Blocks",
        "ApiName": "Imager Reader",
        "ApiDesc": "This API is used in reading text from image",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/faceUpdate"
    },
    {
        "ApiId": "735",
        "ApiDomain": "Building Blocks",
        "ApiName": "State Master Population Service",
        "ApiDesc": "This API will get the list of state master data.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/stateMasterPopulationService"
    },
    {
        "ApiId": "736",
        "ApiDomain": "Building Blocks",
        "ApiName": "City Master Population Service",
        "ApiDesc": "This API will give city master data.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/cityMasterPopulationService"
    },
    {
        "ApiId": "739",
        "ApiDomain": "Building Blocks",
        "ApiName": "Aadhar OTP generation",
        "ApiDesc": "This API is used to generate OTP for Aadhar",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/aadharOTPgeneration"
    },
    {
        "ApiId": "740",
        "ApiDomain": "Building Blocks",
        "ApiName": "Aadhar OTP verification",
        "ApiDesc": "This API is used for OTP verification for Aadhar.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/aadharOTPverification"
    },
    {
        "ApiId": "743",
        "ApiDomain": "Building Blocks",
        "ApiName": "CR Image Reader",
        "ApiDesc": "This API will be used to read the image and give data of image for KYC",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/CRImageReader"
    },
    {
        "ApiId": "744",
        "ApiDomain": "Building Blocks",
        "ApiName": "Search Company ID",
        "ApiDesc": "This API will be used to search result on the basis of company ID ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/searchCompanyID"
    },
    {
        "ApiId": "745",
        "ApiDomain": "Building Blocks",
        "ApiName": "Data Verification Initial Service ",
        "ApiDesc": "This API is used to process initial service for E-signing. ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/esignProcessInitialService"
    },
    {
        "ApiId": "746",
        "ApiDomain": "Building Blocks",
        "ApiName": "Data Verification Final service ",
        "ApiDesc": "This API is used to process final service for E-signing ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/EsignProcessFinalService"
    },
    {
        "ApiId": "749",
        "ApiDomain": "Building Blocks",
        "ApiName": "Activate Your Account",
        "ApiDesc": "Allows you to activate account that you have chosen.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/choiceYourAccount"
    },
    {
        "ApiId": "750",
        "ApiDomain": "Building Blocks",
        "ApiName": "Choose Your Account",
        "ApiDesc": "This API service is used to choose account number of users choice and blocks account number if it is available ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/chooseYourAccount"
    },
    {
        "ApiId": "751",
        "ApiDomain": "Building Blocks",
        "ApiName": "Customer Registration",
        "ApiDesc": "This API will create customer’s ID for a prospect of saving account.",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/customerIDCreation"
    },
    {
        "ApiId": "753",
        "ApiDomain": "Building Blocks",
        "ApiName": "Document Upload ",
        "ApiDesc": "OmniDocs is a file repository used to save documents, files and help in providing viewing restrictions as well. API makes it easier in pushing the document into OmniDocs using JSON request. ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/fileUpload"
    },
    {
        "ApiId": "754",
        "ApiDomain": "Building Blocks",
        "ApiName": "Data Insertion API",
        "ApiDesc": "These API specification document is used for data insertion in database received from customer. ",
        "ApiSubDomain": "New Customer Onboarding",
        "SandboxUrl": "api/v0/NewCustomerOnboading/TatVikPushData"
    },
    {
        "ApiId": "761",
        "ApiDomain": "Business Banking",
        "ApiName": "Payment Process (File upload)",
        "ApiDesc": "To upload payment files containing multiple transactions. Web service request can contain multiple files in one request as well.",
        "ApiSubDomain": "CMS payment",
        "SandboxUrl": "api/v0/paymentProcess"
    },
    {
        "ApiId": "762",
        "ApiDomain": "Business Banking",
        "ApiName": "Reverse MIS",
        "ApiDesc": "To fetch the Reverse MIS from Bank to Customer",
        "ApiSubDomain": "CMS payment",
        "SandboxUrl": "api/v0/reverseMIS"
    },
    {
        "ApiId": "763",
        "ApiDomain": "Business Banking",
        "ApiName": "Reverse MIS (MT940 & Multicash)",
        "ApiDesc": "To receive MT940/Multi-cash statements from Bank. one Request will fetch contents of one file only.",
        "ApiSubDomain": "CMS payment",
        "SandboxUrl": "api/v0/reverseMISMulticash"
    },
    {
        "ApiId": "764",
        "ApiDomain": "Business Banking",
        "ApiName": "Instant Fund Transfer",
        "ApiDesc": "To transfer funds from one ICICI account to another ICICI account. Each request allows one transaction only.",
        "ApiSubDomain": "CMS payment",
        "SandboxUrl": "api/v0/instantFundTransfer"
    },
    {
        "ApiId": "765",
        "ApiDomain": "Business Banking",
        "ApiName": "P2P - Person to Person Fund Transfer",
        "ApiDesc": "Enables funds transfer from remitter BC account to beneficiary account using MMID and Mobile Number.",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/personToPersonFundTransfer"
    },
    {
        "ApiId": "766",
        "ApiDomain": "Business Banking",
        "ApiName": "P2A - Person to Account Fund Transfer",
        "ApiDesc": "Enables funds transfer from remitter BC account to beneficiary account using IFSC and Account Number details of Beneficiary.",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/personToAccountFundTransfer"
    },
    {
        "ApiId": "767",
        "ApiDomain": "Business Banking",
        "ApiName": "IMPS MMID Inquiry",
        "ApiDesc": "This is inquiry transaction to know the status for MMID generation.",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/impsMMIDInquiry"
    },
    {
        "ApiId": "768",
        "ApiDomain": "Business Banking",
        "ApiName": "IMPS Transaction Inquiry",
        "ApiDesc": "This API will return the status of transaction specific to given Reference Retrieval Number.",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/impsTransactionHistory"
    },
    {
        "ApiId": "769",
        "ApiDomain": "Business Banking",
        "ApiName": "IMPS Transaction History",
        "ApiDesc": "This API will return transaction history details of last six month from today’s date for financial transactions.",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/impsTransactionInquiry"
    },
    {
        "ApiId": "770",
        "ApiDomain": "Business Banking",
        "ApiName": "Pagination",
        "ApiDesc": "This API is used  to populate details in multiple records",
        "ApiSubDomain": "Transaction Management",
        "SandboxUrl": "api/v0/Pagination"
    },
    {
        "ApiId": "771",
        "ApiDomain": "Business Banking",
        "ApiName": "Bene Validation",
        "ApiDesc": "This API is used to validate beneficiary details of corporate user id",
        "ApiSubDomain": "Transaction Management",
        "SandboxUrl": "api/v0/benevalidation"
    },
    {
        "ApiId": "801",
        "ApiDomain": "Building Blocks",
        "ApiName": "Bureau Check",
        "ApiDesc": "This API is used to check CIBIL Score.",
        "ApiSubDomain": "Bureau Check",
        "SandboxUrl": "api/v0/checkCibil"
    },
    {
        "ApiId": "802",
        "ApiDomain": "Building Blocks",
        "ApiName": "Eligibility Check",
        "ApiDesc": "This API is used to check loan eligibility of customer.",
        "ApiSubDomain": "Eligibility Check",
        "SandboxUrl": "api/v0/checkEligibility"
    },
    {
        "ApiId": "803",
        "ApiDomain": "Building Blocks",
        "ApiName": "PAN Validation",
        "ApiDesc": "This API is used to provide geographical details of user on successful PAN validation. This api is for internal ICICI bank checks only and is not for any external integrations.",
        "ApiSubDomain": "PAN Validation",
        "SandboxUrl": "api/v0/panValidation"
    },
    {
        "ApiId": "1009",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Goal Creation",
        "ApiDesc": "This API is used to create merchant goal.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/goalCreation"
    },
    {
        "ApiId": "1010",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "View Goal Service(Merchant)",
        "ApiDesc": "This API is used to view merchant goal.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/merchantViewGoalService"
    },
    {
        "ApiId": "1011",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Editing Goals Details(Merchant)",
        "ApiDesc": "This API is used to edit merchant goal.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/editingGoalsDetailsforMerchantSite"
    },
    {
        "ApiId": "1012",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Close Goal (Merchant)",
        "ApiDesc": "This API is used to close goal.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/closeGoalfromMerchantSite"
    },
    {
        "ApiId": "1013",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Transaction History",
        "ApiDesc": "This API is used to get transaction history.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/transactionHistory"
    },
    {
        "ApiId": "1014",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Adding Funds to a Goal",
        "ApiDesc": "This API is used to get transaction history.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/AaddingFundsToAGoal"
    },
    {
        "ApiId": "1015",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "To Enable Or Disable KTC",
        "ApiDesc": "iWish Chhota Savings is an enabler which helps you reach the target amount faster by rounding off your day-to-day transactions such as fund transfer or bill payments and auto investing the amount in your respective iWish.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/toEnableOrDisableKTC"
    },
    {
        "ApiId": "1016",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "KTC Transaction History",
        "ApiDesc": "This API is used to display the KTC transaction history.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/KTCTransacationHistory"
    },
    {
        "ApiId": "1101",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Credit Cards Get Offer",
        "ApiDesc": "This API is leveraged to Avail all the Credit Card offers available to the customer on the basis of Linked Mobile Number after OTP verification",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/creditCardGetOffer"
    },
    {
        "ApiId": "1102",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Details",
        "ApiDesc": "This API is leveraged to display all the details linked to the credit card depending upon the offer available to the customer. ",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "apil/v0/cardDetails"
    },
    {
        "ApiId": "1103",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Card Creation",
        "ApiDesc": "This API is leveraged to create the card as the final acceptance step.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": " api/v0/cardCreation"
    },
    {
        "ApiId": "1105",
        "ApiDomain": "Business Banking",
        "ApiName": "Validation Web Service",
        "ApiDesc": "This service will be used by Customer Service Centre(CSC) to fetch and validate the bills",
        "ApiSubDomain": "CMS Collection",
        "SandboxUrl": "api/v0/validationWebService"
    },
    {
        "ApiId": "1106",
        "ApiDomain": "Business Banking",
        "ApiName": "Receipting Web Service",
        "ApiDesc": "Service used by Customer Service Centre(CSC) to post transaction details to billers post collection of bill amount",
        "ApiSubDomain": "CMS Collection",
        "SandboxUrl": "api/v0/receiptingWebService"
    },
    {
        "ApiId": "1107",
        "ApiDomain": "Business Banking",
        "ApiName": "E-Collection MIS",
        "ApiDesc": "This API is used to send the e-collection transaction details to client and receive response from client for every transaction.",
        "ApiSubDomain": "CMS Collection",
        "SandboxUrl": "api/v0/eCollectionMIS"
    },
    {
        "ApiId": "1115",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Create Saving Account",
        "ApiDesc": "This API will create the saving account for customer and in response will share the account number.",
        "ApiSubDomain": "Savings Account",
        "SandboxUrl": "api/v0/SavingAccountCreateSavingAccount"
    },
    {
        "ApiId": "1116",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Create Current Account",
        "ApiDesc": "This API will create the current account for individual customer.",
        "ApiSubDomain": "Current Account",
        "SandboxUrl": "api/v0/CurrentAccountCreateCurrentAccount"
    },
    {
        "ApiId": "1117",
        "ApiDomain": "Trade Services",
        "ApiName": "Transaction Order",
        "ApiDesc": "This service is used to initiate a transaction request",
        "ApiSubDomain": "Remittance",
        "SandboxUrl": " api/v0/RemittanceTransactionOrder"
    },
    {
        "ApiId": "1118",
        "ApiDomain": "Trade Services",
        "ApiName": "Transaction Inquiry",
        "ApiDesc": "Partner use this service to know the actual status of transaction order",
        "ApiSubDomain": "Remittance",
        "SandboxUrl": "api/v0/RemittanceTransactionInquiry"
    },
    {
        "ApiId": "1119",
        "ApiDomain": "Trade Services",
        "ApiName": "Account Inquiry",
        "ApiDesc": "Partner initiate Account Enquiry request at ICICI to know the ICICI beneficiary name and Account Number is matching or not",
        "ApiSubDomain": "Remittance",
        "SandboxUrl": "api/v0/RemittanceAccountInquiry"
    },
    {
        "ApiId": "1120",
        "ApiDomain": "Trade Services",
        "ApiName": "Remittance  Balance Inquiry",
        "ApiDesc": "Partner initiate  Account Balance service to know the actual balance in the  account of the partner",
        "ApiSubDomain": "Remittance",
        "SandboxUrl": "api/v0/RemittanceBalanceInquiry"
    },
    {
        "ApiId": "1121",
        "ApiDomain": "Business Banking",
        "ApiName": "CDM Deposit",
        "ApiDesc": "This API is used to notify transaction completion details to client system.",
        "ApiSubDomain": "CDM",
        "SandboxUrl": "api/v0/depositAPI"
    },
    {
        "ApiId": "1122",
        "ApiDomain": "Business Banking",
        "ApiName": "CDM Validation",
        "ApiDesc": "This API is used to authenticate depositor and fetch depositor details from client system.",
        "ApiSubDomain": "CDM",
        "SandboxUrl": "api/v0/validationApi"
    },
    {
        "ApiId": "1123",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Return On Investment",
        "ApiDesc": "This API can be used to get return on investment on the basis of  account no, amount to be invested and tenure.",
        "ApiSubDomain": "Fixed Deposit",
        "SandboxUrl": "api/v0/returnOnInvestment"
    },
    {
        "ApiId": "1201",
        "ApiDomain": "Business Banking",
        "ApiName": "InstaIMPS",
        "ApiDesc": "This API is used to make IMPS payment process.",
        "ApiSubDomain": "InstaIMPS",
        "SandboxUrl": "api/v0/InstaIMPSProcess"
    },
    {
        "ApiId": "1202",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Offer Validation",
        "ApiDesc": "This API will be used for offers validation on the basis of mobile number.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/offerValidation"
    },
    {
        "ApiId": "1203",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Offer Confirmation",
        "ApiDesc": "This API will be used for offers confirmation[offer disburse] on the basis of mobile number.",
        "ApiSubDomain": "Personal Loan",
        "SandboxUrl": "api/v0/offerConfirmation"
    },
    {
        "ApiId": "1204",
        "ApiDomain": "Payments",
        "ApiName": "UPI",
        "ApiDesc": "This API will be used to make payment including priority order to identify and carry out UPI payments",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "api/v0/composite-payment"
    },
    {
        "ApiId": "1205",
        "ApiDomain": "Business Banking",
        "ApiName": "IMPS Tran Status",
        "ApiDesc": "This API will be used to check the transaction status for IMPS",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/imps/tran-status"
    },
    {
        "ApiId": "1206",
        "ApiDomain": "Trade Services",
        "ApiName": "Issuance API",
        "ApiDesc": "This API will fetch issuance SFMS details of the inward BG's from TOL.",
        "ApiSubDomain": "Electronic Bank Guarantee",
        "SandboxUrl": "api/v0/Issuance"
    },
    {
        "ApiId": "1207",
        "ApiDomain": "Trade Services",
        "ApiName": "Amendment API",
        "ApiDesc": "This API is used to fetch the amendment SFMS details for Inward BG from TOL.",
        "ApiSubDomain": "Electronic Bank Guarantee",
        "SandboxUrl": "api/v0/Amendment"
    },
    {
        "ApiId": "1208",
        "ApiDomain": "Trade Services",
        "ApiName": "Verify Bank Guarantee API",
        "ApiDesc": "This API will validate if the customer is a valid TOL customer.",
        "ApiSubDomain": "Electronic Bank Guarantee",
        "SandboxUrl": "api/v0/Verifybankguarantee"
    },
    {
        "ApiId": "1209",
        "ApiDomain": "Trade Services",
        "ApiName": "Outward Remittance",
        "ApiDesc": "Used to transfer funds in the form of Foreign Exchange from an entity in India, to a beneficiary outside India (except for Nepal and Bhutan), for any purpose as permissible under FEMA 1999. (FEMA: Foreign Exchange Management Act).",
        "ApiSubDomain": "Outward Remittance",
        "SandboxUrl": "api/v0/OutwardRemittance"
    },
    {
        "ApiId": "1211",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Account Discover",
        "ApiDesc": "This API is used to discover various accounts depending upon the input parameters (output parameters are masked)",
        "ApiSubDomain": "Account Aggregator",
        "SandboxUrl": "api/v0/FIP/accountDiscover"
    },
    {
        "ApiId": "1212",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Data Fetch",
        "ApiDesc": "This API is used to fetch user masked transaction information of the user on basis of mobile number for any external usage.",
        "ApiSubDomain": "Account Aggregator",
        "SandboxUrl": "api/v0/fetchdata"
    },
    {
        "ApiId": "1213",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OTP Creation ",
        "ApiDesc": "This API takes the mobile no and customer ID and sends the OTP to customer.",
        "ApiSubDomain": "Account Aggregator",
        "SandboxUrl": "api/v0/FIP/eOTP/create"
    },
    {
        "ApiId": "1214",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OTP Verification",
        "ApiDesc": "This API takes the OTP id, OTP and verifies and send success or failure with error codes.",
        "ApiSubDomain": "Account Aggregator",
        "SandboxUrl": "api/v0/FIP/eOTP/verify"
    },
    {
        "ApiId": "1215",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Convert Current account  to OD",
        "ApiDesc": "This API is used for converting current account (Type : Individual, proprietary) to OD account and updating of sanction limit , drawing power, calculation of Processing fee and updating of other parameters such as Interest rate, status code, MIS Code , Scheme code for account having pre-approved offer.",
        "ApiSubDomain": "Current Account",
        "SandboxUrl": "api/v0/CaOd"
    },
    {
        "ApiId": "1216",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OD Account creation from Current Account",
        "ApiDesc": "This API is used to create OD account as per the user details present for the current account number.",
        "ApiSubDomain": "Current Account",
        "SandboxUrl": "api/v0/ODAccountCreation"
    },
    {
        "ApiId": "1217",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "InstaOD Guest login",
        "ApiDesc": "InstaOD guest login is to cater to New to Bank customers who will first avail InstaOD",
        "ApiSubDomain": "OD",
        "SandboxUrl": "api/v0/guestlogin/SES"
    },
    {
        "ApiId": "1218",
        "ApiDomain": "Business Banking",
        "ApiName": "IMPS Fund Transfer",
        "ApiDesc": "This API is used for fund transfer via Immediate Mobile Payment System",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/FundTransfer"
    },
    {
        "ApiId": "1219",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Get Saving Account details",
        "ApiDesc": "This API will return the saving account numbers on the basis of registered mobile number and date of birth.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/getsavingaccountdetails"
    },
    {
        "ApiId": "1220",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Loan Creation for existing Account holder and Auto debit.",
        "ApiDesc": "This API will allow user to create loan account for existing icici bank customer.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/loancreation for existingaccountholder"
    },
    {
        "ApiId": "1221",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Loan Creation ",
        "ApiDesc": "This API will allow user to create loan account.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/loancreation"
    },
    {
        "ApiId": "1222",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Loan disbursement",
        "ApiDesc": "This API allows user to create disbursement of loan amount.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/loandisbursement"
    },
    {
        "ApiId": "1223",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Amortization Schedule",
        "ApiDesc": "This API will return repayment schedule for loan account.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/AmortizationSchedule"
    },
    {
        "ApiId": "1224",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Account Inquiry",
        "ApiDesc": "This API user will get Loan details.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/AccountInquiry"
    },
    {
        "ApiId": "1225",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Bill Inquiry",
        "ApiDesc": "This API will provide bill details of loan Account no.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/Billinquiry"
    },
    {
        "ApiId": "1226",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Re-Payment of loan",
        "ApiDesc": "This API loan repayment process is done and transaction id is provided in response for successful transaction.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/Repaymentofloan"
    },
    {
        "ApiId": "1227",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Foreclosure amount",
        "ApiDesc": "This API interest calculation is done then account inquiry api called to check the account balance.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/Foreclosureamount"
    },
    {
        "ApiId": "1228",
        "ApiDomain": "Loans And Cards",
        "ApiName": "Account closure",
        "ApiDesc": "This API is used to close the loan account.",
        "ApiSubDomain": "paylater",
        "SandboxUrl": "api/v0/accountclosure"
    },
    {
        "ApiId": "1229",
        "ApiDomain": "Business Banking",
        "ApiName": "E-Collection Message Holding",
        "ApiDesc": "This Api is used to check the transaction validation",
        "ApiSubDomain": "CMS Collection",
        "SandboxUrl": "api/v0/eCollectionMessageHolding"
    },
    {
        "ApiId": "1230",
        "ApiDomain": "Business Banking",
        "ApiName": "Bene Registration",
        "ApiDesc": "This API is used to Register a Benificaiary in the Current Account",
        "ApiSubDomain": "Transaction Management",
        "SandboxUrl": "api/v0/Beneregistration"
    },
    {
        "ApiId": "1231",
        "ApiDomain": "Business Banking",
        "ApiName": "Cash Deposit ",
        "ApiDesc": "This API is use for cash solutions for corporate, Door Step Banking (DSB) is the product offered by Transaction Banking wherein cash has been collected by DSB agents from customer offices, shop & getting deposited in the bank",
        "ApiSubDomain": "Door Step Banking",
        "SandboxUrl": "api/v0/CashDepositBC"
    },
    {
        "ApiId": "1232",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Fund Transfer - Debit",
        "ApiDesc": "This API is used to debit the fund from customer's ICICI bank account and credit the fund to ICICI bank escrow/pool Account",
        "ApiSubDomain": "Saving Account",
        "SandboxUrl": "api/v0/fundTransfer"
    },
    {
        "ApiId": "1233",
        "ApiDomain": "Payments",
        "ApiName": "E - Payment File Upload",
        "ApiDesc": "This API will help to submit beneficiary details and amount for payment through multiple modes like NEFT,RTGS, Fund Transfer and IMPS. Client will sent request to ICICI Bank  to get response.",
        "ApiSubDomain": "od",
        "SandboxUrl": "api/v0/E-PaymentFileUpload"
    },
    {
        "ApiId": "1234",
        "ApiDomain": "Building Blocks",
        "ApiName": "Document Upload",
        "ApiDesc": "Document Upload is a file repository used to save documents, files and help in providing viewing restrictions as well. API makes it easier in pushing the document into OmniDocs using JSON request",
        "ApiSubDomain": "Document Upload",
        "SandboxUrl": "api/v0/docUpload"
    },
    {
        "ApiId": "1235",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch UserID",
        "ApiDesc": "User id of the requested mobile number",
        "ApiSubDomain": "Accounting Services ",
        "SandboxUrl": "api/v0/fetchUserID"
    },
    {
        "ApiId": "1236",
        "ApiDomain": "Building Blocks",
        "ApiName": "Customer Handshake",
        "ApiDesc": "This service is used to verify the customer details",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v0/NewCustomerOnboarding/CustomerHandshake"
    },
    {
        "ApiId": "1237",
        "ApiDomain": "Building Blocks",
        "ApiName": "WaitCallTime",
        "ApiDesc": "This api gives callwaittime details in response based on groupid",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v0/NewCustomerOnboarding/WaitCallTime"
    },
    {
        "ApiId": "1238",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Details By TrackingID",
        "ApiDesc": "This api gives the status details based on tracking ID  on groupid",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v0/NewCustomerOnboarding/getdetailsbytrackingid"
    },
    {
        "ApiId": "1239",
        "ApiDomain": "Business banking",
        "ApiName": "NEFT incremental status",
        "ApiDesc": "This API is created to get the NEFT incremental status. Client can get the status by putting request on the basis of UTR number received in the transaction API response. The UTR number received in the transaction inquiry is passed in input URL. The transaction status for the input is fetched from SFMS after validating the Aggregator details.",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v0/CIBNEFTStatus"
    },
    {
        "ApiId": "1240",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Block ATM Withdrawals",
        "ApiDesc": "This API is used to block the ATM Cash withdrawal on card. No authorization header is required to invoke this api.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/block-atm-withdrawals"
    },
    {
        "ApiId": "1241",
        "ApiDomain": "Loans and cards",
        "ApiName": "Unblock ATM Withdrawals ",
        "ApiDesc": "This api is used to unblock the ATM Cash withdrawal on card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/unblock-atm-withdrawals"
    },
    {
        "ApiId": "1242",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Block International Transactions",
        "ApiDesc": "This API is used to block the International Txn on card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/block-international-transactions"
    },
    {
        "ApiId": "1243",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Unblock International Transactions",
        "ApiDesc": "This api is used to unblock the International Txn on card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/unblock-international-transactions"
    },
    {
        "ApiId": "1244",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Block Online Transactions",
        "ApiDesc": "This api is used to block the Online Txn on card",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/block-online-transactions"
    },
    {
        "ApiId": "1245",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Unblock Online Transactions",
        "ApiDesc": "This api is used to unblock the Online Txn on card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/unblock-online-transactions"
    },
    {
        "ApiId": "1246",
        "ApiDomain": "Loans and Cards",
        "ApiName": "View Reward Points",
        "ApiDesc": "This api is used to display Reward point balance on card fetched from PRIME.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/view-reward-points"
    },
    {
        "ApiId": "1247",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Available Credit Limit.",
        "ApiDesc": "This API is used to find out available limit of credit card",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/dealerregistration"
    },
    {
        "ApiId": "1248",
        "ApiDomain": "Loans and Cards",
        "ApiName": "View Statement",
        "ApiDesc": "This API will be used for checking the mini statement of customer.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/mini-stmt"
    },
    {
        "ApiId": "1249",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Block Card",
        "ApiDesc": "This API will be used to block the debit or credit card temporary or permanently.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/blockcard"
    },
    {
        "ApiId": "1250",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Unblock Card.",
        "ApiDesc": "This API will be used to unblock the debit or credit card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v0/blockcard"
    },
    {
        "ApiId": "1251",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Wallet Creation API",
        "ApiDesc": "This API is used for creating wallet",
        "ApiSubDomain": "Pockets",
        "SandboxUrl": "api/v0/WalletCreation"
    },
    {
        "ApiId": "1252",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Add Funds API",
        "ApiDesc": "  This API is used for funding wallet based on mobile number.",
        "ApiSubDomain": "Pockets",
        "SandboxUrl": "api/v0/AddFunds"
    },
    {
        "ApiId": "1253",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Card Debit API",
        "ApiDesc": "This API is used to debit the wallet based on mobile number.",
        "ApiSubDomain": "Pockets",
        "SandboxUrl": "api/v0/CardDebit"
    },
    {
        "ApiId": "1254",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Transaction Enquiry API",
        "ApiDesc": "This API is used for checking the status of a transaction.",
        "ApiSubDomain": "Pockets",
        "SandboxUrl": "api/v0/TransactionEnquiry"
    },
    {
        "ApiId": "1255",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Mini Statement API",
        "ApiDesc": "This API will return list of last transactions.",
        "ApiSubDomain": "Pockets",
        "SandboxUrl": "api/v0/MiniStatement"
    },
    {
        "ApiId": "1256",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Detailed Statement API",
        "ApiDesc": "This API will be used to get detailed statement of transaction.",
        "ApiSubDomain": "Pockets",
        "SandboxUrl": "api/v0/DetailedStatement"
    },
    {
        "ApiId": "1270",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OD Account Creation",
        "ApiDesc": "This API will allow user to create OD account.",
        "ApiSubDomain": "OD Account",
        "SandboxUrl": "api/v0/ODAccCreation"
    },
    {
        "ApiId": "1271",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Debit OD Account",
        "ApiDesc": "This API user will debit OD account.",
        "ApiSubDomain": "OD Account",
        "SandboxUrl": "api/v0/odManagementDebit"
    },
    {
        "ApiId": "1272",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OD Balance Inquiry",
        "ApiDesc": "This API is used get the balance details for an OD account.",
        "ApiSubDomain": "OD Account",
        "SandboxUrl": "api/v0/odManagementBalanceInquiry"
    },
    {
        "ApiId": "1273",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OD Bill Inquiry",
        "ApiDesc": "This API is used get the bill details for an OD account.",
        "ApiSubDomain": "OD Account",
        "SandboxUrl": "api/v0/odManagementBillInquiry"
    },
    {
        "ApiId": "1274",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Credit OD Account",
        "ApiDesc": "This API user will credit the OD account.",
        "ApiSubDomain": "OD Account",
        "SandboxUrl": "api/v0/odManagementCredit"
    },
    {
        "ApiId": "1275",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OD Account Closure",
        "ApiDesc": "This API is used to close the OD account.",
        "ApiSubDomain": "OD Account",
        "SandboxUrl": "api/v0/odManagementAccountClosure"
    },
    {
        "ApiId": "1276",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "CIB Registration",
        "ApiDesc": "This API is used to register current account details in CIB.",
        "ApiSubDomain": "Current Account  ",
        "SandboxUrl": "api/v0/CIBRegistration"
    },
    {
        "ApiId": "1277",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get KYC Status",
        "ApiDesc": "This API is use to get KYC status of existing customer having saving account.",
        "ApiSubDomain": "Savings Account  ",
        "SandboxUrl": "api/v0/GetKYCStatus"
    },
    {
        "ApiId": "1278",
        "ApiDomain": "Business Banking",
        "ApiName": "Transactions Reporting for DSB",
        "ApiDesc": " This API is used for transactions upload & transactions modification through API Gateway. ",
        "ApiSubDomain": "Door Step Banking",
        "SandboxUrl": "api/v0/transactionsreportingforDSB"
    },
    {
        "ApiId": "1279",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Enable KTC",
        "ApiDesc": "This API is used to enabling KTC",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/EnableKTC"
    },
    {
        "ApiId": "1280",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "KTC Transaction History",
        "ApiDesc": "This API is used to get the KTC transaction history.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/KTCTransactionHistory"
    },
    {
        "ApiId": "1281",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OTP Authentication",
        "ApiDesc": "If the OTPGenerated flag is ‘Y’ in any iWish API response. Partner should use thisAPI for OTP authentication process.",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/OTPAuthentication(iwish)"
    },
    {
        "ApiId": "1282",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "UPI Collect Pay",
        "ApiDesc": "After hitting the below request customer will get the upi payment request to his upi mobile app. He has to approve the payment request by entering the UPI pin",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/UPICollectPay"
    },
    {
        "ApiId": "1283",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "UPI Transaction Status",
        "ApiDesc": "Use this service to check the status of the upi transaction",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/UPITransactionStatus"
    },
    {
        "ApiId": "1284",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "FD Interest Rate",
        "ApiDesc": "This api is to get the FD Interest Rate",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/FDInterestRate"
    },
    {
        "ApiId": "1285",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "RD Interest Rate",
        "ApiDesc": "This api is to get the RD Interest Rate",
        "ApiSubDomain": "iWish",
        "SandboxUrl": "api/v0/RDInterestRate"
    },
    {
        "ApiId": "1286",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OnBasisOfCompanyname",
        "ApiDesc": "This service is used to get details of desired company’s details based on first three characters.",
        "ApiSubDomain": "Current Account",
        "SandboxUrl": "api/v0/OnTheBesisOfCINNumber"
    },
    {
        "ApiId": "1287",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "OnBasisOfCINNumber",
        "ApiDesc": "This service is used to get desired company’s details such as PAN number, registered address, List of\ndirectories, and GSTIN number",
        "ApiSubDomain": "Current Account",
        "SandboxUrl": "api/v0/OnTheBesisOfCompanyName"
    },
    {
        "ApiId": "1288",
        "ApiDomain": "Building Blocks",
        "ApiName": "Browse Plan API",
        "ApiDesc": "This API is used to get plan details for the requested mobile number.",
        "ApiSubDomain": "Mobile Recharge",
        "SandboxUrl": "api/v1/browsePlans"
    },
    {
        "ApiId": "1289",
        "ApiDomain": "Building Blocks",
        "ApiName": "Operator Validation",
        "ApiDesc": "This API is use to select Plan ",
        "ApiSubDomain": "Mobile Recharge",
        "SandboxUrl": "api/v1/MobileRecharge"
    },
    {
        "ApiId": "1290",
        "ApiDomain": "Building Blocks",
        "ApiName": " Mobile Recharge",
        "ApiDesc": "This API is used for recharge of customer mobile.",
        "ApiSubDomain": "Mobile Recharge",
        "SandboxUrl": "api/v1/OperatorValidation"
    },
    {
        "ApiId": "1291",
        "ApiDomain": "Payments",
        "ApiName": "P2P- Person to Person Fund Transfer",
        "ApiDesc": "This API will support to initiate a fund transfer request to payee using Mobile Number + MMID.",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/imps_p2p"
    },
    {
        "ApiId": "1292",
        "ApiDomain": "Payments",
        "ApiName": "P2A - Person to Account Fund Transfer",
        "ApiDesc": "This API will support to initiate a fund transfer request to payee using Mobile Number + MMID",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/imps_p2a"
    },
    {
        "ApiId": "1293",
        "ApiDomain": "Payments",
        "ApiName": "Transactional Inquiry",
        "ApiDesc": "API will return the status of the transaction based on the “TranRefNo” of the original transaction (for status - success, reject or timeout).",
        "ApiSubDomain": "IMPS",
        "SandboxUrl": "api/v0/IMPS_Status"
    },
    {
        "ApiId": "1294",
        "ApiDomain": "Payments",
        "ApiName": "Recharge Vehicle Balance",
        "ApiDesc": "This API method can be used to recharge the vehicle(s) by Customer using the CUG Wallet Balance.",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/RechargeVehicleBalance"
    },
    {
        "ApiId": "1295",
        "ApiDomain": "Payments",
        "ApiName": "Get Vehicles List",
        "ApiDesc": "This API method is specific to Customer app and is used to get the list of Vehicles of the requested customer. If Customer has more than 50 vehicles, the response will be paginated into multiple pages with each page consisting of 50 vehicles",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/GetVehicles"
    },
    {
        "ApiId": "1296",
        "ApiDomain": "Payments",
        "ApiName": "Customer Recharge",
        "ApiDesc": "This API method used to recharge at customer end for Tag Account of a vehicle or CUG Wallet.For One Wallet Customers it recharges the One Wallet",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/CustomerRecharge"
    },
    {
        "ApiId": "1297",
        "ApiDomain": "Payments",
        "ApiName": "Get Transaction Details",
        "ApiDesc": "This API method returns the transaction details of the requested vehicle number of a Customer for the given duration. This API request accepts Customer ID (mandatory) & vehicle number (optional) to return the Transaction details. ",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/GetTransactionDetails"
    },
    {
        "ApiId": "1298",
        "ApiDomain": "Payments",
        "ApiName": "Get Transaction by Posted Date",
        "ApiDesc": "This API fetches trips\\Transactions (of both normal and one wallet customer) based on Transaction Posted Date (The date which the actual transaction is performed).",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/GetTransactionsByPostedDate"
    },
    {
        "ApiId": "1299",
        "ApiDomain": "Payments",
        "ApiName": "One Wallet Credit Transactions",
        "ApiDesc": "This API fetches the credit transactions of a one wallet customer (includes internal transfers as well)",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/OneWalletCreditTransactions"
    },
    {
        "ApiId": "1300",
        "ApiDomain": "Payments",
        "ApiName": "Get TAG Account Credit Transactions",
        "ApiDesc": "This API method returns the Credit transactions\\Recharge details for the requested Customer ID and Vehicle number in a given duration.  The details can be requested only for a single vehicle number.",
        "ApiSubDomain": "FASTag",
        "SandboxUrl": "api/v0/ISRCUSTAPI/Customer/TAGAccountCreditTransactions"
    },
    {
        "ApiId": "1301",
        "ApiDomain": "Payments",
        "ApiName": "PayLater A/c Discovery",
        "ApiDesc": "This API will allow user to get account details.",
        "ApiSubDomain": "Paylater",
        "SandboxUrl": "api/v0/PayLaterAccountDiscovery"
    },
    {
        "ApiId": "1302",
        "ApiDomain": "Payments",
        "ApiName": "Balance Inquiry",
        "ApiDesc": "This API will allow user to get account balance.",
        "ApiSubDomain": "Paylater",
        "SandboxUrl": "api/v0/Balance Inquiry"
    },
    {
        "ApiId": "1303",
        "ApiDomain": "Payments",
        "ApiName": "Debit Orchestration",
        "ApiDesc": "This API is used to get information about all debit transactions initiated from Merchant platform using PayLater A/c.",
        "ApiSubDomain": "Paylater",
        "SandboxUrl": "api/v0/Debit Orchestration"
    },
    {
        "ApiId": "1304",
        "ApiDomain": "Business Banking",
        "ApiName": "POS Onboarding Status Check API",
        "ApiDesc": "This API  allows the merchant to check the status of a particular onboarding request.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v1/EazypayPOS?service=OnboardingStatusCheck"
    },
    {
        "ApiId": "1305",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction Initiation API",
        "ApiDesc": "This API allows merchants to initiate a transaction on a POS terminal.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v1/EazypayPOS?service=TransactionThroughPOS"
    },
    {
        "ApiId": "1306",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction Status Check API",
        "ApiDesc": "This API allows the merchant to check status of a POS terminal transaction.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v1/EazypayPOS?service=TransactionStatusCheck"
    },
    {
        "ApiId": "1307",
        "ApiDomain": "Business Banking",
        "ApiName": "POS Onboarding Immediate Callback",
        "ApiDesc": "This callback API is used to send response regarding status of the onboarding request.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/POSOnboardIMRCallback"
    },
    {
        "ApiId": "1308",
        "ApiDomain": "Business Banking",
        "ApiName": "POS Onboarding Installation callback",
        "ApiDesc": "This callback API is used to send respose from Eazypay regarding installation status of the terminal.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/POSOnboardINRcallback"
    },
    {
        "ApiId": "1309",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction Status Callback",
        "ApiDesc": "This callback API is used to send the status of a POS terminal transaction from Eazypay to merchant.",
        "ApiSubDomain": "Eazypay",
        "SandboxUrl": "api/v0/TransactionResponseCallback"
    },
    {
        "ApiId": "1310",
        "ApiDomain": "Building Blocks",
        "ApiName": "Challan Download",
        "ApiDesc": "This API is used to download challan.",
        "ApiSubDomain": "Direct Tax",
        "SandboxUrl": "api/v0/ChallanDownload"
    },
    {
        "ApiId": "1311",
        "ApiDomain": "Building Blocks",
        "ApiName": "Payment Process",
        "ApiDesc": "This API is used to initiate Direct Tax payment.",
        "ApiSubDomain": "Direct Tax",
        "SandboxUrl": "api/v0/PaymentProcess"
    },
    {
        "ApiId": "1312",
        "ApiDomain": "Building Blocks",
        "ApiName": "Verification",
        "ApiDesc": "This API is used to verify Payment details.",
        "ApiSubDomain": "Direct Tax",
        "SandboxUrl": "api/v0/Verification\n\n"
    },
    {
        "ApiId": "1313",
        "ApiDomain": "Building Blocks",
        "ApiName": "GST-Enquiry Request",
        "ApiDesc": "This API is used to Validate GST. ",
        "ApiSubDomain": "GST",
        "SandboxUrl": "api/v0/GST-EnquiryRequest"
    },
    {
        "ApiId": "1314",
        "ApiDomain": "Building Blocks",
        "ApiName": "GST-Payment Process",
        "ApiDesc": "This API is used  to initiate GST Tax.",
        "ApiSubDomain": "GST",
        "SandboxUrl": "api/v0/GST-PaymentProcess"
    },
    {
        "ApiId": "1315",
        "ApiDomain": "Building Blocks",
        "ApiName": "GST-Verification",
        "ApiDesc": "This API is used to verify Payment.",
        "ApiSubDomain": "GST",
        "SandboxUrl": "api/v0/GST-Verification"
    },
    {
        "ApiId": "1316",
        "ApiDomain": "Building Blocks",
        "ApiName": "GST-challan Download",
        "ApiDesc": "This API is used to download GST.",
        "ApiSubDomain": "GST",
        "SandboxUrl": "api/v0/GST-ChallanDownload"
    },
    {
        "ApiId": "1317",
        "ApiDomain": "Payments",
        "ApiName": "IMPS",
        "ApiDesc": "This API will be used to make payment including priority order to identify and carry out IMPS payments",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "api/v0/composite-payment"
    },
    {
        "ApiId": "1318",
        "ApiDomain": "Payments",
        "ApiName": "NEFT",
        "ApiDesc": "This API will be used to make payment including priority order to identify and carry out NEFT payments",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "api/v0/composite-payment"
    },
    {
        "ApiId": "1319",
        "ApiDomain": "Payments",
        "ApiName": "RTGS",
        "ApiDesc": "This API will be used to make payment including priority order to identify and carry out RTGS payments",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "api/v0/composite-payment"
    },
    {
        "ApiId": "1320",
        "ApiDomain": "Building Blocks",
        "ApiName": "Transaction Status Check",
        "ApiDesc": "This API is used to check Transaction Status",
        "ApiSubDomain": "Mobile Recharge"
    },
    {
        "ApiId": "1321",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "LOP Offer Fetch",
        "ApiDesc": "This API is used to check OD offers on given mobile number",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/AcctDiscover/OfferFetch"
    },
    {
        "ApiId": "1322",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Promoter details",
        "ApiDesc": "This API is used  to fetch Entity and their individual details based on the Current Account number",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/DemogFetch"
    },
    {
        "ApiId": "1323",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Initiate Transaction API",
        "ApiDesc": "This API is used to initiate trasaction of Bank statement upload with Perfios, on real time basis",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/perfios/initiateTransaction"
    },
    {
        "ApiId": "1324",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Bank Statement Upload",
        "ApiDesc": "This API is used to upload PDF Bank statements, of last 12 months, to generate an analysis report",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/perfios/uploadStatement"
    },
    {
        "ApiId": "1325",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Process Report Generation",
        "ApiDesc": "This API is used to complete the Bank statement upload process and initiate the analysis process",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/perfios/reportGenerator"
    },
    {
        "ApiId": "1326",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Karza - Partnership and Company",
        "ApiDesc": "This API is used to fetch Entity and their individual details based on the PAN, for New to bank customers",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/karja"
    },
    {
        "ApiId": "1327",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "SAtoOD",
        "ApiDesc": "This API is used to open OD account based on Savings account details",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/ODAccCreate"
    },
    {
        "ApiId": "1328",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "File upload",
        "ApiDesc": "This API is used to store Customer documents used in OD availing process, in omnidocs folder",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/docs"
    },
    {
        "ApiId": "1329",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Dashboard Get Account balance icore",
        "ApiDesc": "This API is used to to get the account details based on OD account number",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/ODAccountInquiry"
    },
    {
        "ApiId": "1330",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "PA Offer validation",
        "ApiDesc": "API to check customer eligibility, based on Bureau, after the Partner/Director details of the Entity have been modified",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/PAOffervalidation"
    },
    {
        "ApiId": "1331",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "PQ NTB sanction API",
        "ApiDesc": "API to check sanction eligibility with offer details for Pre-qualified and New to bank customers",
        "ApiSubDomain": "Unsecured Loan APIs",
        "SandboxUrl": "api/v0/PQNTBsanctionAPI"
    },
    {
        "ApiId": "1332",
        "ApiDomain": "Business Banking",
        "ApiName": "Offer check",
        "ApiDesc": "This API can be used to fetch pre-approved ICICI Bank OD offer and customer details based on given mobile number",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/lopDemogFetch"
    },
    {
        "ApiId": "1333",
        "ApiDomain": "Business Banking",
        "ApiName": "New customer information",
        "ApiDesc": "This API can be used to fetch non-ICICI customer details based on PAN, using publicly available APIs",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "/api/v1/karja"
    },
    {
        "ApiId": "1334",
        "ApiDomain": "Business Banking",
        "ApiName": "Customer details modification",
        "ApiDesc": "This API can be used for getting sanction status of the customer, with pre-approved ICICI OD offer, after modifying the details",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/PAOfferValidation"
    },
    {
        "ApiId": "1335",
        "ApiDomain": "Business Banking",
        "ApiName": "Bank statement (i)",
        "ApiDesc": "This API initiates the process of Bank statement upload by generating a unique transaction ID.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v2/perfios/initiateTransaction"
    },
    {
        "ApiId": "1336",
        "ApiDomain": "Business Banking",
        "ApiName": "Bank statement (ii)",
        "ApiDesc": "This API can be used to upload PDF bank statements in base64 format, using unique transaction ID received in part (i).",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v2/perfios/uploadStatement"
    },
    {
        "ApiId": "1337",
        "ApiDomain": "Business Banking",
        "ApiName": "Bank statement (iii)",
        "ApiDesc": "This API completes the process of Bank statement upload and initiates the analysis process",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v2/perfios/reportGenerator"
    },
    {
        "ApiId": "1338",
        "ApiDomain": "Business Banking",
        "ApiName": "Instant Sanction",
        "ApiDesc": "This API can be used for getting instant sanction for ICICI Bank OD based on customer's already uploaded Bank statement and Bureau records.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/check-eligibility"
    },
    {
        "ApiId": "1339",
        "ApiDomain": "Business Banking",
        "ApiName": "Instant Disbursement",
        "ApiDesc": "This API can be used to complete T&C acceptance and provide instant Disbursement to customers with pre-approved ICICI Bank OD offer.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/dataStorage"
    },
    {
        "ApiId": "1340",
        "ApiDomain": "Business Banking",
        "ApiName": "Data fetch",
        "ApiDesc": "This API can be used to complete T&C acceptance and provide instant Disbursement to new to bank customer after they have opened a new current account with ICICI Bank",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/lendingPlatform/dataFetch "
    },
    {
        "ApiId": "1341",
        "ApiDomain": "Business Banking",
        "ApiName": "Mini Statement",
        "ApiDesc": "This API will be used for checking the mini statement of customer.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/mini-stmt "
    },
    {
        "ApiId": "1342",
        "ApiDomain": "Business Banking",
        "ApiName": "File sharing",
        "ApiDesc": "This API makes it easier in pushing the document into OmniDocs using JSON request.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/docs"
    },
    {
        "ApiId": "1343",
        "ApiDomain": "Business Banking",
        "ApiName": "Dashboard ",
        "ApiDesc": "This API is used to get the account details of OD account.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/ODAccountInquiry"
    },
    {
        "ApiId": "1344",
        "ApiDomain": "Business Banking",
        "ApiName": "Status Check",
        "ApiDesc": "This API is used to check the status.",
        "ApiSubDomain": "Business Lending Products",
        "SandboxUrl": "api/v1/lendingPlatform/disbStatusCheck"
    },
    {
        "ApiId": "1349",
        "ApiDomain": "Business Banking",
        "ApiName": "Transaction Alerts",
        "ApiDesc": "This API can be used to get transaction alerts.",
        "ApiSubDomain": "Collections",
        "SandboxUrl": "api/v1/TransactionAlerts​"
    },
    {
        "ApiId": "1350",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Prime Credit Card",
        "ApiDesc": "This API is used for retrieving customer details",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "api/v1/creditCards"
    },
    {
        "ApiId": "1351",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Account Validation",
        "ApiDesc": "This API is used For Fetching account details, GST details, IFSC details based on Account number",
        "ApiSubDomain": "Accounts and Deposits",
        "SandboxUrl": "api/v1/accountvalidationFI"
    },
    {
        "ApiId": "1352",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Eligibility",
        "ApiDesc": "This API is used to check the Eligibility .",
        "ApiSubDomain": "Cardless EMI",
        "SandboxUrl": "api/v1/cardless-emi/eligibility"
    },
    {
        "ApiId": "1353",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Validation",
        "ApiDesc": "This API is use for validation",
        "ApiSubDomain": "Cardless EMI",
        "SandboxUrl": "api/v1/cardless-emi/validation"
    },
    {
        "ApiId": "1354",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Confirmation",
        "ApiDesc": "API is used to get Confirmation",
        "ApiSubDomain": "Cardless EMI",
        "SandboxUrl": "api/v1/cardless-emi/confirmation"
    },
    {
        "ApiId": "1355",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Cancellation",
        "ApiDesc": "This API is used for Cancellation",
        "ApiSubDomain": "Cardless EMI",
        "SandboxUrl": "api/v1/cardless-emi/cancellation"
    },
    {
        "ApiId": "1356",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Resend-OTP",
        "ApiDesc": "This API is used for Resend the OTP.",
        "ApiSubDomain": "Cardless EMI",
        "SandboxUrl": "api/v1/cardless-emi/resend-otp"
    },
    {
        "ApiId": "1357",
        "ApiDomain": "Building Blocks",
        "ApiName": "GET List of Banks Accounts",
        "ApiDesc": "Retrieves the list of operative accounts for which the user has inquiry access. If no operative accounts are linked to the user, system throws an error stating 'No Accounts Found'. The list of accounts is based on the CIF linked to the user",
        "ApiSubDomain": "Bank Accounts",
        "SandboxUrl": "v1/bankaccounts/banks/users/customaccounts/opraccounts/operativeaccounts"
    },
    {
        "ApiId": "1358",
        "ApiDomain": "Building Blocks",
        "ApiName": "Bank Account Details",
        "ApiDesc": "Retrieves the complete details of selected account.",
        "ApiSubDomain": "Bank Accounts",
        "SandboxUrl": "v1/bankaccounts/banks/users/customaccounts/opraccounts/operativeaccounts"
    },
    {
        "ApiId": "1359",
        "ApiDomain": "Building Blocks",
        "ApiName": "Ministatement",
        "ApiDesc": "This API Retrieves the mini statement of operative account.",
        "ApiSubDomain": "Bank Accounts",
        "SandboxUrl": "v1/bankaccounts/banks/users/customaccounts/opraccounts/customministatement"
    },
    {
        "ApiId": "1360",
        "ApiDomain": "Building Blocks",
        "ApiName": "Detailed Statement Flow",
        "ApiDesc": "This API retrieves the transaction history of operative account.",
        "ApiSubDomain": "Bank Accounts",
        "SandboxUrl": "v1/bankaccounts/banks/users/customaccounts/opraccounts/customtransactions"
    },
    {
        "ApiId": "1361",
        "ApiDomain": "Building Blocks",
        "ApiName": "EStatement",
        "ApiDesc": "Below API retrieves the customerIdAcctId string to be passed to fetchPeriods API and the list of EStatement periods respectively.",
        "ApiSubDomain": "Bank Accounts",
        "SandboxUrl": "v1/bankaccounts/banks/users/customaccounts/filter/fetchForEstatement"
    },
    {
        "ApiId": "1362",
        "ApiDomain": "Building Blocks",
        "ApiName": "EStatement 2",
        "ApiDesc": "Below API retrieves the customerActString string to be passed to fetchPeriods API and the list of EStatement periods respectively.",
        "ApiSubDomain": "Bank Accounts",
        "SandboxUrl": "v1/bankaccounts/banks/users/customaccounts/opraccounts/fetchPeriods"
    },
    {
        "ApiId": "1363",
        "ApiDomain": "Building Blocks",
        "ApiName": "Revoke Token (Logout)",
        "ApiDesc": "This API generates an access token for the user to be used to access REST services from DEH.",
        "ApiSubDomain": "Common API",
        "SandboxUrl": "v1/common/banks/oauth/revoke"
    },
    {
        "ApiId": "1364",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Filtered Account",
        "ApiDesc": "This API fetches the filtered accounts applicable for a transaction.",
        "ApiSubDomain": "Common API",
        "SandboxUrl": "v1/common/banks/users/filters/transactiondebitaccounts"
    },
    {
        "ApiId": "1365",
        "ApiDomain": "Building Blocks",
        "ApiName": "Property References",
        "ApiDesc": "Fetches a list of properties configured at the bank level (propertyList).",
        "ApiSubDomain": "Common API",
        "SandboxUrl": "v1/common/banks/propertyreferences"
    },
    {
        "ApiId": "1366",
        "ApiDomain": "Building Blocks",
        "ApiName": "Code References",
        "ApiDesc": "Fetch common code reference details.",
        "ApiSubDomain": "Common API",
        "SandboxUrl": "v1/common/banks/codereferences"
    },
    {
        "ApiId": "1367",
        "ApiDomain": "Building Blocks",
        "ApiName": "Completed Transaction",
        "ApiDesc": "Completed Transaction for below Transaction types",
        "ApiSubDomain": "Completed Transaction",
        "SandboxUrl": "v1/completedtransaction/banks/users/customtran/fundsTransfer/customviewcompletedtxns"
    },
    {
        "ApiId": "1368",
        "ApiDomain": "Building Blocks",
        "ApiName": "View Transaction Details",
        "ApiDesc": "This API fetches the transaction details of completed transaction.",
        "ApiSubDomain": "Completed Transaction",
        "SandboxUrl": "v1/completedtransaction/banks/customtran/fundsTransfer/customviewtxndetail"
    },
    {
        "ApiId": "1369",
        "ApiDomain": "Building Blocks",
        "ApiName": "View Transaction Details – Transaction Type - XFR",
        "ApiDesc": "This API fetches the transaction details of completed transaction for transactiontype XFR.",
        "ApiSubDomain": "Completed Transaction",
        "SandboxUrl": "v1/completedtransaction/banks/users/customtran/fundsTransfer/customviewxfrtxn"
    },
    {
        "ApiId": "1370",
        "ApiDomain": "Building Blocks",
        "ApiName": "Credit Cards - Summary",
        "ApiDesc": "This API Fetches the summary of the credit cards.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "v1/creditcards/banks/users/customcards/creditcards"
    },
    {
        "ApiId": "1371",
        "ApiDomain": "Building Blocks",
        "ApiName": "Credit Cards - Last Statement",
        "ApiDesc": "This API Fetches the Last Statement Details of the Credit Card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "v1/creditcards/banks/users/customcards/creditcards/laststatement"
    },
    {
        "ApiId": "1372",
        "ApiDomain": "Building Blocks",
        "ApiName": "Credit Cards – Current Statement",
        "ApiDesc": "This API Fetches the current Statement Details of the Credit Card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "v1/creditcards/banks/users/customcards/creditcards/currentstatement"
    },
    {
        "ApiId": "1373",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Statement Periods",
        "ApiDesc": "To fetch list of monthly statement periods",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "v1/creditcards/banks/users/customaccounts/opraccounts/fetchPeriods"
    },
    {
        "ApiId": "1374",
        "ApiDomain": "Building Blocks",
        "ApiName": "Credit Cards List",
        "ApiDesc": "To fetch list of Credit Cards",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "v1/creditcards/banks/users/customcards/creditcards/creditcardslist"
    },
    {
        "ApiId": "1375",
        "ApiDomain": "Building Blocks",
        "ApiName": "Unbilled Transaction List",
        "ApiDesc": "This API Fetches the List of Unbilled Transactions of the Credit Card.",
        "ApiSubDomain": "Credit Cards",
        "SandboxUrl": "v1/creditcards/banks/users/customcards/creditcards/unbilledtransactions"
    },
    {
        "ApiId": "1388",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Credit Account List",
        "ApiDesc": "This API fetches the list of Accounts registered to the user as per the transaction type.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customaccounts/creditaccounts/payeeList"
    },
    {
        "ApiId": "1389",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Debit Account List",
        "ApiDesc": "This API fetches the applicable debit accounts allowed for a transaction type.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customaccounts/initiatoraccounts/transactiondebitaccounts"
    },
    {
        "ApiId": "1390",
        "ApiDomain": "Building Blocks",
        "ApiName": "FT Payee List",
        "ApiDesc": "This API Fetches the Upcoming Payments in Pay Bills Module.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/custompayees/cp/counterpartyList"
    },
    {
        "ApiId": "1391",
        "ApiDomain": "Building Blocks",
        "ApiName": "Own Account FT",
        "ApiDesc": "This API processes an Own account Funds Transfer.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/owntransfer/transfersrequests"
    },
    {
        "ApiId": "1392",
        "ApiDomain": "Building Blocks",
        "ApiName": "Other ICICI FT",
        "ApiDesc": "This API processes Other ICICI account Funds Transfers.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/fundsTransfer/customadhocpayeerequests"
    },
    {
        "ApiId": "1393",
        "ApiDomain": "Building Blocks",
        "ApiName": "Other Bank FT (IMPS-IFSC)",
        "ApiDesc": "This API processes Other bank account Funds Transfers. This includes NEFT/ RTGS and IMPS Payments.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/fundsTransfer/customadhocpayeerequests"
    },
    {
        "ApiId": "1394",
        "ApiDomain": "Building Blocks",
        "ApiName": "Other Bank FT (IMPS-MMID)",
        "ApiDesc": "This API processes Other bank account Funds Transfers. This includes NEFT/ RTGS and IMPS Payments.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/fundsTransfer/customadhocpayeerequests"
    },
    {
        "ApiId": "1395",
        "ApiDomain": "Building Blocks",
        "ApiName": "Other Bank FT (NEFT)",
        "ApiDesc": "This API processes Other bank account Funds Transfers. This includes NEFT/ RTGS and IMPS Payments.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/fundsTransfer/customadhocpayeerequests"
    },
    {
        "ApiId": "1396",
        "ApiDomain": "Building Blocks",
        "ApiName": "Other Bank FT (RTGS)",
        "ApiDesc": "This API processes Other bank account Funds Transfers. This includes NEFT/ RTGS and IMPS Payments.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/fundsTransfer/customadhocpayeerequests"
    },
    {
        "ApiId": "1397",
        "ApiDomain": "Building Blocks",
        "ApiName": "ICICI Quick FT",
        "ApiDesc": "This API processes Quick FT transfers to ICICI Accounts.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/quickFT/ownBank"
    },
    {
        "ApiId": "1347",
        "ApiDomain": "Trade Services",
        "ApiName": "LC Issuance",
        "ApiDesc": "Enables issuance of a Letter of Credit (LC) on the customer’s request.",
        "ApiSubDomain": "GetCustomerDetails",
        "SandboxUrl": "v1/api/trade-online/createLC"
    },
    {
        "ApiId": "1348",
        "ApiDomain": "Trade Services",
        "ApiName": "BG Issuance",
        "ApiDesc": "Enables issuance of a Bank Guarantee on the customer’s request.",
        "ApiSubDomain": "GetCustomerDetails",
        "SandboxUrl": "v1/api/trade-online/createbg"
    },
    {
        "ApiId": "1403",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get oAuth Token",
        "ApiDesc": "This API generates an access token for the user to be used to access REST services from DEH.",
        "ApiSubDomain": "Login",
        "SandboxUrl": "v1/login/banks/v2/oAuth/token"
    },
    {
        "ApiId": "1404",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get User Profile",
        "ApiDesc": "This API retrieves the basic details of the user like Segment, Gender, Salutation, Date. Amount formats, mobile number along with fedId etc. These values may have to be persisted in the client application for later use.",
        "ApiSubDomain": "Login",
        "SandboxUrl": "v1/login/banks/customprofiledetails/userprofile"
    },
    {
        "ApiId": "1405",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Menu Profile",
        "ApiDesc": "This API retrieves the Menu access list for the user. This needs to be used by the client application to control the functionalities exposed to the user.",
        "ApiSubDomain": "Login",
        "SandboxUrl": "v1/login/banks/users/menuprofile"
    },
    {
        "ApiId": "1406",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Landing Page",
        "ApiDesc": "This API retrieves the Menu Id of the landing page to which the user should be landed post successful login. The client application should pass a valid CTA flag as an input to this API for getting the landing page menu Id.",
        "ApiSubDomain": "Login",
        "SandboxUrl": "v1/login/banks/users/customusers/cta/fetchmenu"
    },
    {
        "ApiId": "1407",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Widget Visibility",
        "ApiDesc": "This API takes input as fedId, widgetVisibility string and same will be updated in userProfile API.",
        "ApiSubDomain": "Login",
        "SandboxUrl": "v1/login/banks/users/customdisplaydetails/widgetvisibility"
    },
    {
        "ApiId": "1408",
        "ApiDomain": "Building Blocks",
        "ApiName": "Resend OTP",
        "ApiDesc": "This API retrieves the one time password and resend to the registered customer mobile number.",
        "ApiSubDomain": "Login",
        "SandboxUrl": "v1/login/banks/users/customusers/otp/resendotp"
    },
    {
        "ApiId": "1409",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Biller Categories",
        "ApiDesc": "This API Fetches the Biller Categories in Pay Bills Module.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/payBillFetchBillerCategories"
    },
    {
        "ApiId": "1410",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Recent Paid Bills",
        "ApiDesc": "This API Fetches the Recently Paid Bills in Pay Bills Module.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/payBillFetchRecentPaidBills"
    },
    {
        "ApiId": "1411",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Upcoming Payments",
        "ApiDesc": "This API Fetches the Upcoming Payments in Pay Bills Module.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/payBillFetchUpcomingPmts"
    },
    {
        "ApiId": "1412",
        "ApiDomain": "Building Blocks",
        "ApiName": "UBPS Biller Addition",
        "ApiDesc": "This API is UBPS Biller Addition service.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custompayees/biller/billers"
    },
    {
        "ApiId": "1413",
        "ApiDomain": "Building Blocks",
        "ApiName": "UBPS Bill Payment",
        "ApiDesc": "This API post the UBPS Bill Payment.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custombillpay/adhocbillers/customadhocbillerrequests"
    },
    {
        "ApiId": "1414",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Biller List",
        "ApiDesc": "This API gets all/category wise billers",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/fetchAllBillers"
    },
    {
        "ApiId": "1415",
        "ApiDomain": "Building Blocks",
        "ApiName": "BBPS Bill Fetch and Biller Validation",
        "ApiDesc": "This API Fetches the BBPS Bill details and validates the biller in Pay Bills Module.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/billerdetails"
    },
    {
        "ApiId": "1416",
        "ApiDomain": "Building Blocks",
        "ApiName": "BBPS / Quick Pay Bill Payment",
        "ApiDesc": "This API submits a BBPS bill payment",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/adhocbillerrequests"
    },
    {
        "ApiId": "1417",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Biller Details",
        "ApiDesc": "This API fetches the details for the selected biller.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/registeredbillers/getPayeeFormat"
    },
    {
        "ApiId": "1418",
        "ApiDomain": "Building Blocks",
        "ApiName": "View Registered Biller",
        "ApiDesc": "This API fetches the list of registered billers of a user.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/registeredbillers/viewallbillers"
    },
    {
        "ApiId": "1419",
        "ApiDomain": "Building Blocks",
        "ApiName": "Edit Biller",
        "ApiDesc": "This API allows user to edit the biller.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/registeredbillers/editBiller"
    },
    {
        "ApiId": "1420",
        "ApiDomain": "Building Blocks",
        "ApiName": "Delete Biller",
        "ApiDesc": "This API allows user to deregister the biller.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/registeredbillers/deleteBiller"
    },
    {
        "ApiId": "1421",
        "ApiDomain": "Building Blocks",
        "ApiName": "Autopay Details – UBPS Biller",
        "ApiDesc": "This API allows user to get the autopay details for a UBPS biller.",
        "ApiSubDomain": "PayBills",
        "SandboxUrl": "v1/paybills/banks/users/custom/billpayment/registeredbillers/autopayDetails"
    },
    {
        "ApiId": "1422",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Payee List",
        "ApiDesc": "Retrieves the list of registered payees associated with a user. This API should be consumed for both ICICI and Other Bank Payees.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/counterparties"
    },
    {
        "ApiId": "1423",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Payee Details",
        "ApiDesc": "Retrieves the complete details of selected payee. The Payee can either belong to Home Bank or Other bank.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/counterparties"
    },
    {
        "ApiId": "1424",
        "ApiDomain": "Building Blocks",
        "ApiName": "Add Payee (Home Bank)",
        "ApiDesc": "This API is for adding a payee for the user.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/counterparties"
    },
    {
        "ApiId": "1425",
        "ApiDomain": "Building Blocks",
        "ApiName": "Add Payee (Other Bank)",
        "ApiDesc": "This API is for adding a payee for the user.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/biller/billers"
    },
    {
        "ApiId": "1426",
        "ApiDomain": "Building Blocks",
        "ApiName": "GET Pending List Payee Confirmation",
        "ApiDesc": "This API retrieves the list of all the pending self-confirmations. User can view the list and perform required action such as confirm and reject.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/fetchPendingPayee"
    },
    {
        "ApiId": "1427",
        "ApiDomain": "Building Blocks",
        "ApiName": "Confirm Payee",
        "ApiDesc": "This API confirms the payee addition which is pending self-confirmation",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/confirmpayee"
    },
    {
        "ApiId": "1428",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Bank Branch Details",
        "ApiDesc": "This API fetches list of bank branches and routing number. This should sort the list by Bank Ref No.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/bankbranches-routingnumbers"
    },
    {
        "ApiId": "1429",
        "ApiDomain": "Building Blocks",
        "ApiName": "Reject Payee",
        "ApiDesc": "This API deletes the other bank beneficiary registered for the user.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/rejectpayee"
    },
    {
        "ApiId": "1430",
        "ApiDomain": "Building Blocks",
        "ApiName": "Delete Payee (Other Bank)",
        "ApiDesc": "This API deletes the other bank beneficiary registered for the user.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/biller"
    },
    {
        "ApiId": "1431",
        "ApiDomain": "Building Blocks",
        "ApiName": "Delete Payee (Home Bank)",
        "ApiDesc": "This API deletes the home bank beneficiary registered for the user.",
        "ApiSubDomain": "Payee Management",
        "SandboxUrl": "v1/payeemanagement/banks/users/custompayees/cp/counterparties"
    },
    {
        "ApiId": "1432",
        "ApiDomain": "Building Blocks",
        "ApiName": "Pay Later Listing Details",
        "ApiDesc": "This API Fetches the Registration Details or the Paylater Account Summary",
        "ApiSubDomain": "Pay Later",
        "SandboxUrl": "v1/paylater/banks/users/custom/payLaterFetchDetails"
    },
    {
        "ApiId": "1433",
        "ApiDomain": "Building Blocks",
        "ApiName": "Pay Later Registration",
        "ApiDesc": "This API creates a PayLater account.",
        "ApiSubDomain": "Pay Later",
        "SandboxUrl": "v1/paylater/banks/users/custom/payLaterRegistration"
    },
    {
        "ApiId": "1434",
        "ApiDomain": "Building Blocks",
        "ApiName": "Change Password",
        "ApiDesc": "This API helps to change the password for the user from personal profile details.",
        "ApiSubDomain": "Personal Profile Details",
        "SandboxUrl": "v1/personalprofile/banks/users/custompersonalprofile/changepassword"
    },
    {
        "ApiId": "1345",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "FD Details",
        "ApiDesc": "FD Details",
        "ApiSubDomain": "GetCustomerDetails",
        "SandboxUrl": "v1/api/trade-online/getExistingFD"
    },
    {
        "ApiId": "1346",
        "ApiDomain": "Trade Services",
        "ApiName": "Limit details",
        "ApiDesc": "Used to fetch the real-time limit availability details of the customer.",
        "ApiSubDomain": "GetCustomerDetails",
        "SandboxUrl": "v1/api/trade-online/getLimits"
    },
    {
        "ApiId": "1435",
        "ApiDomain": "Building Blocks",
        "ApiName": "Personalize my Transaction Limits Fetch Limit Schemes",
        "ApiDesc": "This API helps to fetch the limit categories ",
        "ApiSubDomain": "Personal Profile Details",
        "SandboxUrl": "v1/personalprofile/banks/users/custom/txnLimits/fetch"
    },
    {
        "ApiId": "1436",
        "ApiDomain": "Building Blocks",
        "ApiName": "Personalize my Transaction Limits Fetch Daily Limits",
        "ApiDesc": "This API helps to fetch the daily limits for a particular category. ",
        "ApiSubDomain": "Personal Profile Details",
        "SandboxUrl": "v1/personalprofile/banks/users/custom/txnLimits/fetchListing"
    },
    {
        "ApiId": "1437",
        "ApiDomain": "Building Blocks",
        "ApiName": "Personalize my Transaction Limits Update",
        "ApiDesc": "This API helps to update the selected transaction limits for the user. ",
        "ApiSubDomain": "Personal Profile Details",
        "SandboxUrl": "v1/personalprofile/banks/users/custom/txnLimits/update"
    },
    {
        "ApiId": "1438",
        "ApiDomain": "Building Blocks",
        "ApiName": "Update Email Id",
        "ApiDesc": "This API helps to update the email id for the user.",
        "ApiSubDomain": "Personal Profile Details",
        "SandboxUrl": "v1/personalprofile/banks/users/custom/personalDetails/emailUpdate"
    },
    {
        "ApiId": "1439",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Scheduled Transaction List",
        "ApiDesc": "This API is used to fetch the list of scheduled transactions.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/customtran/scheduledtransactions/fetch"
    },
    {
        "ApiId": "1440",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Scheduled Transaction Details",
        "ApiDesc": "This API is used to fetch the details of a UBPS scheduled transaction.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/customtran/scheduledtransactions/fetchtransactiondetails"
    },
    {
        "ApiId": "1441",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Scheduled Transaction Type List",
        "ApiDesc": "This API is used to fetch the list of transactions types under scheduled transaction.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/customtran/scheduledtransactions/fetchTxnType"
    },
    {
        "ApiId": "1442",
        "ApiDomain": "Building Blocks",
        "ApiName": "Stop Scheduled Transaction",
        "ApiDesc": "This API is used to stop a scheduled transaction.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/customtran/scheduledtransactions/stoptransaction"
    },
    {
        "ApiId": "1443",
        "ApiDomain": "Building Blocks",
        "ApiName": "Modify Transaction",
        "ApiDesc": "This API is for modifying the transaction.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/customtran/fundsTransfer/customadhocpayeerequests"
    },
    {
        "ApiId": "1444",
        "ApiDomain": "Building Blocks",
        "ApiName": "Modify Transaction BBPS",
        "ApiDesc": "This API is used to update a modify transaction BBPS.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/customtran/scheduledtransactions/modifyBBPStransaction"
    },
    {
        "ApiId": "1445",
        "ApiDomain": "Building Blocks",
        "ApiName": "Modify Transaction UBPS",
        "ApiDesc": "This API is used to update a modify transaction UBPS.",
        "ApiSubDomain": "Scheduled Transaction",
        "SandboxUrl": "v1/scheduledtransaction/banks/users/custombillpay/adhocbillers/customadhocbillerrequest"
    },
    {
        "ApiId": "1446",
        "ApiDomain": "Building Blocks",
        "ApiName": "Debit Card Pin Generation",
        "ApiDesc": "This API is used to generate debit card pin.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrcards/generatepin/debitcardpinchange"
    },
    {
        "ApiId": "1447",
        "ApiDomain": "Building Blocks",
        "ApiName": "Block Card Service Request",
        "ApiDesc": "This API is used to raise service request for Block card. ",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrcards/customdebitcards/customblockdebitcardsrequest"
    },
    {
        "ApiId": "1448",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Debit Card List",
        "ApiDesc": "This API is used to fetch debit card list for user or account.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrcards/fetch/fetchdebitcardslist"
    },
    {
        "ApiId": "1449",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Fixed Deposit",
        "ApiDesc": "This API allows the user to open a new Fixed Deposit in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/servicerequests/fixed-deposit/open-fixed-deposit"
    },
    {
        "ApiId": "1450",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Tax Saver Fixed Deposit",
        "ApiDesc": "This API allows the user to open a new Tax Saver Fixed Deposit in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/servicerequests/tax-saver-fixed-deposit/open-tax-saver-fd"
    },
    {
        "ApiId": "1451",
        "ApiDomain": "Building Blocks",
        "ApiName": "Money Multiplier Fixed Deposit",
        "ApiDesc": "This API allows the user to open a new Money Multiplier Fixed Deposit in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/servicerequests/money-multiplier-fixed-deposit/open-money-multiplier-fd"
    },
    {
        "ApiId": "1452",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Recurring Deposit",
        "ApiDesc": "This API allows the user to open a new recurring deposit in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customservicerequests/customRD/customRDOpenAccountRequest"
    },
    {
        "ApiId": "1453",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Recurring Deposit Monthly Income",
        "ApiDesc": "This API allows the user to open a recurring deposit with monthly income in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customservicerequests/customRDM/customRDwithMonthlyIncomeRequest"
    },
    {
        "ApiId": "1454",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Monthly Income Fixed Deposit",
        "ApiDesc": "This API allows the user to open a new monthly income fixed deposit in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrfd/fdextra/fdincome"
    },
    {
        "ApiId": "1455",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Fixed Deposit with Group Term Plan (GTP) Life Cover",
        "ApiDesc": "This API allows the user to open Fixed Deposit with Group Term Plan (GTP) Life Cover in ICICI. ",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrfd/fdlife/fdlifeopen"
    },
    {
        "ApiId": "1456",
        "ApiDomain": "Building Blocks",
        "ApiName": "Open Fixed Deposit Credit Cards",
        "ApiDesc": "This API allows the user to open a new monthly income fixed deposit in ICICI.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrfd/fdextra/fdcard"
    },
    {
        "ApiId": "1457",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Address & Nominee Details",
        "ApiDesc": "This API is used to fetch user address and nominee details.",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/banks/users/customsrfd/fdlife/fetchNominee"
    },
    {
        "ApiId": "1458",
        "ApiDomain": "Building Blocks",
        "ApiName": "FD RD ROI & Maturity Details",
        "ApiDesc": "This API calculates the Rate of interest (ROI) and maturity details for different FD and RD products. ",
        "ApiSubDomain": "Service Request",
        "SandboxUrl": "v1/servicerequest/bank/users/customsrcards/basiccalculations/interestcalculation"
    },
    {
        "ApiId": "1459",
        "ApiDomain": "Building Blocks",
        "ApiName": "Create Fetch VPA",
        "ApiDesc": "This API checks for existing registration for the user account selected with UPI and creates a new VPA for the user if registration doesn’t exist. If the VPA is already available, the API returns the same.",
        "ApiSubDomain": "UPI PULL Funds",
        "SandboxUrl": "v1/upipullfunds/banks/users/custom/upiFetchVPA"
    },
    {
        "ApiId": "1460",
        "ApiDomain": "Building Blocks",
        "ApiName": "Verify VPA",
        "ApiDesc": "This API will check the VPA handle entered by the user for collection and return error (invalid case) or the Name (Valid Case) of the VPA handle holder.",
        "ApiSubDomain": "UPI PULL Funds",
        "SandboxUrl": "v1/upipullfunds/banks/users/custom/upiVerifyVPA"
    },
    {
        "ApiId": "1461",
        "ApiDomain": "Building Blocks",
        "ApiName": "Pull Fund",
        "ApiDesc": "This API invokes the collection request to UPI and checks for completion of payment from the UPI app of the target user till the waiting time configured.",
        "ApiSubDomain": "UPI PULL Funds",
        "SandboxUrl": "v1/upipullfunds/banks/users/custom/upiCollect"
    },
    {
        "ApiId": "1462",
        "ApiDomain": "Building Blocks",
        "ApiName": "UPI Transaction Status",
        "ApiDesc": "This API facilitates the user to check for the status of past payments done.",
        "ApiSubDomain": "UPI PULL Funds",
        "SandboxUrl": "v1/upipullfunds/banks/users/custom/upiTxnStatus"
    },
    {
        "ApiId": "1463",
        "ApiDomain": "Payments",
        "ApiName": "UPI Satus Check",
        "ApiDesc": "This API will be used to check the transaction status of the UPI Payment. ",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "/api/v1/composite-status"
    },
    {
        "ApiId": "1464",
        "ApiDomain": "Payments",
        "ApiName": "IMPS Status Check",
        "ApiDesc": "This API will be used to check the transaction status for IMPS. ",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "/api/v1/composite-status"
    },
    {
        "ApiId": "1465",
        "ApiDomain": "Payments",
        "ApiName": "NEFT/RTGS Status Check",
        "ApiDesc": "RTGS response received over composite status API is a terminal response.",
        "ApiSubDomain": "Composite API",
        "SandboxUrl": "/api/v1/composite-status"
    },
    {
        "ApiId": "1492",
        "ApiDomain": "Building Blocks",
        "ApiName": "UCustomerFilter",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/UCustomerFilter"
    },
    {
        "ApiId": "1381",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Deposit Accounts",
        "ApiDesc": "Retrieves the list of deposits accounts for which the user has inquiry access.If no deposits accounts are linked to the user, system throws an error stating 'No Accounts Found'. The list of accounts is based on the CIF linked to the user",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/customaccounts/dpraccounts/depositaccounts"
    },
    {
        "ApiId": "1382",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Deposit Account Details",
        "ApiDesc": "This API retrieves the complete details of selected deposit account.",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/depositaccounts"
    },
    {
        "ApiId": "1383",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Deposit Statement",
        "ApiDesc": "This API retrieves the transaction history of deposit account.",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/customaccounts/dpraccounts/statement"
    },
    {
        "ApiId": "1384",
        "ApiDomain": "Building Blocks",
        "ApiName": "Consolidated Balance",
        "ApiDesc": "This API retrieves the consolidated balances of deposits accounts grouped based on account type and currency type.",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/customaccounts/dpraccounts/fetchdepbalances"
    },
    {
        "ApiId": "1385",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get FD Advice",
        "ApiDesc": "This API retrieves the FD Advice in PDF format as binary attachment.",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/customaccounts/dpraccounts/advice"
    },
    {
        "ApiId": "1386",
        "ApiDomain": "Building Blocks",
        "ApiName": "Fetch Nominee Details",
        "ApiDesc": "This API retrieves the nominee details for the given deposits account.",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/customaccounts/dpraccounts/fetchNominee"
    },
    {
        "ApiId": "1387",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get IWish Deposit Accounts",
        "ApiDesc": "This API list the iWish deposits accounts and its details.",
        "ApiSubDomain": "Deposit Accounts",
        "SandboxUrl": "v1/depositaccounts/banks/users/customaccounts/dpraccounts/iWishDepAccountsList"
    },
    {
        "ApiId": "1398",
        "ApiDomain": "Building Blocks",
        "ApiName": "Other Bank Quick FT",
        "ApiDesc": "This API processes Quick FT transfers to ICICI Accounts.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/quickFT/otherBank"
    },
    {
        "ApiId": "1399",
        "ApiDomain": "Building Blocks",
        "ApiName": "Recent Transaction",
        "ApiDesc": "This API fetches the list of Recent transactions done by the user. ",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/completedTransaction/recentTransaction"
    },
    {
        "ApiId": "1400",
        "ApiDomain": "Building Blocks",
        "ApiName": "Favorite Transaction",
        "ApiDesc": "This API fetches the list of Favorite transactions set by the user. ",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/completedTransaction/favouriteTransaction"
    },
    {
        "ApiId": "1401",
        "ApiDomain": "Building Blocks",
        "ApiName": "Check Balance",
        "ApiDesc": "This API is used to get balance when accountId is provided.",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customaccounts/initiatoraccounts/checkBalance"
    },
    {
        "ApiId": "1402",
        "ApiDomain": "Building Blocks",
        "ApiName": "One Time Fund Transfer",
        "ApiDesc": "This API accepts the transaction details along with unregistered payee details, after validations payee will be created and transaction details will be stored in custom table",
        "ApiSubDomain": "Fund Transfer",
        "SandboxUrl": "v1/fundstransfer/banks/users/customtran/oneTimeFundsTransfer/customOTAdhocpayeerequests"
    },
    {
        "ApiId": "1466",
        "ApiDomain": "Building Blocks",
        "ApiName": "getJobCardDetails",
        "ApiDesc": "This API will give the jobcard details for particular RM. This data is fetched from the VRM_PRODUCT_SERVICE, VRM_RM_MAPPING and VRM_JOBCARD_DATA Collection of the mongodb. Count is optional, if not pass count no then get complete jobCard details and if pass count no (count=3) then get same no of records.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getJobCardDetails"
    },
    {
        "ApiId": "1467",
        "ApiDomain": "Building Blocks",
        "ApiName": "getCPMRData",
        "ApiDesc": "This API will give the complete CPMR data of the customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getCPMRData"
    },
    {
        "ApiId": "1468",
        "ApiDomain": "Building Blocks",
        "ApiName": "getRMMapping",
        "ApiDesc": "This API will give the RM mapping details (Primary/Secondary) of particular customer Mobile no. Below is the API detail.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getRMMapping"
    },
    {
        "ApiId": "1469",
        "ApiDomain": "Building Blocks",
        "ApiName": "getCustomerSummary",
        "ApiDesc": "This API will give the full Customer Summary. This data is fetched from the VRM_RM_CUST_SUMMARY Collection of the mongodb. Below is the API detail.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getCustomerSummary"
    },
    {
        "ApiId": "1470",
        "ApiDomain": "Building Blocks",
        "ApiName": "InsertAuditLog",
        "ApiDesc": "This API can be used for recent transactions of the Customer",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/InsertAuditLog"
    },
    {
        "ApiId": "1471",
        "ApiDomain": "Building Blocks",
        "ApiName": "UpdateJobCardStatus",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/UJobCardStatus"
    },
    {
        "ApiId": "1472",
        "ApiDomain": "Building Blocks",
        "ApiName": "addJob",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/addJob"
    },
    {
        "ApiId": "1473",
        "ApiDomain": "Building Blocks",
        "ApiName": "getJobCardDashboard",
        "ApiDesc": "This API gives details of communication history of the RM.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getJobCardDashboard"
    },
    {
        "ApiId": "1474",
        "ApiDomain": "Building Blocks",
        "ApiName": "getOverview",
        "ApiDesc": "This API can be used for recent transactions of the Customer",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getOverview"
    },
    {
        "ApiId": "1475",
        "ApiDomain": "Building Blocks",
        "ApiName": "getAccountSnapshots",
        "ApiDesc": "This API can be used to get Account Detail’s.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getAccountSnapshots"
    },
    {
        "ApiId": "1476",
        "ApiDomain": "Building Blocks",
        "ApiName": "getMyInsights",
        "ApiDesc": "This API is used to get the insight of the RM job card status.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getMyInsights"
    },
    {
        "ApiId": "1477",
        "ApiDomain": "Building Blocks",
        "ApiName": "changeMyAvailability",
        "ApiDesc": "This API is use update the toggle button of the RM Availability",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/changeMyAvailability"
    },
    {
        "ApiId": "1478",
        "ApiDomain": "Building Blocks",
        "ApiName": "getSuggestedProduct",
        "ApiDesc": "This API gives the upcoming Meetings for the RM for particular day",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getSuggestedProduct"
    },
    {
        "ApiId": "1479",
        "ApiDomain": "Building Blocks",
        "ApiName": "getCommHistory",
        "ApiDesc": "This API gives details of communication history of the RM.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getCommHistory"
    },
    {
        "ApiId": "1480",
        "ApiDomain": "Building Blocks",
        "ApiName": "UCustProdFeed",
        "ApiDesc": "This API is used to update the Customer Feedback for particular product.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/UCustProdFeed"
    },
    {
        "ApiId": "1481",
        "ApiDomain": "Building Blocks",
        "ApiName": "getUpcomingMeetings",
        "ApiDesc": "This API gives the upcoming Meetings for the RM for particular day.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getUpcomingMeetings"
    },
    {
        "ApiId": "1482",
        "ApiDomain": "Building Blocks",
        "ApiName": "Ucalendar",
        "ApiDesc": "This API is used to update the Calendar events.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/Ucalendar"
    },
    {
        "ApiId": "1483",
        "ApiDomain": "Building Blocks",
        "ApiName": "giveMyCustomerDetails",
        "ApiDesc": "This API gives details of all Customers of the RM.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/giveMyCust"
    },
    {
        "ApiId": "1484",
        "ApiDomain": "Building Blocks",
        "ApiName": "postINCallDetails",
        "ApiDesc": "This API will Insert the customer call details (Primary/Secondary) of particular customer Mobile no.  Below is the API detail.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/postINCallDetails"
    },
    {
        "ApiId": "1485",
        "ApiDomain": "Building Blocks",
        "ApiName": "postOUTCallDetails",
        "ApiDesc": "This API will Insert the customer call details (Primary/Secondary) of particular customer Mobile no.  Below is the API detail.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/postOUTCallDetails"
    },
    {
        "ApiId": "1486",
        "ApiDomain": "Building Blocks",
        "ApiName": "getTransactions",
        "ApiDesc": "This API can be used for recent transactions of the Customer",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getTransactions"
    },
    {
        "ApiId": "1487",
        "ApiDomain": "Building Blocks",
        "ApiName": "getJobCardDetails1",
        "ApiDesc": "This API will give the jobcard details for particular RM. This data is fetched from the VRM_JOBCARD_DATA Collection of the mongodb.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getJobCardDetails1"
    },
    {
        "ApiId": "1488",
        "ApiDomain": "Building Blocks",
        "ApiName": "getJobCardHistory",
        "ApiDesc": "This API can be used to get job card history.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getJobCardHistory"
    },
    {
        "ApiId": "1489",
        "ApiDomain": "Building Blocks",
        "ApiName": "getCustomerFilters",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getCustomerFilters"
    },
    {
        "ApiId": "1490",
        "ApiDomain": "Building Blocks",
        "ApiName": "Global Search",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/getEmpDetails"
    },
    {
        "ApiId": "1491",
        "ApiDomain": "Building Blocks",
        "ApiName": "sCustomerFilter",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/sCustomerFilter"
    },
    {
        "ApiId": "1",
        "ApiDomain": "Building Blocks",
        "ApiName": "Encryption",
        "ApiDesc": "This API is used to provide a sample conversion of a regular data packet to an encrypted data packet.",
        "ApiSubDomain": "Security",
        "SandboxUrl": "api/v0/encryption"
    },
    {
        "ApiId": "2",
        "ApiDomain": "Building Blocks",
        "ApiName": "Test API",
        "ApiDesc": "This API is used to provide a sample encrypted response to an encrypted sample data packet post selection of the appropriate service corresponding to the packet.  ",
        "ApiSubDomain": "Security",
        "SandboxUrl": "api/v0/upi"
    },
    {
        "ApiId": "3",
        "ApiDomain": "Building Blocks",
        "ApiName": "Decryption",
        "ApiDesc": "This API is used to provide a sample conversion of a encrypted data packet to a plain data packet.",
        "ApiSubDomain": "Security",
        "SandboxUrl": " api/v0/decryption"
    },
    {
        "ApiId": "101",
        "ApiDomain": "Payments",
        "ApiName": "List Account Provider UPI 2.0",
        "ApiDesc": "This API is used to returns the list of banks live on NPCI-UPI. This list will be updated as more banks get live on the platform.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/ListAccountProvider"
    },
    {
        "ApiId": "102",
        "ApiDomain": "Payments",
        "ApiName": "List Accounts UPI 2.0",
        "ApiDesc": "This API is used to returns customer accounts for given account provider registered with provided mobile number.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/ListAccounts"
    },
    {
        "ApiId": "103",
        "ApiDomain": "Payments",
        "ApiName": "Generate OTP  UPI 2.0",
        "ApiDesc": "This API is used for mapping account to customer VPA, as a authentication purpose issuing bank will validate one time password (OTP). UPI system will initiate generate OTP request to NPCI, which in turn call issuing Bank service.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/GenerateOTP"
    },
    {
        "ApiId": "104",
        "ApiDomain": "Payments",
        "ApiName": "List Keys UPI 2.0",
        "ApiDesc": "This API is used to return the list of encryption key for NPCI common library. Mobile application can call API once app instance in started and cache the keys in memory.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": " api/v0/upi2/ListKeys"
    },
    {
        "ApiId": "105",
        "ApiDomain": "Payments",
        "ApiName": "Register Mobile Number  UPI 2.0",
        "ApiDesc": "This API is used to register the mobile number with the PSP, validate customer with OTP or MPIN, set MPIN for selected account. In case of other bank account holders channels should invoke register mobile API to authenticate the user based on card digits, expiry date and set MPIN.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/RegisterMobileNumber"
    },
    {
        "ApiId": "106",
        "ApiDomain": "Payments",
        "ApiName": "Get Customer Accounts  UPI 2.0",
        "ApiDesc": "This API is used to return all the accounts mapped to the user. If same account is mapped to multiple account then multiple entries of same account will be present in the result.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/GetCustomerAccounts"
    },
    {
        "ApiId": "107",
        "ApiDomain": "Payments",
        "ApiName": "Validate Virtual Address  UPI 2.0",
        "ApiDesc": "This API is used by the application customer wants to add a beneficiary within PSP application (for sending & collecting money) or at the time of transaction when initiating Pay to ad-hoc VPA / Collect from ad-hoc VPA request.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/ValidateVirtualAddress"
    },
    {
        "ApiId": "108",
        "ApiDomain": "Payments",
        "ApiName": "Pay To Virtual Address  UPI 2.0",
        "ApiDesc": "This common API is used to support to initiate a pay request to virtual address and global recipients (IFSC + Account no / Mobile + MMD / Aadhaar + IIN).",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/PayToVirtualAddress"
    },
    {
        "ApiId": "109",
        "ApiDomain": "Payments",
        "ApiName": "Collect Request UPI 2.0",
        "ApiDesc": "This API will initiate a collect request from the virtual address. Amount will be credited to the account mapped to VPA which is identified by Account + IFSC.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/CollectRequest"
    },
    {
        "ApiId": "110",
        "ApiDomain": "Payments",
        "ApiName": "Approve/Reject Mandates UPI 2.0",
        "ApiDesc": "This API is used to approve or reject collect request initiated by some payee to user identified by mobile number. Debiting account will be identified by Account + IFSC mapped to VPA.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/Approve/RejectMandates"
    },
    {
        "ApiId": "111",
        "ApiDomain": "Payments",
        "ApiName": "Collect Auth  UPI 2.0",
        "ApiDesc": "This API is used for Switch (UPI System) initiate post request in format of son, to check channel authentication for approval of mandate transaction (validation response for inward Mandate Collect Authentication).",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/CollectAuth"
    },
    {
        "ApiId": "112",
        "ApiDomain": "Payments",
        "ApiName": "Manage Mandate  UPI 2.0",
        "ApiDesc": "This API is used for creating, updating and revoking the mandate.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/ManageMandate"
    },
    {
        "ApiId": "113",
        "ApiDomain": "Payments",
        "ApiName": "Get Pending Mandates  UPI 2.0",
        "ApiDesc": "This API is used to provide the list of pending mandates to the end user.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/GetPendingMandates"
    },
    {
        "ApiId": "114",
        "ApiDomain": "Payments",
        "ApiName": "Get All Mandates  UPI 2.0",
        "ApiDesc": "This API is used provide the list of mandates to the end user.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/GetAllMandates"
    },
    {
        "ApiId": "115",
        "ApiDomain": "Payments",
        "ApiName": "Mandate History  UPI 2.0",
        "ApiDesc": "This API display the mandate details for payer, which contains the number of instruction (Standing instruction) executed or pending to execute.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/portal/upi2/get-mandate-history"
    },
    {
        "ApiId": "116",
        "ApiDomain": "Payments",
        "ApiName": "Initiate Mandates Collect  UPI 2.0",
        "ApiDesc": "This API will provide facility to initiate mandate collect request manually. (Only bank enabled channels can initiate this request).",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/InitiateMandatesCollect"
    },
    {
        "ApiId": "117",
        "ApiDomain": "Payments",
        "ApiName": "UPI 2.0 Balance Inquiry  UPI 2.0",
        "ApiDesc": "This API used to return the balance details of the Account + IFSC mapped to VPA. Same API will cater to give customer existence.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/BalanceEnquiry"
    },
    {
        "ApiId": "118",
        "ApiDomain": "Payments",
        "ApiName": "Change MPIN  UPI 2.0",
        "ApiDesc": "This API used to change account MPIN. Account will be identified by Account + IFSC mapped to VPA.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/ChangeMPIN"
    },
    {
        "ApiId": "119",
        "ApiDomain": "Payments",
        "ApiName": "Deregister Profile  UPI 2.0",
        "ApiDesc": "This API works in two flows - depending on the value of delete-va-flag API will either delete specific VPA or deregister complete profile altogether.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/DeregisterProfile"
    },
    {
        "ApiId": "120",
        "ApiDomain": "Payments",
        "ApiName": "Merchant Refund Request  UPI 2.0",
        "ApiDesc": "This API works depending on the channel of the original transaction. UPI will only initiate credit for specific channels. Otherwise it will act like \"Get Payer Details\"  for other channel. API works based on the seq-no of the original transaction.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/MerchantRefundRequest"
    },
    {
        "ApiId": "121",
        "ApiDomain": "Payments",
        "ApiName": "Transaction Status  UPI 2.0",
        "ApiDesc": "This API is used to return the status of the transaction based on the seq-no of the original transaction.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/TransactionStatus"
    },
    {
        "ApiId": "122",
        "ApiDomain": "Payments",
        "ApiName": "Common Pay Request  UPI 2.0",
        "ApiDesc": "This common API will support to initiate a pay request to virtual address and global recipients (IFSC + Account no / Mobile + MMD / Aadhaar + IIN).",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/CommonPayRequest"
    },
    {
        "ApiId": "123",
        "ApiDomain": "Payments",
        "ApiName": "List PSP Keys  UPI 2.0",
        "ApiDesc": "This API is used to return the token from NPCI to be sent in the List Key API.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/listPSPKeys"
    },
    {
        "ApiId": "124",
        "ApiDomain": "Payments",
        "ApiName": "Manage Verified Address  UPI 2.0",
        "ApiDesc": "This API is used add/update/remove the verified virtual addresses as per the operation in the input.",
        "ApiSubDomain": "UPI 2.0",
        "SandboxUrl": "api/v0/upi2/ManageVerifiedAddress"
    },
    {
        "ApiId": "125",
        "ApiDomain": "Payments",
        "ApiName": "Get Token UPI 1.0",
        "ApiDesc": "This API will return the token from NPCI to be sent in the List Key API.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/gettoken"
    },
    {
        "ApiId": "126",
        "ApiDomain": "Payments",
        "ApiName": "List Accounts UPI 1.0",
        "ApiDesc": "Returns customer accounts for given account provider registered with provided mobile number.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/listaccounts"
    },
    {
        "ApiId": "127",
        "ApiDomain": "Payments",
        "ApiName": "Generate OTP UPI UPI 1.0",
        "ApiDesc": "For mapping account to customer VPA, as a authentication purpose issuing bank will validate One Time Password (OTP). UPI system will initiate generate OTP request to NPCI, which in turn call issuing Bank service.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/generateotp"
    },
    {
        "ApiId": "128",
        "ApiDomain": "Payments",
        "ApiName": "Register Mobile Number UPI 1.0",
        "ApiDesc": "Register the mobile number with the PSP, validate customer with OTP or MPIN, set MPIN for selected account.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/register"
    },
    {
        "ApiId": "129",
        "ApiDomain": "Payments",
        "ApiName": "Manage Verified Address UPI 1.0",
        "ApiDesc": "This API will add/update/remove the verified virtual addresses as per the operation in the input.",
        "ApiSubDomain": "UPI 1.0",
        "SandboxUrl": "api/v0/upi1/ManageVerifiedAddress"
    },
    {
        "ApiId": "1493",
        "ApiDomain": "Building Blocks",
        "ApiName": "dCustomerFilter",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/dCustomerFilter"
    },
    {
        "ApiId": "1494",
        "ApiDomain": "Building Blocks",
        "ApiName": "sCPMRLevel",
        "ApiDesc": "This API can be used for recent transactions of the Customer.",
        "ApiSubDomain": "VRM",
        "SandboxUrl": "api/v1/vrm/sCPMRLevel"
    },
    {
        "ApiId": "1495",
        "ApiDomain": "Building Blocks",
        "ApiName": "Execute Batch",
        "ApiDesc": "This URC Updatation API is used to business entity falling under the ambit of MSME is required to register itself with UDYAM. Udyam Registration Number is mandatory document for all MSME customers. ",
        "ApiSubDomain": "URC Updation",
        "SandboxUrl": "api/v1/urc-updation/proceedExecuteBatch"
    },
    {
        "ApiId": "1503",
        "ApiDomain": "Business Banking",
        "ApiName": "Create Offer",
        "ApiDesc": "The Create Offer API is unavailable to Partners as Offers are only created by Amazon Lending and are surfaced to Sellers on Amazon Seller Central.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/createOffer"
    },
    {
        "ApiId": "1504",
        "ApiDomain": "Business Banking",
        "ApiName": "Get (Read) Offer",
        "ApiDesc": "The Get Offer API is use to retrieve information about seller performance dataset.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1amazon-instaod/getOffer"
    },
    {
        "ApiId": "1505",
        "ApiDomain": "Business Banking",
        "ApiName": "Inquire Offer",
        "ApiDesc": "In the production environment, an offer is inquired when a seller clicks on an offer and is redirected to the partner's website. For testing purposes, this API provides the ability to emulate that event.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/inquireOffer"
    },
    {
        "ApiId": "1506",
        "ApiDomain": "Business Banking",
        "ApiName": "Redirect URL",
        "ApiDesc": "In this API, ICICI bank platform would receive Offer ID, Return URL, Expiry time of redirect URL, Signature & key ID. These parameters received in the URL would have to be stored by the InstaOD platform / database.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/getRedirectUrl"
    },
    {
        "ApiId": "1507",
        "ApiDomain": "Business Banking",
        "ApiName": "Create Application",
        "ApiDesc": "The Create Application API is use to create new application on lender central portal. When customer started his loan application on InstaOD platform, InstaOD trigger Create Application API.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/createApplication"
    },
    {
        "ApiId": "1508",
        "ApiDomain": "Business Banking",
        "ApiName": "Get (Read) Application",
        "ApiDesc": "The Create Application API is use to create new application on lender central portal. When customer started his loan application on InstaOD platform, InstaOD trigger Create Application API.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/getApplication"
    },
    {
        "ApiId": "1509",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Application API - Received",
        "ApiDesc": "For updating application to RECEIVED, the API accepts applicationId, lastUpdatedBy, receivedOn, request-related fields (denoted by **) and version.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/receiveApplication"
    },
    {
        "ApiId": "1510",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Application API - Approved",
        "ApiDesc": "For updating application to APPROVED, the API accepts applicationId, lastUpdatedBy, approvedOn, approval-related fields (denoted by ***) and version\n\n",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/approveApplication"
    },
    {
        "ApiId": "1511",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Application API - Confirmed",
        "ApiDesc": "In the production environment, an application is confirmed by the seller, which indicates their intent to proceed with the loan creation. For testing purposes, this API provides the ability to emulate that event.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/confirmApplication"
    },
    {
        "ApiId": "1512",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Application API - Rejected",
        "ApiDesc": "For updating application to REJECTED, the API accepts applicationId, lastUpdatedBy, rejectedOn, rejectionCategory statusReasonCode and version. Other fields would be ignored by the API",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/rejectApplication"
    },
    {
        "ApiId": "1513",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Application API - Abandoned\n\n",
        "ApiDesc": "For updating application to ABANDONED, the API accepts applicationId, lastUpdatedBy, abandonedOn, statusReasonCode and version.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/abandonApplication"
    },
    {
        "ApiId": "1514",
        "ApiDomain": "Business Banking",
        "ApiName": "Create Account Lock",
        "ApiDesc": "The Create AccountLock API is unavailable to Partners as AccountLocks are only created by Amazon Lending and are surfaced to Sellers on Amazon Seller Central. (This is created in UAT only for testing purpose).",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazoninstaod/lockAccountAndConfirmApplication"
    },
    {
        "ApiId": "1515",
        "ApiDomain": "Business Banking",
        "ApiName": "Get (Read) Account Lock",
        "ApiDesc": "Gets the details for an Account Lock with a specific AccountLock ID",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/getAccountLock"
    },
    {
        "ApiId": "1516",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Account Lock",
        "ApiDesc": "The Partner should call the Update AccountLock API to update any AccountLock information. Account Lock Schema is used for updating account lock status. Partners are only allowed to update accountLockStatus and unlockReasonCode field.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/upAccountLock"
    },
    {
        "ApiId": "1517",
        "ApiDomain": "Business Banking",
        "ApiName": "Confirm Account Lock",
        "ApiDesc": "This API is for seller, this is implemented in UAT only for testing purpose.  ",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/confirmAccountLock\n\n"
    },
    {
        "ApiId": "1518",
        "ApiDomain": "Business Banking",
        "ApiName": "Remove Account Lock",
        "ApiDesc": "AccountLockStatus should be LOCKED to UNLOCKED it with unlockReasonCode. This API is for seller, this is implemented in UAT only for testing purpose.  ",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/removeAccountLock"
    },
    {
        "ApiId": "1519",
        "ApiDomain": "Business Banking",
        "ApiName": "Create Credit Approval",
        "ApiDesc": "This API will display the data to sellers on Seller Central platform.\nThis API will create a new Credit Approval record with Amazon Lending once the Seller's Application is approved, before the loan has been disbursed.\n",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/createCreditApproval"
    },
    {
        "ApiId": "1520",
        "ApiDomain": "Business Banking",
        "ApiName": "Read (GET) Credit Approval",
        "ApiDesc": "Gets the details for an Credit Approval with a specific Application ID.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/getCreditApproval"
    },
    {
        "ApiId": "1521",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Credit Approval",
        "ApiDesc": "The Partner should call the Update Credit Approval API to update any Credit Approval information.",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1amazon-instaod/upCreditApproval"
    },
    {
        "ApiId": "1522",
        "ApiDomain": "Business Banking",
        "ApiName": "Create Loan API",
        "ApiDesc": "Create Loan API will be triggered to create a new Loan record with Amazon Lending once the Partner has created a Loan for the Seller and has disbursed funds.\n\n",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/createLoan"
    },
    {
        "ApiId": "1523",
        "ApiDomain": "Business Banking",
        "ApiName": "Read (GET) Loan API",
        "ApiDesc": "This API normally be performed to get the status of the loan & its current status. ",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/getLoan"
    },
    {
        "ApiId": "1524",
        "ApiDomain": "Business Banking",
        "ApiName": "Update Loan API",
        "ApiDesc": "This API normally be performed when the status of the loan changes; this may occur when the seller makes a payment",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/upLoan"
    },
    {
        "ApiId": "1525",
        "ApiDomain": "Business Banking",
        "ApiName": "Close Loan API",
        "ApiDesc": "This API normally be performed when close the loan; this may occur when the seller makes all outstandings",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/amazon-instaod/closeLoan"
    },
    {
        "ApiId": "1526",
        "ApiDomain": "Business Banking",
        "ApiName": "SNS Notification API\n\n",
        "ApiDesc": "SNS notification is being used Confrim Application, Abandoned Application & Confrim Accout Lock API",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "/amazon_loan_disbursal"
    },
    {
        "ApiId": "1502",
        "ApiDomain": "Building Blocks",
        "ApiName": "Login CRM",
        "ApiDesc": "CRM I-Mobile integration",
        "ApiSubDomain": "CRM",
        "SandboxUrl": "api/v1/crmimobile/login"
    },
    {
        "ApiId": "1530",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Debit Card Status",
        "ApiDesc": "This API is used to know the Status of Debit Card",
        "ApiSubDomain": "Debit Card",
        "SandboxUrl": "api/v1/eai_osb-generic/debitCardStatus"
    },
    {
        "ApiId": "1531",
        "ApiDomain": "Loans and Cards",
        "ApiName": "SR Search",
        "ApiDesc": "Pass SRSearch in service parameter in encrypted data",
        "ApiSubDomain": "Loans",
        "SandboxUrl": "api/v1/FCRM"
    },
    {
        "ApiId": "1532",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Account Balance Summary ",
        "ApiDesc": "This API will be used to show the Account balance (Check balance) of saving account number and credit card.  ",
        "ApiSubDomain": "Saving Account",
        "SandboxUrl": "api/v1/check-balance"
    },
    {
        "ApiId": "1533",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Cheque Book Request",
        "ApiDesc": "This API will be used to Raise Cheque book request ",
        "ApiSubDomain": "Saving Account",
        "SandboxUrl": "api/v1/check-balance"
    },
    {
        "ApiId": "1568",
        "ApiDomain": "Building Blocks",
        "ApiName": "ShuftiPro_Delete",
        "ApiSubDomain": "This api is for deleting KYC record in sufti pro"
    },
    {
        "ApiId": "1534",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "PAN Validation/ Get GSTIN details (Proprietor, Partnership)",
        "ApiDesc": "This API validates PAN Number and provide GSTIN details on the basis of customer’s PANNO. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/gstns"
    },
    {
        "ApiId": "1535",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Initial Handshake",
        "ApiDesc": "This API can be used for initial hand shake with merchant.   In response ICICI will send re-direction URL with pre-populated input details sent in request such as Customer Name, PAN, Mobile number etc",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/kyc/preCustomerHandshake"
    },
    {
        "ApiId": "1536",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Status Callback eKYC ",
        "ApiDesc": "This API is a call back service to update merchant the status of EKYC ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": " "
    },
    {
        "ApiId": "1537",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - GSTIN",
        "ApiDesc": "This API will validate on the basis of GSTIN.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/gstinDetail"
    },
    {
        "ApiId": "1538",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - Shop & Establishment",
        "ApiDesc": "This API will validate on the basis of registration number and state.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/snecs"
    },
    {
        "ApiId": "1539",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - IEC",
        "ApiDesc": "This API will validate on the basis of IEC Code.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/iecs"
    },
    {
        "ApiId": "1540",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - FSSAI",
        "ApiDesc": "This API will validate on the basis of license Number.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/fssais"
    },
    {
        "ApiId": "1541",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - TIN",
        "ApiDesc": "This API will validate on the basis of license Number.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/tins"
    },
    {
        "ApiId": "1542",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - VAT",
        "ApiDesc": "This API will validate on the basis of VAT Number.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/vats"
    },
    {
        "ApiId": "1543",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - CST",
        "ApiDesc": "This API will validate on the basis of CST number.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/csts"
    },
    {
        "ApiId": "1544",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - TAN",
        "ApiDesc": "This API will validate on the basis of TAN registration.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/csts"
    },
    {
        "ApiId": "1545",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - Udyog Aadhar",
        "ApiDesc": "This API will validate on the basis of UAM Number.  Request PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/udyogaadhaars"
    },
    {
        "ApiId": "1546",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - Central Service Tax",
        "ApiDesc": "This API will validate on the basis of assesse code.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/cservicetaxs"
    },
    {
        "ApiId": "1547",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details - Professional tax",
        "ApiDesc": "This API will validate on the basis of Professional tax number and state.  Requested PAN number is validated with response from signzy. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/ptrcs"
    },
    {
        "ApiId": "1548",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "PAN Validation/Get CIN (Others except Partnership )",
        "ApiDesc": "This API validates PAN Number and provide CIN details on the basis of customer’s Name.",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyCompany/getCI"
    },
    {
        "ApiId": "1549",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Get Details on CIN  (Others except Partnership )",
        "ApiDesc": "This API validates PAN Number and provide CIN details on the basis of customer’s Name. ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyCompany/organizations"
    },
    {
        "ApiId": "1550",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "PAN Validation (Director / Partners  )",
        "ApiDesc": "This API validates PAN Number of Director / Partner of a company.  ",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": " "
    },
    {
        "ApiId": "1551",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Choose your Account ",
        "ApiDesc": "This API will allow customer to get choice account number if available.",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/chooseCurrentAccount"
    },
    {
        "ApiId": "1552",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Final Submit ",
        "ApiDesc": "This API will allow customer to perform final submit of data",
        "ApiSubDomain": "Partner Integration",
        "SandboxUrl": "api/v1/signzyApi/finalSubmit"
    },
    {
        "ApiId": "1553",
        "ApiDomain": "Payments",
        "ApiName": "Pay Refund UK Global Pay",
        "ApiDesc": "This API is used for sending the refund request to Global Pay vendor for the other bank settlement. For the case where transaction is failed in NRISR.",
        "ApiSubDomain": "Refund",
        "SandboxUrl": "api/v1/payrefunduk"
    },
    {
        "ApiId": "1566",
        "ApiDomain": "Building Block",
        "ApiName": "Salary Account PPA Identification",
        "ApiSubDomain": "Unified Customer Journey ",
        "SandboxUrl": "api/v1/salaryAccountPPAidentification/getAccount-ppa"
    },
    {
        "ApiId": "1499",
        "ApiDomain": "Building Blocks",
        "ApiName": "Generate Case RCAS",
        "ApiDesc": "This API would transfer the request data(JSON), the customer data, coming from aggregator portal to the RCAS layer and save the data in RCAS system and thereby generate a case in RCAS system. RCAS will store the data of customer and it will be in various stages like case initiated, approval, etc.",
        "ApiSubDomain": "RCAS",
        "SandboxUrl": "api/v1/generateCaseRCAS"
    },
    {
        "ApiId": "1500",
        "ApiDomain": "Building Blocks",
        "ApiName": "Get Case Status RCAS",
        "ApiDesc": "The api will fetch the case status in RCAS of the cases initiated by generate case RCAS api.This will be triggered by the aggregator for status query of the case. ",
        "ApiSubDomain": "RCAS",
        "SandboxUrl": "getCaseStatusRCAS"
    },
    {
        "ApiId": "1501",
        "ApiDomain": "Payments",
        "ApiName": "Profunds Bene Upload",
        "ApiDesc": "The api has been developed to facilitate the communication between applications situated outside the bank’s logical network and Profunds via APIGEE gateway as a reverse proxy for the apis exposed by Profunds. When a user is registered on Pay2corp, a static VAN is created. This VAN needs to be registered in Profunds as well in order to execute the above validation.",
        "ApiSubDomain": "BeneUpload",
        "SandboxUrl": "brsbeneupload"
    },
    {
        "ApiId": "1554",
        "ApiDomain": "Accounts and Deposits",
        "ApiName": "Sol Inquiry",
        "ApiDesc": "This API is used Sol inquiry",
        "ApiSubDomain": "Account validation",
        "SandboxUrl": "api/v1/fi/Sol_Inq"
    },
    {
        "ApiId": "1528",
        "ApiDomain": "Building Blocks",
        "ApiName": "ShuftiPro",
        "ApiDesc": "For Customer online KYC verification we have called Shufti Pro API.",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "v1/shuftipro"
    },
    {
        "ApiId": "1529",
        "ApiDomain": "Building Blocks",
        "ApiName": "ShuftiPro_Callback",
        "ApiDesc": "In Shufti Pro Callback URL we have to configured API Gateway (ICICI Bank) API URL so that after customer KYC verification Shufti Pro will send response to API Gateway Gateway.",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v1/shuftipro_callback"
    },
    {
        "ApiId": "1555",
        "ApiDomain": "Building Block",
        "ApiName": "Update Passport Details",
        "ApiDesc": " ",
        "ApiSubDomain": " Passport",
        "SandboxUrl": "api/v1/fcrm/SRgenerate"
    },
    {
        "ApiId": "1556",
        "ApiDomain": "Building Block",
        "ApiName": "Update GSTIN",
        "ApiDesc": " ",
        "ApiSubDomain": " GST",
        "SandboxUrl": "api/v1/fcrm/SRgenerate"
    },
    {
        "ApiId": "1557",
        "ApiDomain": "Building Block",
        "ApiName": "ekyc_updation",
        "ApiDesc": "This API will be used for submission of an Original Transaction to internal system.",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v1/ekyc_updation"
    },
    {
        "ApiId": "1558",
        "ApiDomain": "Loans and Cards",
        "ApiName": "Loan Summary",
        "ApiDesc": "This API will be used to get the loan details on the Account.",
        "ApiSubDomain": "Loan Management",
        "SandboxUrl": "api/v1/finnone?service=GetLoanAcctDtls "
    },
    {
        "ApiId": "1559",
        "ApiDomain": "Building Block",
        "ApiName": "Video KYC Status ",
        "ApiDesc": "API for Video KYC Status update to the source system after each step of progress at VKYC end",
        "ApiSubDomain": "VKYC",
        "SandboxUrl": "api/v1/videoKYCstatus "
    },
    {
        "ApiId": "1560",
        "ApiDomain": "Building Block",
        "ApiName": "WaitCallTimeAPI",
        "ApiDesc": "This api gives wait time of the customer depending on the availability of the video KYC agent availability",
        "ApiSubDomain": "VKYC",
        "SandboxUrl": "api/v3/vKycWaitTime"
    },
    {
        "ApiId": "1561",
        "ApiDomain": "Building Block",
        "ApiName": "Customer Hand Shake API",
        "ApiDesc": "This api is used to send customer details to video kyc application/",
        "ApiSubDomain": "VKYC",
        "SandboxUrl": "api/v3/vKycCustomerData"
    },
    {
        "ApiId": "1562",
        "ApiDomain": "Building Block",
        "ApiName": "VKYC File Download",
        "ApiDesc": "This api provides the source system to download important documents from VKYC system",
        "ApiSubDomain": " VKYC",
        "SandboxUrl": "api/v3/vKycDownload"
    },
    {
        "ApiId": "1563",
        "ApiDomain": "Building Block",
        "ApiName": "Get Details By Tracking ID",
        "ApiDesc": "This API gives the status details basis tracking ID.",
        "ApiSubDomain": "VKYC",
        "SandboxUrl": "api/v3/getDeatilsByTrackingId?trackingId=1xh61481s9kaxxxxxx"
    },
    {
        "ApiId": "1564",
        "ApiDomain": "Building Block",
        "ApiName": "Get Details by PAN",
        "ApiDesc": "This api gives the status details basis of PAN Number",
        "ApiSubDomain": "VKYC",
        "SandboxUrl": "api/v3/getDetailsByPANID?PanNumber=XXXXXXXXXXX"
    },
    {
        "ApiId": "1565",
        "ApiDomain": "Building Block",
        "ApiName": "VKYC Customer Forwarding API",
        "ApiDesc": "This api enables source system to forward important information to users.",
        "ApiSubDomain": " VKYC",
        "SandboxUrl": "api/v3/kycCustomerforwarding"
    },
    {
        "ApiId": "1567",
        "ApiDomain": "Building Block",
        "ApiName": "GetCVidyaStatus",
        "ApiDesc": "This API will give the status",
        "ApiSubDomain": "Unified Customer Journey",
        "SandboxUrl": "/getcvidyastatus"
    },
    {
        "ApiId": "1496",
        "ApiDomain": "Business Banking",
        "ApiName": "Offer check API",
        "ApiDesc": "This API will validate the Mobile number using OTP and then check if the customer has any offer with ICICI bank or not",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/AcctDiscover/OfferFetch"
    },
    {
        "ApiId": "1497",
        "ApiDomain": "Business Banking",
        "ApiName": "Redirection for Existing customer",
        "ApiDesc": "This API will provide redirection URL for existing customer",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/IMSL"
    },
    {
        "ApiId": "1498",
        "ApiDomain": "Business Banking",
        "ApiName": "Redirection for New to Bank customer",
        "ApiDesc": "This API will provide redirection URL for New to Bank customer",
        "ApiSubDomain": "Inframe/Redirection APIs",
        "SandboxUrl": "api/v1/InstaOD/SES"
    },
    {
        "ApiId": "1527",
        "ApiDomain": "Building Blocks",
        "ApiName": "ShuftiPro",
        "ApiDesc": "For Customer online KYC verification we have called Shufti Pro API.",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "v1/shuftipro"
    },
    {
        "ApiId": "1569",
        "ApiDomain": "Building Blocks",
        "ApiName": "TransUnion(Canada)",
        "ApiDesc": "This api is used to capture customer details and upload it in transunion",
        "ApiSubDomain": "Customer Authentication",
        "SandboxUrl": "api/v1/transunion"
    },
    {
        "ApiId": "1570",
        "ApiDomain": "Payments",
        "ApiName": "Composite Validation",
        "ApiDesc": "This API will be used for beneficiary validation check",
        "ApiSubDomain": "Composite Pay",
        "SandboxUrl": "api/v1/composite-validation"
    },
    {
        "ApiId": "1571",
        "ApiDomain": "Corporate API Suite",
        "ApiName": "Fetch Bill",
        "ApiDesc": "This API is developed to Fetch Bill based on input details",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/Corporate/CIB/v1/FetchBill"
    },
    {
        "ApiId": "1572",
        "ApiDomain": "Corporate API Suite",
        "ApiName": "Fetch And Pay",
        "ApiDesc": "This API is developed to fetch pay based on the request packet",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/Corporate/CIB/v1/FetchPay"
    },
    {
        "ApiId": "1573",
        "ApiDomain": "Corporate API Suite",
        "ApiName": "Calculate tax",
        "ApiDesc": "This API is developed to calculate the tax",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/Corporate/CIB/v1/CalculateTax"
    },
    {
        "ApiId": "1574",
        "ApiDomain": "Corporate API Suite",
        "ApiName": "Pay Only",
        "ApiDesc": "This API is developed for paying the bill only",
        "ApiSubDomain": "BBPS",
        "SandboxUrl": "api/Corporate/CIB/v1/Payonly"
    }
];
  //searchText: string; 
  enteredText;
  //searchText: string; 
  constructor(private adm:LoginService,public router:Router, private route: ActivatedRoute,
     private toasterService: ToasterService) {     
    this.Get_All_API_List(); 
    this.route.params.subscribe(params => {
      this.enteredText="";
      if(localStorage.getItem("userEnteredText")!="" || localStorage.getItem("userEnteredText")!=undefined){
        this.onSearchChange(localStorage.getItem("userEnteredText"))
        this.enteredText=localStorage.getItem("userEnteredText");
        localStorage.removeItem("userEnteredText");
      }
    });
   
  }

  ngOnInit() {
  /*   console.log(localStorage.getItem("userEnteredText"))
    if(localStorage.getItem("userEnteredText")!="" || localStorage.getItem("userEnteredText")!=undefined){
      this.onSearchChange(localStorage.getItem("userEnteredText"))
    } */
   // this.onSearchChange(this.enteredText);
  }

  onSearchChange(searchValue: string): void { 
    var json = {
      "username" : localStorage.getItem('username')
    } 
    // this.adm.Get_All_API().subscribe((data: any) => {
    this.adm.Get_All_API(json).subscribe((data: any) => {
      var obj = JSON.parse(data._body);
      this.APIListV = obj; 
      var ApiName = [];
      for(let i=0;i<this.APIListV.length;i++)
      {        
       var apiname =this.APIListV[i]["ApiName"].toString().toLocaleLowerCase().trim();// this.APIListV[i]["ApiName"].toString().toLowerCase().trim(); //|| this.APIListV[i]["ApiDesc"].toLowerCase().indexOf(searchValue.toLowerCase()) !==-1
       var ApiDesc =this.APIListV[i]["ApiDesc"].toString().toLocaleLowerCase().trim();
       var a = apiname.includes(searchValue.toLocaleLowerCase().trim());
       var b = ApiDesc.includes(searchValue.toLocaleLowerCase().trim());
       var c =this.APIListV[i]["ApiName"].toString().includes(searchValue.toLocaleLowerCase());       
        if(a || b || c)
        {
          ApiName.push(this.APIListV[i]["ApiName"]);
        } 
                 
      }
      console.log("ApiName : "+ ApiName.sort()); 
      var sort_arr = ApiName.sort();
      var nn = [];
      var pp = [];
      var word = "";
      var obj1 = {};
      for(var i in sort_arr){
        if(word == sort_arr[i][0]){
          pp.push(sort_arr[i]); 
          obj1[word] = pp;
          nn.push(obj1);
        } else {
          obj1[word] = pp;
          nn.push(obj1);
          word = sort_arr[i][0];
          pp = [];
          pp.push(sort_arr[i]);
        }
        
      }
      this.appNameList = nn[0];
      console.log(this.appNameList);
    },
    err => {
      console.log('err', err);
    //  this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      
    },); 
  }

  Get_All_API_List()
  {
    var json = {
      "username" : localStorage.getItem('username')
    } 
      // this.adm.Get_All_API().subscribe((data: any) => {
      this.adm.Get_All_API(json).subscribe((data: any) => {
      var obj = JSON.parse(data._body);
      console.log(obj);
      this.APIListV = obj; 
      
      var AppName = [];
    
      for(var i in obj)
      {
         AppName.push(obj[i].ApiName);
        this.AppId[obj[i].ApiName] = obj[i]['ApiId'];
      }   
      console.log("Api sort");   
    
      
      var sort_arr = AppName.sort();
      var nn = [];
      var pp = [];
      var word = "A";
      var obj1 = {};
      console.log('sort_arr',sort_arr);
      for(var i in sort_arr){
        if(word == sort_arr[i][0]){
          pp.push(sort_arr[i]); 
        } else {
          obj1[word] = pp;
          nn.push(obj1);
          word = sort_arr[i][0];
          pp = [];
          pp.push(sort_arr[i]);
        }
        
      }
      // console.log("newarray");
      // console.log(nn[0]);
     //var alfabets =[]; var temp;

      // for(var i in AppName.sort())
      // {
      //   // var firstChr = AppName[i];
      //   // if(temp!=firstChr)
      //   // {
      //   //    temp = firstChr;console.log(firstChr);
      //   //    alfabets.push(firstChr[0])
      //   // }
      // }
      //console.log(alfabets);



      // 2/8/2021
      
      this.appNameList = nn[0];
      console.log(this.appNameList);
      },
      err => {
       
       
       
        var obj = this.dataBody;
      console.log(obj);
      // this.APIListV = obj; 
      
      var AppName = [];
    
      for(var i in obj)
      {
         AppName.push(obj[i].ApiName);
        this.AppId[obj[i].ApiName] = obj[i]['ApiId'];
      }   
      console.log("Api sort");   
    
      
      var sort_arr = AppName.sort();
      var nn = [];
      var pp = [];
      var word = "A";
      var obj1 = {};
      console.log('sort_arr',sort_arr);
      for(var i in sort_arr){
        if(word == sort_arr[i][0]){
          pp.push(sort_arr[i]); 
          console.log(pp)
        } else {
         
 
    const distinctArray = pp.filter((n, i) => pp.indexOf(n) === i);
          obj1[word] = distinctArray;

          nn.push(obj1);
          word = sort_arr[i][0];
          pp = [];
          pp.push(sort_arr[i]);
          console.log(pp)
        }
        
      }
      
      this.appNameList = nn[0];
      console.log(this.appNameList);
      
      console.log('err', err);
      //  this.router.navigate(['error']);
        this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      },)      
  }

  search( A:any){
    this.onSearchChange(A);
    this.seartext=A;
  }

  goto(from){
    $('html, body').animate({
                    scrollTop: $(".symbo_"+from).offset().top - 130
                }, 100);
  }

  goToPage(id){
    this.router.navigate(['apidetails/'+this.AppId[id]]);
  }

  gotoTop(){
     $('html, body').animate({
        scrollTop: 0
    }, 100);
  }
  toastrmsg(type ,title) {
    var toast: Toast = {
      type: type,
      title:"",
      body:title,
      showCloseButton: true 
    }; 
    this.toasterService.pop(toast);
  }
}
