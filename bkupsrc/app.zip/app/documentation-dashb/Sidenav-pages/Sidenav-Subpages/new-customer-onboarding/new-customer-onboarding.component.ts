import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-customer-onboarding',
  templateUrl: './new-customer-onboarding.component.html',
 // styleUrls: ['./new-customer-onboarding.component.css']
})
export class NewCustomerOnboardingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
