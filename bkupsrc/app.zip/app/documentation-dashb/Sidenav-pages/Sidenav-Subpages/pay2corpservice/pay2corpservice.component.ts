import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay2corpservice',
  templateUrl: './pay2corpservice.component.html',
  //styleUrls: ['./pay2corpservice.component.css']
})
export class Pay2corpserviceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
