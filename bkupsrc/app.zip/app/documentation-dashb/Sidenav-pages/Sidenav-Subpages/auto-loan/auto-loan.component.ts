import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auto-loan',
  templateUrl: './auto-loan.component.html',
  //styleUrls: ['./personal-loan.component.css']
})
export class AutoLoanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
