import { ViewAllApiFilterPipe } from './view-all-api-filter.pipe';

describe('ViewAllApiFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ViewAllApiFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
