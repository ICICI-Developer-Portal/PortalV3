import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/services/dashboard.service';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  showMatSpinner: boolean;
  treeData: any;
  router: any;
  TransactionHistory: any;

  constructor(private HttpClient: HttpClient,
   
    private dashboardService: DashboardService) { }

  ngOnInit() {
  }

  getTransactionHistory() {
    this.showMatSpinner = true;
    this.dashboardService.getTranscationHistory().subscribe((data: any) => {
      this.TransactionHistory = JSON.parse(data._body);
     
    },
    err => {
      console.log('err', err);
      this.router.navigate(['error']);
    },);
  }

}
