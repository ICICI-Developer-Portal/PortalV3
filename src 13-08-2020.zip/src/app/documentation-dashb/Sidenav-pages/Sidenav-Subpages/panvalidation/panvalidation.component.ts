import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panvalidation',
  templateUrl: './panvalidation.component.html',
 // styleUrls: ['./panvalidation.component.css']
})
export class PanvalidationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
