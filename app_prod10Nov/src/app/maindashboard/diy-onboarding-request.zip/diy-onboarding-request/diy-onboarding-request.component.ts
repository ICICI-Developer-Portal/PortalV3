import { Component, OnInit, TemplateRef } from '@angular/core';
import { LoginService } from "src/app/services";
import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
import { BsModalService, BsModalRef } from 'ngx-bootstrap';

// import 'rxjs/Rx';
import { Http, Headers, Response } from "@angular/http";
import { saveAs } from "file-saver";
import { Router } from '@angular/router';
import { ToasterService, Toast } from 'angular2-toaster';
//declare var require;

@Component({
  selector: 'app-diy-onboarding-request',
  templateUrl: './diy-onboarding-request.component.html',
  styleUrls: ['./diy-onboarding-request.component.css']
})
export class DiyOnboardingRequestComponent implements OnInit {
  onboardedMerchantData:any;
  reqDetailArr:any = [];

  modalRef: BsModalRef;
  onoardingRequestTableData:any;
  dataSource: string[] = [];
  p: any = "";
  role: string;
  certificate: any;
  //showurl:Boolean;
  constructor(
    private adm: LoginService,
    private spinnerService: Ng4LoadingSpinnerService,
    private router:Router,
    private toasterService: ToasterService,
    private modalService: BsModalService
  ) {
    this.request_data();
  }

  ngOnInit() {
    console.log("hi")
    
  }
  UAT_help(UAT_Help: any) {
    this.modalRef = this.modalService.show(UAT_Help, {
      backdrop: "static",
      class: "modal-lg"
    });
  }

  request_data() {
    console.log("jiii")
    
    this.spinnerService.show();
    //  this.role=localStorage.getItem('role')
    //   if(localStorage.getItem('role')=='admin'){
    //     this.showurl=true;
    //   }else{
    //   this.showurl=false;
    //   }
    this.adm.OnboardrequestsuserDiy().subscribe((data: any) => {
      var response = data._body;

      var obj = JSON.parse(response);
      this.onoardingRequestTableData=obj;
      this.onoardingRequestTableData.forEach( (myObject, index) => {
        //console.log(myObject)
        if(myObject.JiraStatus!=404){
          
          this.dataSource.push( myObject);
        
        }
      });
      this.spinnerService.hide();
    },
    err => {
      console.log('err', err);
     // this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      
    },);
  }

  //supporting .sql,.cer (not supporting .png, .docx)
  downloadCertificate(url) {
    var json = {
      filePath: url
    };

    var fileName = url.substring(url.lastIndexOf("/") + 1);

    this.adm.downloadCertificate(json).subscribe((data: any) => {
      this.certificate = data._body;
      console.log(data._body);
      var blob = new Blob([this.certificate], {
        type: "text/plain"
      });
      saveAs(blob, fileName);
    },
    err => {
      console.log('err', err);
     // this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  openModal(viewDetail: TemplateRef<any>,id) {
    console.log(id);
    this.onboardedMerchantData = this.reqDetailArr[id];
    console.log(this.onboardedMerchantData);
   // this.apiUrl = this.onboardedMerchantData.apiUrl.split(',');
    this.modalRef= this.modalService.show(viewDetail, { backdrop: "static",class: 'modal-lg'});
    
    
  }
  downloadDocument(jiraID,type,url) {
    var json = {
      jiraid: jiraID,
      type:type
    };

    var fileName = url.substring(url.lastIndexOf("/") + 1);

    this.adm.customDownload(json).subscribe((data: any) => {
      this.certificate = data._body;
      console.log(data._body);
      var blob = new Blob([this.certificate], {
        type: "text/plain"
      });
      saveAs(blob, fileName);
    },
    err => {
      console.log('err', err);
     // this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  toastrmsg(type ,title) {
    var toast: Toast = {
      type: type,
      title:"",
      body:title,
      showCloseButton: true 
    }; 
    this.toasterService.pop(toast);
  }
}
