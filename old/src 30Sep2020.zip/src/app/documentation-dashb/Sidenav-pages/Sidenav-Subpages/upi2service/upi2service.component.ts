import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upi2service',
  templateUrl: './upi2service.component.html',
  //styleUrls: ['./upi2service.component.css']
})
export class Upi2serviceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
