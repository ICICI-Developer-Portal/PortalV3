import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-penny-drop',
  templateUrl: './penny-drop.component.html',
  //styleUrls: ['./penny-drop.component.css']
})
export class PennyDropComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
