import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-instapay',
  templateUrl: './instapay.component.html',
 // styleUrls: ['./instapay.component.css']
})
export class InstapayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
