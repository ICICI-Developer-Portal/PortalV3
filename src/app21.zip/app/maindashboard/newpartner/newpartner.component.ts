import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newpartner',
  templateUrl: './newpartner.component.html',
  styleUrls: ['./newpartner.component.css']
})
export class NewpartnerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
