import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cash-deposit',
  templateUrl: './cash-deposit.component.html',
 // styleUrls: ['./cash-deposit.component.css']
})
export class CashDepositComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
