export class Config {
	 //public apiUrl = 'http://localhost:8080/rest/';
	  public apiUrl = 'https://developer.icicibank.com/rest/';
};
