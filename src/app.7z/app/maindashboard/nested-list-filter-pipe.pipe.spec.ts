import { NestedListFilterPipePipe } from './nested-list-filter-pipe.pipe';

describe('NestedListFilterPipePipe', () => {
  it('create an instance', () => {
    const pipe = new NestedListFilterPipePipe();
    expect(pipe).toBeTruthy();
  });
});
