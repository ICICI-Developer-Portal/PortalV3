import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nda',
  templateUrl: './nda.component.html',
  //styleUrls: ['./nda.component.css']
})
export class NDAComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
