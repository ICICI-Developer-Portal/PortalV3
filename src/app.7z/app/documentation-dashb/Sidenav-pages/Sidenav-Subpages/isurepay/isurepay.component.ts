import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-isurepay',
  templateUrl: './isurepay.component.html',
  //styleUrls: ['./isurepay.component.css']
})
export class IsurepayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
