import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bbps',
  templateUrl: './bbps.component.html',
  //styleUrls: ['./bbps.component.css']
})
export class BbpsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
