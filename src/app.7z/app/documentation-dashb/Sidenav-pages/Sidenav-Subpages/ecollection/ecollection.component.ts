import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecollection',
  templateUrl: './ecollection.component.html',
  //styleUrls: ['./ecollection.component.css']
})
export class EcollectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
