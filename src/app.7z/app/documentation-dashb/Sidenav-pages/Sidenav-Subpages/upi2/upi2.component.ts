import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upi2',
  templateUrl: './upi2.component.html',
 // styleUrls: ['./upi2.component.css']
})
export class Upi2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
