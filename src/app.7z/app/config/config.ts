export class Config {
	 //public apiUrl = 'http://localhost:8080/rest/';
	  public apiUrl = 'https://developer.icicibank.com/rest/';
	 public UAT_apiUrl ='https://developer.icicibank.com/ROOT_UAT/rest/';
	//   public UAT_apiUrl ='https://developer.icicibank.com/rest/';

}