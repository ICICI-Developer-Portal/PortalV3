import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MerchantOnboardingService } from 'src/app/services/merchant-onboarding.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-approve-onboarded-merchant-request',
  templateUrl: './approve-onboarded-merchant-request.component.html',
  styleUrls: ['./approve-onboarded-merchant-request.component.css']
})
export class ApproveOnboardedMerchantRequestComponent implements OnInit {
  id:any;
  reqDetailArr:any = [];
  
  
    constructor(private router: Router,
      private route: ActivatedRoute,
      private merchantSrvc: MerchantOnboardingService,
      private spinnerService: Ng4LoadingSpinnerService,
      private  formBuilder: FormBuilder) { 
        this.id = "456"
       
      }
  
    ngOnInit() {
      let json = {
        buHId : this.id
      }
      this.spinnerService.show();
      this.merchantSrvc.getBUHRequests(json ).subscribe((data: any) => {
        let response = JSON.parse( data._body);
        this.spinnerService.hide();
        this.reqDetailArr = response;
       },
       err => {
         this.spinnerService.hide();
         console.log('err', err);
         
       }); 
    }
    
    showDetailPage(id){
      console.log(id);
      this.merchantSrvc.setMerchantData(this.reqDetailArr[id]);
      this.router.navigate(["/MerchantDetail"]);
    }
  
  }
  