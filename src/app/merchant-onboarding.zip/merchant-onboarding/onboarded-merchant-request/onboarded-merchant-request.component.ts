import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MerchantOnboardingService } from 'src/app/services/merchant-onboarding.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-onboarded-merchant-request',
  templateUrl: './onboarded-merchant-request.component.html',
  styleUrls: ['./onboarded-merchant-request.component.css']
})
export class OnboardedMerchantRequestComponent implements OnInit {
id:any;
reqDetailArr:any = [];


  constructor(private router: Router,
    private route: ActivatedRoute,
    private merchantSrvc: MerchantOnboardingService,
    private spinnerService: Ng4LoadingSpinnerService,
    private  formBuilder: FormBuilder) { 

      this.route.params.subscribe(params => {
        this.id = params['id'];
      });
    }

  ngOnInit() {
    let json = {
      bUserId: this.id
    }
    this.spinnerService.show();
    this.merchantSrvc.getBURequests(json ).subscribe((data: any) => {
      let response = JSON.parse( data._body);
      this.spinnerService.hide();
      this.reqDetailArr = response;
     },
     err => {
       this.spinnerService.hide();
       console.log('err', err);
       
     }); 
  }
  
  showDetailPage(id){
    console.log(id);
    this.merchantSrvc.setMerchantData(this.reqDetailArr[id]);
    this.router.navigate(["/MerchantDetail"]);
  }

}
