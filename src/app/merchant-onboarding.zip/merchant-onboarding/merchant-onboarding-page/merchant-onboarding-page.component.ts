import { FormBuilder, FormGroup, FormArray, FormControl, Validators, AbstractControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MerchantOnboardingService } from 'src/app/services/merchant-onboarding.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Console } from 'console';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-merchant-onboarding-page',
  templateUrl: './merchant-onboarding-page.component.html',
  styleUrls: ['./merchant-onboarding-page.component.css'],
  providers: [DatePipe],
})
export class MerchantOnboardingPageComponent implements OnInit {
  reactiveForm: FormGroup;
  maxDate:any;
  minDate:any;

  constructor(private router: Router,
    private merchantSrvc: MerchantOnboardingService,
    private spinnerService: Ng4LoadingSpinnerService,
    private  formBuilder: FormBuilder,
    private HttpClient: HttpClient,
    public datepipe: DatePipe,
   ) {
    /* this.dateInput= datepipe.transform(Date.now(),'dd-MMMM-yyyy');*/
    this.maxDate= datepipe.transform(new Date(),'yyyy-MM-dd'); 
    }

  ngOnInit() {
    let reset="";
    this.form(reset)

  }

  form(reset){
    this.reactiveForm = new FormGroup({
      'basicDetailsSection': new FormGroup({
         "buID":new FormControl('',[Validators.required]),     
        "BusinessUserName":new FormControl('',[Validators.required]),  
        "BusinessUserHeadID":new FormControl('',[Validators.required]),  
        "BusinessUserEmail":new FormControl('',[Validators.required,Validators.email]),  
        "merchantName": new FormControl('',[Validators.required]),  
        "Decryption": new FormControl('',[Validators.required]),  
        "RelationshipManager": new FormControl('',[Validators.required]),  
        "RequestDate": new FormControl('',[Validators.required]),  
        "Domain": new FormControl('',[Validators.required]),  
        "DomainAPI": new FormControl('',[Validators.required]),  
        "IPList": new FormControl('',[Validators.required]),  
        "CallbackURL":new FormControl(''),  
        "APIURL": new FormControl('',[Validators.required]),  
        "Certificate":  new FormControl('',[Validators.required]),  
        "Remarks": new FormControl(''),  
        "APIName": new FormControl(''),  
        "Mode":new FormControl('', [Validators.required]),
        "nDa":new FormControl('', [Validators.required])
       })
  })

  }

  saveMerchantData($event){
    console.log(this.reactiveForm.value);
    let json= {
      "buID":this.reactiveForm.value.basicDetailsSection.buID,    
      "BusinessUserName":this.reactiveForm.value.basicDetailsSection.BusinessUserName,  
      "BusinessUserHeadID":this.reactiveForm.value.basicDetailsSection.BusinessUserHeadID,  
      "BusinessUserEmail":this.reactiveForm.value.basicDetailsSection.BusinessUserEmail,  
      "merchantName": this.reactiveForm.value.basicDetailsSection.merchantName,  
      "Decryption": this.reactiveForm.value.basicDetailsSection.Decryption,  
      "RelationshipManager": this.reactiveForm.value.basicDetailsSection.RelationshipManager,  
      "RequestDate": this.reactiveForm.value.basicDetailsSection.RequestDate,  
      "Domain": this.reactiveForm.value.basicDetailsSection.Domain,  
      "DomainAPI": this.reactiveForm.value.basicDetailsSection.DomainAPI,  
      "IPList": this.reactiveForm.value.basicDetailsSection.IPList,  
      "CallbackURL":this.reactiveForm.value.basicDetailsSection.CallbackURL,  
      "APIURL": this.reactiveForm.value.basicDetailsSection.APIURL,  
      "Certificate":  "",  
      "Remarks": this.reactiveForm.value.basicDetailsSection.Remarks,  
      "APIName": this.reactiveForm.value.basicDetailsSection.APIName,  
      "Mode": this.reactiveForm.value.basicDetailsSection.Mode,
      "nDa": this.reactiveForm.value.basicDetailsSection.nDa
      
    }
    const formData = new FormData();
    /* bUserId : 
    bUserName :
    bUserEmail :
    bUserHId ;
    mName :
    desc :
    rManager :
    reqDt :
    domain :
    domainApi :
    ipList : 
    cBackUrl :
    nSign ://
    apiUrl :
    certificate :  -(File type attachment)
    remarks :
    apiName :
    encrypt :
    decrypt :
    mode : */
    formData.append("bUserId", json["buID"]); //1
    formData.append("bUserName", json["BusinessUserName"]); //2
    formData.append("bUserHId", json["BusinessUserHeadID"]); //1
    formData.append("bUserEmail", json["BusinessUserEmail"]); //2
    formData.append("mName", json["merchantName"]); //1
    formData.append("desc", json["Decryption"]); //1
    formData.append("rManager", json["RelationshipManager"]); //2
    formData.append("reqDt", this.datepipe.transform(new Date(json["RequestDate"]),'dd-MMM-yyyy')); //1
    formData.append("domain", json["Domain"]); //2
    formData.append("domainApi", json["DomainAPI"]); //1
    formData.append("ipList", json["IPList"]); //2
    formData.append("cBackUrl", json["CallbackURL"]); //1
    formData.append("apiUrl", json["APIURL"]); //2

    let a: any = (<HTMLInputElement>document.getElementById("Certificate")).files;
   
    for (let k = 0; k < a.length; k++) {
     
      formData.append("certificate", a[k]); //34

    }
    formData.append("remarks", json["Remarks"]); //2
    formData.append("apiName", json["APIName"]); //1
    formData.append("mode", json["Mode"]); //2
    formData.append("nDa", json["nDa"]); 
    // Unused request key
    formData.append("nSign",""); 
    formData.append("encrypt", ""); 
    formData.append("decrypt", ""); 

    this.spinnerService.show();

    this.HttpClient.post<any>(

      "https://developer.icicibank.com/rest/merchantOnboard",

      formData

    ).subscribe(

      res => {
        console.log(res);
        if (res.status == true || res.status == "true") {
          alert(res.message);
          this.router.navigate(["onboardedMerchantList/"+json["buID"]]);

        } else{
          alert(res.message);
        }
        this.spinnerService.hide();
      },

      err => {
        console.log('err', err);
        this.spinnerService.hide();
      });
   
     
      }
    
    }
