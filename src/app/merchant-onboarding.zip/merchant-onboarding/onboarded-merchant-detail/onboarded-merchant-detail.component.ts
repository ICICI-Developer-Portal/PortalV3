import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MerchantOnboardingService } from 'src/app/services/merchant-onboarding.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormBuilder } from '@angular/forms';
import { Location } from '@angular/common'

@Component({
  selector: 'app-onboarded-merchant-detail',
  templateUrl: './onboarded-merchant-detail.component.html',
  styleUrls: ['./onboarded-merchant-detail.component.css']
})
export class OnboardedMerchantDetailComponent implements OnInit {
  onboardedMerchantData:any = {}
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private merchantSrvc: MerchantOnboardingService,
    private spinnerService: Ng4LoadingSpinnerService,
    private  formBuilder: FormBuilder,
    private location: Location
    ) { 
      
    }

  ngOnInit() {
    this.onboardedMerchantData= this.merchantSrvc.getMerchantData();
    console.log( this.onboardedMerchantData);

  }
  navigateBack():void {
    this.location.back()
  }

}
