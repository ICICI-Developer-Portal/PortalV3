import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { FormBuilder, FormGroup, FormArray, FormControl, Validators, AbstractControl } from '@angular/forms';

import { BillingEngineService } from 'src/app/services/billing-engine.service';

@Component({
  selector: 'app-approve-rate-plan',
  templateUrl: './approve-rate-plan.component.html',
  styleUrls: ['./approve-rate-plan.component.css']
})
export class ApproveRatePlanComponent implements OnInit {

  ApproveRateForm: FormGroup;

  id:any;
  appDetail:any;
  appProducts:any = [];
  apiProductBucket :any =[];
  ratePlans : any = [];
   arr1 =[];
   status;
   apiProduct;
  
  
  
    constructor(
      private route: ActivatedRoute,
      private fetchData: BillingEngineService,
      private spinnerService: Ng4LoadingSpinnerService,
      private formBuilder: FormBuilder
      ) { 
      
    
      this.route.params.subscribe(params => {
        this.id = params['id'];
        console.log(this.id);
      });
    }
  
    ngOnInit() {
  
     
      this.spinnerService.show();
      let json= {
        appId : this.id
      }
     
      this.fetchData.getAppDetail(json).subscribe((data: any) => {
          let response = JSON.parse( data._body);
          this.appDetail = response;
          // product value may change
          let products = response.credentials[0].apiProducts;
          for( let i in products){
            for(let j in response.attribute){ 
              if(response.attributes[j].name == products[i].apiproduct){
                let o = JSON.parse(response.attributes[j].value);
                for(let key in o){
                  let tempObj = {
                    name: key,
                    value:o[key],
                    appProduct:products[i].apiproduct
                  }
                  this.apiProductBucket.push(tempObj)
                }
                
              }
            }

            this.appProducts.push(products[i].apiproduct);
            
          }
         console.log("this.apiProductBucket="+ JSON.stringify(this.apiProductBucket))
          this.spinnerService.hide();
         },
         err => {
           this.spinnerService.hide();
           console.log('err', err);
           
         });


         
         //get rate plan
         let reset="";
     this.form(reset)
    }

    form(reset){
    this.ApproveRateForm = new FormGroup({
      'ApproveRateplan': new FormGroup({

      "approveRateplan":  new FormControl(),})
     
})
}

  
    saveRatePlane(){
  
      
      let attr = {
       
          "attributes": []
        
      };
      let json = {
        appName : "",
        email : "",
        attributes :attr
        
      };
     
      this.spinnerService.show();
     this.fetchData.saveRatePlan(json).subscribe((data: any) => {
       let response = JSON.parse( data._body);
       console.log(response);
       this.spinnerService.hide();
      },
      err => {
        this.spinnerService.hide();
        console.log('err', err);
        
      }); 
   }

  
  
  
  
  
  onSubmit($event) {
    console.log("sbdbsdh",this.ApproveRateForm.value);
   }
   
   
   
   }
  
  
  
  
  
  
  
  
  
  
  
  
 
  