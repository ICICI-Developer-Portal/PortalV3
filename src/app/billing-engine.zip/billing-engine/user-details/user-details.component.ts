import { Component, OnInit,OnDestroy  } from '@angular/core';
import { BillingEngineService } from 'src/app/services/billing-engine.service';
import { Subscription } from 'rxjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';




@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit  {
  dataRcvr: Array<any>;
  userProfileData;

  message:string;
  subscription: Subscription;


  constructor(private fetchData: BillingEngineService,
    private spinnerService: Ng4LoadingSpinnerService) {
   
  }
 
  ngOnInit() {
   
    // get profile data 
    this.userProfileData= this.fetchData.getUserData();
     console.log( this.userProfileData);

  }

  newMessage() {
    this.fetchData.changeMessage("Hello from Sibling")
    
    
  }

}
