import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { DataTableResource } from 'angular7-data-table';


@Component({
  selector: 'app-userdata',
  templateUrl: './userdata.component.html',
  styleUrls: ['./userdata.component.css']
})
export class UserdataComponent implements OnInit {

  
  userForm: FormGroup;
  Merchant_user: any = false;
  API_Sample_packet: any = false;
  ADD_Parameters_Table: any = false;
  API_REQ_PARAMETER_Table: any = false;
  API_RES_PARAMETER_Table: any = false;
  @ViewChild('modalClose') modalClose:ElementRef;
  //Static data, you can change as per your need
  persons: any[] = [
		{"id": "1", "merchantname": "CD ", "username": "chetan"},
		{"id": "2", "merchantname": "RazorPay ", "username": "apitesting@2"},
		{"id": "3", "merchantname": "SafeGold ", "username": "nitinthard"},
		{"id": "4", "merchantname": "Safexpay ", "username": "deepaknair.17"},
	   
	    
	];
	itemResource = new DataTableResource(this.persons);
	items = [];
	itemCount = 0;
	params = {offset: 0, limit: 10}; //Static can be changed as per your need
	formFlag = 'add';
	tableList : any[] = ["MERCHANT_USER","API_SAMPLE_PACKET","ADD_PARAMETERS_TABLE","API_REQ_PARAMETER","API_RES_PARAMETER"];

    constructor(){
      this.itemResource.count().then(count => this.itemCount = count);
      this.reloadItems(this.params);
    }  

    reloadItems(params) {
      this.itemResource.query(params).then(items => this.items = items);
    }

    // special properties:
    rowClick(rowEvent) {
        console.log('Clicked: ' + rowEvent.row.item.merchantname);
    }

    rowDoubleClick(rowEvent) {
        alert('Double clicked: ' + rowEvent.row.item.merchantname);
    }

	rowTooltip(item) { return item.username; }

	//Init method
	ngOnInit(){
		this.userForm = new FormGroup({
		  'id': new FormControl(null),
		  'merchantname': new FormControl(null, Validators.required),
		  'username': new FormControl(null, Validators.required)
		});
	}

	initUser(){
		//User form reset
		this.userForm.reset();
		this.formFlag = 'add';
	}
	//Save user's data
	saveUser(){
		if(this.formFlag == 'add')
		{
			this.userForm.value.id= this.persons.length + 1;
			this.persons.unshift(this.userForm.value);
		}
		else
		{
			var index = this.persons.findIndex(x => x.id== this.userForm.value.id);
			if (index !== -1) {
			  this.persons[index] = this.userForm.value;
			}
		}
		this.reloadTableManually();
		//Close modal
		this.modalClose.nativeElement.click();
		//User form reset
		this.userForm.reset();
	}
	//Get data while edit
	getData(item)
	{
		this.userForm.patchValue(item);
		this.formFlag = 'edit';
	}
	//Delete user's data
	delData(item){
		this.persons.splice(this.persons.indexOf(item), 1);
		this.reloadTableManually();
	}
	//Reload table manually after add/edit
	reloadTableManually(){
		this.reloadItems(this.params);
		this.itemResource.count().then(count => this.itemCount = count);
	}
	changeTableName(val){

		console.log(val);
		
		if(val === "MERCHANT_USER"){
			this.Merchant_user= true;

			
			this.API_Sample_packet  = false;
			this.ADD_Parameters_Table  = false;
			this.API_REQ_PARAMETER_Table = false;
			this.API_RES_PARAMETER_Table  = false;
		} else if(val === "API_SAMPLE_PACKET"){
			this.API_Sample_packet= true;

			this.Merchant_user= false;
			this.ADD_Parameters_Table  = false;
			this.API_REQ_PARAMETER_Table = false;
			this.API_RES_PARAMETER_Table  = false;

		}else if(val === "ADD_PARAMETERS_TABLE"){
			this.ADD_Parameters_Table= true;

			this.Merchant_user= false;
			this.API_Sample_packet  = false;
			this.API_REQ_PARAMETER_Table = false;
			this.API_RES_PARAMETER_Table  = false;
		}else if(val === "API_REQ_PARAMETER"){
			this.API_REQ_PARAMETER_Table= true;

			this.Merchant_user= false;
			this.API_Sample_packet  = false;
			this.ADD_Parameters_Table  = false;
			this.API_RES_PARAMETER_Table  = false;
		}else if(val === "MERCHAPI_RES_PARAMETERNT_USER"){
			this.API_RES_PARAMETER_Table= true;
			this.Merchant_user= false;
			this.API_Sample_packet  = false;
			this.ADD_Parameters_Table  = false;
			this.API_REQ_PARAMETER_Table = false;
		}else{
			this.Merchant_user= false;
			this.API_Sample_packet  = false;
			this.ADD_Parameters_Table  = false;
			this.API_REQ_PARAMETER_Table = false;
			this.API_RES_PARAMETER_Table  = false;
		}
	}
}
