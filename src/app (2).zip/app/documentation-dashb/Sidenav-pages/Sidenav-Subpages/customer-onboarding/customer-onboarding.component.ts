import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-onboarding',
  templateUrl: './customer-onboarding.component.html',
  //styleUrls: ['./customer-onboarding.component.css']
})
export class CustomerOnboardingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
