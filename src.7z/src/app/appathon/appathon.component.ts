import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appathon',
  templateUrl: './appathon.component.html',
  styleUrls: ['./appathon.component.css']
})
export class AppathonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
