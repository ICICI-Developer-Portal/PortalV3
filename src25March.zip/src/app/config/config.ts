export class Config {
	//public apiUrl = 'http://localhost:8080/rest/';
	//---------- prod------------------- 
	  public apiUrl = 'https://developer.icicibank.com/rest/';
	 public DIY_apiUrl = "https://developer.icicibank.com/ROOTDIY/rest/";
	
	 public UAT_apiUrl ='https://developer.icicibank.com/ROOT_UAT/rest/'; 

	 //-----------------uat--------------------- 
	/*  public apiUrl = 'http://10.78.25.173:8080/rest/';
	 public DIY_apiUrl = 'http://10.78.25.173:8080/rest/';
	 public UAT_apiUrl ='http://10.78.25.173:8080/rest/';  */

	 public allowedIdForApiList= ["461738","469904","474221","231240","BAN255139","BAN255141","BAN255142"];
}