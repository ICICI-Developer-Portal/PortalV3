import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-merchant-onboarding-page',
  templateUrl: './test-merchant-onboarding-page.component.html',
  styleUrls: ['./test-merchant-onboarding-page.component.css']
})
export class TestMerchantOnboardingPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
