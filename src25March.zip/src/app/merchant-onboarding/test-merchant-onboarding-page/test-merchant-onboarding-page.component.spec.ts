import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TestMerchantOnboardingPageComponent } from './test-merchant-onboarding-page.component';

describe('TestMerchantOnboardingPageComponent', () => {
  let component: TestMerchantOnboardingPageComponent;
  let fixture: ComponentFixture<TestMerchantOnboardingPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestMerchantOnboardingPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestMerchantOnboardingPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
