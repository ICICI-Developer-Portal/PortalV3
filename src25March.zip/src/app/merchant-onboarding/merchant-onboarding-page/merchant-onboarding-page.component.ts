
import { FormBuilder, FormGroup, FormArray, FormControl, Validators, AbstractControl } from '@angular/forms'; 
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MerchantOnboardingService } from 'src/app/services/merchant-onboarding.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Console } from 'console';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { BillingEngineService } from 'src/app/services/billing-engine.service';
import { Config } from 'src/app/config/config';



declare var $: any;

/* uat */

@Component({
  selector: 'app-merchant-onboarding-page',
  templateUrl: './merchant-onboarding-page.component.html',
  styleUrls: ['./merchant-onboarding-page.component.css'],
  providers: [DatePipe],
})
export class MerchantOnboardingPageComponent implements OnInit {
  restUrl: string;
  reactiveForm: FormGroup;
  scndreactiveForm: FormGroup; // new form for ip/cerificate replacement
  selectedEnv;
  selectedEnv2;
  selectedApp;
  selectedAPI;
  credentials: any = [];

  maxDate: any;
  minDate: any;
  userAppDetail: any = [];

  productDetail: any = [];
  productApiService: any = {};
  apiServiceUrlList: any = [];
  ipListArray: any = [];
  apiService: any;
  kvmCallbackURL:any[];
   urlListArray=[];
   updateURL=[];


  apiUrl: any;
  buUsername;
  buEmail;
  buName;
  selectedApiProduct;
  checkedStatus: boolean = false;
  IPList: boolean = false;

  IPLists: boolean = false;
  showMode: boolean = false;
  additionalField: boolean = false;
  sendAdditionalHeader: boolean = false;

  checkboxValues: any = "Select";
  showText1: boolean = false;
  showText2: boolean = false;
  showText3: boolean = false;



  Attach;
  AttachIProcess;

  fileName;
  filetype;

  fileName1;
  otherFile;
  otherFilextnsnMatch;
  filetype1;
  fileCT;
  extnsn;
  fileCT1;
  extnsn1;
  otherFilextnsn;

  nodalAcnt: boolean = false;
  nodalValue;
  fileTest: boolean = false;
  fileTest1: boolean = false;


  showfirstForm: boolean = true;
  showscndForm: boolean = true;

  getDetailEnable: boolean = true;  //19/1/21

  apiList:any=[];
  appList;
  kvmData: any;
  appJiraId: any;
  appLocalDBData: any;
  default;
  kvmConfigKey:any;
  contain_selfdomain:any='';
  ICICBANK:any='';
  textareaLength:number;
  progress: number;
  kvmAGGRID:any="";

  constructor(private router: Router,
    private merchantSrvc: MerchantOnboardingService,
    private spinnerService: Ng4LoadingSpinnerService,
    private formBuilder: FormBuilder,
    private HttpClient: HttpClient,
    public datepipe: DatePipe,
    private beSrvc: BillingEngineService,
    private config: Config,

  ) {
    this.restUrl = config.apiUrl;
    /* this.dateInput= datepipe.transform(Date.now(),'dd-MMMM-yyyy');*/
    // this.maxDate = datepipe.transform(new Date(), 'yyyy-MM-dd');
    // this. reactiveForm.get('basicDetailsSection.sendAdditionalHeaders').setValue(this.default, {onlySelf: true});

  }

  ngOnInit() {
    let reset = "";
    this.form(reset)

    //getProductDetail
    this.spinnerService.show();
    this.merchantSrvc.getProductDetail().subscribe((data: any) => {
      let response = JSON.parse(data._body);
      this.productDetail = response;

      for (let i in response) {
        let key = response[i].apiProductName;
        this.productApiService[key] = response[i].apiProducts;
      }
      this.spinnerService.hide();
      // console.log("response=="+ response);
    },
      err => {
        this.spinnerService.hide();
        console.log('err', err);

      });
    //Prepopulate the field
    this.buEmail = localStorage.getItem("email");
    this.buName = localStorage.getItem("Firstname");
    this.buUsername = localStorage.getItem("username");
    this.reactiveForm.get(['basicDetailsSection', 'buID']).setValue(this.buUsername);
    this.reactiveForm.get(['basicDetailsSection', 'BusinessUserName']).setValue(this.buName);
    this.reactiveForm.get(['basicDetailsSection', 'BusinessUserEmail']).setValue(this.buEmail);

    /* Set above value in second form */
    this.scndreactiveForm.get(['secondSection', 'buID']).setValue(this.buUsername);
    this.scndreactiveForm.get(['secondSection', 'BusinessUserName']).setValue(this.buName);
    this.scndreactiveForm.get(['secondSection', 'BusinessUserEmail']).setValue(this.buEmail);
    this.OnBUIDchange(this.buUsername);

    var checkList = document.getElementById('list1');

    $(".anchor").click(function () {
      if (checkList.classList.contains('visible'))
        checkList.classList.remove('visible');
      else
        checkList.classList.add('visible');
    })

    //  this.getKVMAppDetails();
    this.reactiveForm.get(['basicDetailsSection', 'callbackRoutingType']).setValue("singleUrl");
    this.reactiveForm.get(['basicDetailsSection', 'spikeArrestThreshold']).setValue("199ps");


  }
  selectChangeHandlerEnv(event: any) {

    this.selectedEnv = event.target.value;
    console.log(this.selectedEnv);
    console.log(this.reactiveForm.value.basicDetailsSection.Environment);
  }
  envChangeHandler(event: any) {

    this.selectedEnv2 = event.target.value;
  

  }

  addIPinToArray() { //19/1/21
    const ip = this.scndreactiveForm.get('secondSection').get('dynamicIPLists');
    console.log(ip.value);
    if (ip.value.length <= 19) {
      if (this.ipListArray.includes(ip.value)) {
        alert("You can not add same IP twice");

      }
      else {
        this.ipListArray.push(ip.value)
      }

    } else {

    }
  }


  initipRows() {
    return this.formBuilder.group({
      IPList: ['']
    });
  }
  /**
   * add and remove additional IP
   */

  addNewIPField() {
    const control = <FormArray>this.reactiveForm.get('basicDetailsSection').get('IPList');
    //console.log(control.at(0));
    if (control.length <= 19) {
      control.push(new FormControl(null, [Validators.required, Validators.pattern('^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$')]))
    } else { }
  }

  deleteRow(i: number) {
    //console.log(i);
    const control = <FormArray>this.reactiveForm.get('basicDetailsSection').get('IPList');

    control.removeAt(i);

  }
  isNodal(e){
    e.target.value;
     if( e.target.value=="Yes"){
       this.nodalValue = "true"; 
     }
     else{
       this.nodalValue = "false";
     }
     console.log( e.target.value);
   }
  form(reset) {
    const ipReg = '^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$';
   // const regURL = "(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?";
    const regURL = /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/;
    const alphanumericbraces= /^[a-z\d\-_\s\()]+$/;

    this.reactiveForm = new FormGroup({
      'basicDetailsSection': new FormGroup({
        "section": new FormControl(''),
        "buID": new FormControl('', [Validators.required]),
        "BusinessUserName": new FormControl('', [Validators.required]),
        "BusinessUserHeadID": new FormControl('', [Validators.required]),
        "BusinessUserEmail": new FormControl('', [Validators.required, Validators.email]),
        "Environment": new FormControl('', [Validators.required]),
        "noteFile": new FormControl(""),
        "noteNumber": new FormControl(""),
        "merchantName": new FormControl('', [Validators.required, Validators.pattern(/^([a-zA-Z0-9 _-]+)$/)]),
        "Decryption": new FormControl(''),
        "Authentication_Mode": new FormControl('ip'),
        "SSL_Type": new FormControl('oneway'),
        "deleteResponseCode": new FormControl('yes'),
        "merchantHeaderKeys": new FormControl(''),
        "sendAdditionalHeaders": new FormControl('no'),
        "merchantHeaderValues": new FormControl(''),
        "callbackRoutingType": new FormControl(''),
        "spikeArrestThreshold": new FormControl(''),
        "DecryptionKey": new FormControl(''),
        "RelationshipManager": new FormControl('', [Validators.required]),
        "RequestDate": new FormControl(''),
        "Domain": new FormControl('', [Validators.required]),
        "DomainAPI": new FormControl(''),  //,[Validators.required]
        "IPList": new FormArray([
          // <FormArray>this.reactiveForm.get('basicDetailsSection').get('ipRows'),Validators.required
          new FormControl(null, [Validators.required,Validators.pattern(ipReg)]),//Validators.required,
        ]),

        "CallbackURL":  new FormControl(null, [Validators.required,Validators.pattern(regURL)]),
        "APIURL": new FormControl('', [Validators.required]),
        "Certificate": new FormControl('', [Validators.required]),
        "Remarks": new FormControl(''),
        "APIName": new FormControl(''),
        "Mode": new FormControl('hybrid_generic'),
        "nDa": new FormControl('', [Validators.required]),
        "ClientCode": new FormControl('1234'),
        "MerchantId": new FormControl('', [Validators.required]),
        "MerchantEmail": new FormControl('', [Validators.required, Validators.email, this.emailMatchValidator]),
        "nodalAccount" :new FormControl(''),
        "buUnitHead": new FormControl('', [Validators.required]),
        "buTeamFPR": new FormControl('', [Validators.required]),
        "dptName": new FormControl('', [Validators.required]),
        "otherFile": new FormControl()


      })
    })
    this.scndreactiveForm = new FormGroup({
      'secondSection': new FormGroup({
        "buID": new FormControl('', [Validators.required]),
        "dynamicIPLists": new FormControl(null, [Validators.pattern(ipReg)]),
        

        "BusinessUserName": new FormControl('', [Validators.required]),
        "BusinessUserHeadID": new FormControl('', [Validators.required]),
        "BusinessUserEmail": new FormControl('', [Validators.required, Validators.email]),
        "searchByEmail": new FormControl('', [Validators.required, Validators.email]),
        "appList": new FormControl("",[Validators.required]),
        "apiList": new FormControl("",[Validators.required]),
        "nodalAccount": new FormControl(""),
        "Environment": new FormControl('', [Validators.required]),
        "noteFile": new FormControl(""),
        "noteNumber": new FormControl(""),
        "certificate": new FormControl(''), ////19/1/21
        "Ipwhitlisting": new FormControl(''), ////19/1/21
        "UpdateCallbackURL": new FormControl(''),
        "certificate2":new FormControl(''),
        "dynamicURLLists":new FormControl(),
        "Remarks": new FormControl(""), ////19/1/21
        "buUnitHead": new FormControl("", [Validators.required]),
        "buTeamFPR": new FormControl("", [Validators.required]),
        "dptName": new FormControl('', [Validators.required]),
       "otherFile": new FormControl()



      })
    })



  }
  formdataAndSubmission() {
    let json = {
      "buID": this.reactiveForm.value.basicDetailsSection.buID,
      "BusinessUserName": this.reactiveForm.value.basicDetailsSection.BusinessUserName,
      "BusinessUserHeadID": this.reactiveForm.value.basicDetailsSection.BusinessUserHeadID,
      "BusinessUserEmail": this.reactiveForm.value.basicDetailsSection.BusinessUserEmail,
      "Environment": this.reactiveForm.value.basicDetailsSection.Environment,
      "noteFile": this.AttachIProcess,
      "noteNumber": this.reactiveForm.value.basicDetailsSection.noteNumber,
      "merchantName": this.reactiveForm.value.basicDetailsSection.merchantName,
      "Decryption": this.reactiveForm.value.basicDetailsSection.Decryption,
      "DecryptionKey": this.reactiveForm.value.basicDetailsSection.DecryptionKey,
      // =================================================================================//
      //                                 additional fields starts
      // =================================================================================//
      "authentication_mode": this.reactiveForm.value.basicDetailsSection.Authentication_Mode, //authentication_mode
      "sslType": this.reactiveForm.value.basicDetailsSection.SSL_Type,//sslType
      "deleteResponseCode": this.reactiveForm.value.basicDetailsSection.deleteResponseCode,//deleteResponseCode
      "sendAdditionalHeaders": this.reactiveForm.value.basicDetailsSection.sendAdditionalHeaders,//sendAdditionalHeaders
      "merchantHeaderKeys": this.reactiveForm.value.basicDetailsSection.merchantHeaderKeys,//merchantHeaderKeys
      "merchantHeaderValues": this.reactiveForm.value.basicDetailsSection.merchantHeaderValues, //merchantHeaderValues
      "callbackRoutingType": this.reactiveForm.value.basicDetailsSection.callbackRoutingType, //callbackRoutingType
      "spikeArrestThreshold": this.reactiveForm.value.basicDetailsSection.spikeArrestThreshold,//spikeArrestThreshold
      // =================================================================================//
      //                                 additional fields ends
      // =================================================================================//
      "RelationshipManager": this.reactiveForm.value.basicDetailsSection.RelationshipManager,
      "RequestDate": Date.now(),  //this.reactiveForm.value.basicDetailsSection.RequestDate
      "Domain": this.reactiveForm.value.basicDetailsSection.Domain,
      "DomainAPI": this.apiService,
      "IPList": this.reactiveForm.value.basicDetailsSection.IPList,
      "CallbackURL": this.reactiveForm.value.basicDetailsSection.CallbackURL,
      "APIURL": this.apiUrl,
      "Certificate": this.Attach,
      "Remarks": this.reactiveForm.value.basicDetailsSection.Remarks,
      "APIName": this.reactiveForm.value.basicDetailsSection.APIName,
      "Mode": this.reactiveForm.value.basicDetailsSection.Mode,
      "nDa": this.reactiveForm.value.basicDetailsSection.nDa,
      "ClientCode": this.reactiveForm.value.basicDetailsSection.ClientCode,
      "MerchantId": this.reactiveForm.value.basicDetailsSection.MerchantId,
      "MerchantEmail": this.reactiveForm.value.basicDetailsSection.MerchantEmail,
      "isNodal" :this.nodalValue,
      "buUnitHead":  this.reactiveForm.value.basicDetailsSection.buUnitHead,
      "buTeamFPR":  this.reactiveForm.value.basicDetailsSection.buTeamFPR,
      "dptName":  this.reactiveForm.value.basicDetailsSection.dptName,
      "otherFile":  this.reactiveForm.value.basicDetailsSection.otherFile,
      "validation":  "", // e-collection yes/No
      "isInternal":  "",// e-collection true or false
    

      "operationType": "INSERT",
    }
    if ((json["Domain"] == "EazyPay" || json["Domain"] == "EazyPay 1.0" || json["Domain"] == "EazyPay 2.0") && json["CallbackURL"] == '') {

      alert("Callback URL is mandatory for EazyPay product");
      return false;

    }
    if (json["Domain"] == "CIB" && json["Mode"] == '') {

      alert("Encryption method is mandatory for CIB product");
      return false;

    }

    const formData = new FormData();
   
    formData.append("bUserId", json["buID"]); //1
    formData.append("bUserName", json["BusinessUserName"]); //2
    formData.append("bUserHId", json["BusinessUserHeadID"]); //1
    formData.append("bUserEmail", json["BusinessUserEmail"]); //2
    formData.append("Environment", json["Environment"]); //1
    // "noteFile":   this.reactiveForm.value.basicDetailsSection.noteFile,
    // "noteNumber":   this.reactiveForm.value.basicDetailsSection.noteNumber,
    // formData.append("noteFile", json["noteFile"]); //1
    //FOR CONVERTING IN BINARY

    if (json["Domain"] == "Composite") {
      formData.append("isNodal", this.nodalValue); //1

    }
    if (this.selectedEnv == "PROD") {
      if ((this.AttachIProcess !== "" && this.reactiveForm.value.basicDetailsSection.noteNumber !== "")) {

        let B: any = (<HTMLInputElement>document.getElementById("noteFile")).files;
        for (let k = 0; k < B.length; k++) {
          formData.append("noteFile", B[k]); //34
        }
        formData.append("noteNumber", json["noteNumber"]); //1
      }
      let c: any = (<HTMLInputElement>document.getElementById("otherFile")).files;
      if(c.length > 0){
       // let c: any = (<HTMLInputElement>document.getElementById("otherFile")).files;
        console.log(c.length);
        for (let k = 0; k < c.length; k++) {
          formData.append("otherFile", c[k]);
        }
      }else{
        formData.append("otherFile", "");
      }
       
  
    }
    if (this.selectedEnv == "UAT") {
      formData.append("noteFile", "")
      formData.append("noteNumber", ""); //1
      formData.append("otherFile", "");
    }

    formData.append("merchantName", json["merchantName"]); //1
    formData.append("encryptRequired", json["Decryption"]); //1
    // =================================================================================//
    //                                 additional fields starts
    // =================================================================================//
    formData.append("authentication_mode", json["authentication_mode"]);
    formData.append("sslType", json["sslType"]);
    formData.append("deleteResponseCode", json["deleteResponseCode"]);
    formData.append("sendAdditionalHeaders", json["sendAdditionalHeaders"]);
    formData.append("merchantHeaderKeys", json["merchantHeaderKeys"]);
    formData.append("merchantHeaderValues", json["merchantHeaderValues"]);
    formData.append("callbackRoutingType", json["callbackRoutingType"]);
    formData.append("spikeArrestThreshold", json["spikeArrestThreshold"]);

    formData.append("buUnitHead", json["buUnitHead"]); //2
    formData.append("buTeamFPR", json["buTeamFPR"]); //2
    formData.append("dptName", json["dptName"]); //2
     //2
    
    // =================================================================================//
    //                                 additional fields ends
    // =================================================================================//
    formData.append("relationManagerId", json["RelationshipManager"]); //2
    formData.append("requestDate", this.datepipe.transform(new Date(json["RequestDate"]), 'dd-MMM-yyyy')); //1
    formData.append("apiProduct", json["Domain"]); //2
    formData.append("apiProductServices", json["DomainAPI"]); //1
    formData.append("ipList", json["IPList"]); //2
    formData.append("callBackUrl", json["CallbackURL"]); //1
    formData.append("apiUrl", json["APIURL"]); //2




    let a: any = (<HTMLInputElement>document.getElementById("Certificate")).files;

    for (let k = 0; k < a.length; k++) {

      formData.append("certificate", a[k]); //34

    }
    formData.append("remarks", json["Remarks"]); //2
    formData.append("apiName", json["APIName"]); //1
    formData.append("encryptMode", json["Mode"]); //2
    formData.append("status", "Pending");
    // Unused request key
    formData.append("ndaSign", "true");
    formData.append("clientCode", json["ClientCode"]);
    formData.append("merchantId", json["MerchantId"]);
    formData.append("description", "");
    formData.append("merchantEmail", json["MerchantEmail"]);
    formData.append("operationType", json["operationType"]);
if( this.reactiveForm.value.basicDetailsSection.Domain=="Composite"){
}
    console.log(formData)
    // alert("rchd")

    this.HttpClient.post<any>(

      //  "https://developer.icicibank.com/rest/merchantOnboard",
  //   this.restUrl + "saveMerchantOnboard1",saveMerchantOnboardRevamp2
 this.restUrl  + "saveMerchantOnboard23",

  

      formData

    ).subscribe(

      res => {
        // console.log(res);
        if (res.status == true || res.status == "true") {
          alert(res.message);
          this.router.navigate(["onboardedMerchantList/" + json["buID"]]);
          this.reactiveForm.reset();

        } else {
          alert(res.message);
        }
        this.spinnerService.hide();
      },

      err => {
        console.log('err', err);
        this.spinnerService.hide();
      });

  }
  saveMerchantData($event) {
    console.log(this.reactiveForm.value);

    this.spinnerService.show();
    // alert(this.selectedEnv)
    //  console.log(this.Attach)
    if (this.selectedEnv == "PROD") {
      if ((this.AttachIProcess !== "" || this.reactiveForm.value.basicDetailsSection.noteNumber !== "")) {
        this.formdataAndSubmission();
      }
      else {
        alert("kindly upload  Approved I-Process Note File & enter Note Number value.")
        return false;
      }
    }
    else if (this.selectedEnv == "UAT") {
      // alert("hiii")
      this.formdataAndSubmission();

    }


  }
  selectChangeHandler(event) {
    this.checkboxValues = [];
    this.apiUrl = [];
    this.apiService = [];
    this.reactiveForm.get(['basicDetailsSection', 'APIURL']).setValue("");
    this.reactiveForm.get(['basicDetailsSection', 'MerchantId']).setValue("");

    $('input[name="selectAll"]').prop('checked', false);
    this.checkedStatus = false;
    this.selectedApiProduct=event.target.value;
    let val = event.target.value;
    this.apiServiceUrlList = this.productApiService[val];
    if (val == "CIB" || val == "EazyPay" || val == "EazyPay 1.0" || val == "EazyPay 2.0") {
      this.showMode = true;
      // const regURL = "(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?";
    const regURL = /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/;

      
      this.reactiveForm.get('basicDetailsSection.CallbackURL').setValidators([Validators.required, Validators.pattern(regURL)])
      this.reactiveForm.get('basicDetailsSection.CallbackURL').updateValueAndValidity()
      this.reactiveForm.get('basicDetailsSection.nodalAccount').clearValidators()
      this.reactiveForm.get('basicDetailsSection.nodalAccount').updateValueAndValidity()
    } else {
      this.showMode = false;
    }

    if (val == "CIB") {
      this.showText1 = true;
      this.showText2 = false;
      this.showText3 = false;
      this.additionalField = false;
      this.reactiveForm.get('basicDetailsSection.nodalAccount').clearValidators()
      this.reactiveForm.get('basicDetailsSection.nodalAccount').updateValueAndValidity()
      // this.showMode = true;
    } else if (val == "Composite") {
   
      
        this.reactiveForm.get('basicDetailsSection.CallbackURL').clearValidators()
      this.reactiveForm.get('basicDetailsSection.CallbackURL').updateValueAndValidity()

       
      this.reactiveForm.get('basicDetailsSection.nodalAccount').setValidators([Validators.required])
      this.reactiveForm.get('basicDetailsSection.nodalAccount').updateValueAndValidity()
  
  
      
      this.showText2 = true;
      this.showText1 = false;
      this.showText3 = false;
      this.additionalField = false;

      // this.showMode = false;
    } else if  (val == "EazyPay" || val == "EazyPay 1.0" || val == "EazyPay 2.0") {
      this.additionalField = true;
      this.showText3 = true;
      this.showText1 = false;
      this.showText2 = false;

      // var code = (event.which) ? event.which : event.keyCode;
      // if (code > 31 && (code < 48 || code > 57)) {
      //     event.preventDefault();
      this.reactiveForm.get('basicDetailsSection.nodalAccount').clearValidators()
      this.reactiveForm.get('basicDetailsSection.nodalAccount').updateValueAndValidity()
      // }
      console.log(this.reactiveForm.get('basicDetailsSection.MerchantId'))

      // console.log(this.reactiveForm.get('basicDetailsSection.MerchantId').value)
    

    } 
    else {
      this.showText2 = false;
      this.showText1 = false;
      this.showText3 = false;
      this.additionalField = false;
    }
  }
  sendAdditionalHeaders(event) {
   // alert(event.target.value)
    let val = event.target.value;
    console.log(this.sendAdditionalHeader,val)

    console.log(this.sendAdditionalHeader ==val)
    if (val == "Yes") {
      
      this.sendAdditionalHeader = false;
    } else {
      this.sendAdditionalHeader = true;
    }
  }

  onServiceChange(event) {
    /*Start here  */
    let that = this;
    let _apiUrl = [];
    let env = this.reactiveForm.value.basicDetailsSection.Environment;
    if ($('input[name="apiService"]:checkbox:not(":checked")').length) {
      $('input[name="selectAll"]').prop('checked', false);

    }
    else {
      $('input[name="selectAll"]').prop('checked', true);
    }

    this.checkboxValues = $('input[name="apiService"]:checked').map(function () {

      let val = $(this).val();

      let serviceName = that.apiServiceUrlList[val].apiName;

      if (env == "PROD") {
        _apiUrl.push(that.apiServiceUrlList[val].apiPRODUrl)
      } else if (env == "UAT") {
        _apiUrl.push(that.apiServiceUrlList[val].apiUATUrl)
      } else {
        _apiUrl.push(that.apiServiceUrlList[val].apiUATUrl)
      }
      return serviceName;
    })
      .get()
      .join(', ');
    // console.log(this.checkboxValues)
    this.apiService = this.checkboxValues;
    this.apiUrl = _apiUrl.toString();
    //  console.log(this.apiUrl);
    console.log(22222);
    this.reactiveForm.get(['basicDetailsSection', 'APIURL']).setValue(_apiUrl.toString());
    /* End here */
  }


  OnBUIDchange(val) {


    let json = {
      bUserId: val
    }
    this.spinnerService.show();
    this.merchantSrvc.getBEUserHeadId(json).subscribe((data: any) => {
      let response = JSON.parse(data._body);
      this.spinnerService.hide();
      if (response.status == true && response.data != null) {
        this.reactiveForm.get(['basicDetailsSection', 'BusinessUserHeadID']).setValue(response.data);
        this.scndreactiveForm.get(['secondSection', 'BusinessUserHeadID']).setValue(response.data);

      } else {
        //  console.log(response.message);
      }
      //  console.log("response=="+ response.data);
    },
      err => {
        this.spinnerService.hide();
        console.log('err', err);
      });

  }

  navigateToHistory() {
    this.router.navigate(["onboardedMerchantList/" + localStorage.getItem("username")]);
  }


  getSelectedApiServiceList() {
    let that = this;
    let _apiUrl = [];
    let env = this.reactiveForm.value.basicDetailsSection.Environment;
    this.checkboxValues = $('input[name="apiService"]:checked').map(function () {
      let val = $(this).val();
      let serviceName = that.apiServiceUrlList[val].apiName;
      let serviceURL = that.apiServiceUrlList[val].apiUATUrl;
      _apiUrl.push(serviceURL);
      return serviceName;
    })
      .get()
      .join(', ');
    console.log(this.checkboxValues)
    this.apiService = this.checkboxValues;
    this.apiUrl = _apiUrl.toString();
    this.reactiveForm.get(['basicDetailsSection', 'APIURL']).setValue(_apiUrl.toString());
    //    console.log(this.apiUrl);
  }

  // The selectall checkbox will check/ uncheck all items
  checkUncheckAll() {
    let env = this.reactiveForm.value.basicDetailsSection.Environment;
    let _apiName = [];
    let _apiUrl = [];
    let checkbox = document.querySelectorAll('.apiServiceList');
    if (document.querySelectorAll('.selectAll:checked').length > 0) {

      this.checkedStatus = true;
      for (var i = 0; i < checkbox.length; i++) {
        _apiName.push(this.apiServiceUrlList[i].apiName);
        if (env == "PROD") {
          _apiUrl.push(this.apiServiceUrlList[i].apiPRODUrl)
        } else if (env == "UAT") {
          _apiUrl.push(this.apiServiceUrlList[i].apiUATUrl)
        } else {
          _apiUrl.push(this.apiServiceUrlList[i].apiUATUrl)
        }
      }
      this.apiUrl = _apiUrl.toString();
      this.checkboxValues = _apiName.toString();
      this.apiService = this.checkboxValues;
      console.log(11111);
      this.reactiveForm.get(['basicDetailsSection', 'APIURL']).setValue(_apiUrl.toString());
    }
    else {

      this.checkedStatus = false;
      _apiName = [];
      //this.apiUrl = _apiUrl.toString();
      this.checkboxValues = _apiName.toString();
      this.apiUrl = [];
      this.apiService = [];
      this.reactiveForm.get(['basicDetailsSection', 'APIURL']).setValue("");

    }
  }
  readFile(fileEvent: any) {
    const file = fileEvent.target.files[0];
    const allowed_types = ['crt', 'txt', 'key'];

    if (fileEvent.target.files && fileEvent.target.files[0]) {

      this.fileName = fileEvent.target.files[0].name;

      this.filetype = fileEvent.target.files[0].type;
      const lastdot = this.fileName.lastIndexOf('.');
      const ext = this.fileName.substring(this.fileName.lastIndexOf('.') + 1);
      this.extnsn = ext;

      if ((allowed_types).includes(ext)) {
        // alert("pass")
        this.fileTest = true;

        $(".fileError").text("");
        $(".fileError").hide();

      }
      else {
        this.filetype = fileEvent.target.files[0].type;
        this.fileTest = false;
        // alert("f")

        // alert(fileEvent.target.files[0].type)
        $(".fileError").text(ext + "File type not allowed.")
        $(".fileError").text('Only  .crt ,.txt,.key file type are  allowed')
        return false;

      }




      const reader = new FileReader();
      let self = this;
      reader.onload = (e: any) => {

        e.target.result.replace("data:image/png;base64,", "");
        //console.log( e.target.result);

        self.Attach = e.target.result.split(',')[1];
      };

      reader.readAsDataURL(file);
    }
  }

  approvedIprocess(fileEvent: any) {
    const file1 = fileEvent.target.files[0];
    const allowed_types1 = ['pdf'];
    if (fileEvent.target.files && fileEvent.target.files[0]) {
      this.fileName1 = fileEvent.target.files[0].name;
      this.filetype1 = fileEvent.target.files[0].type;
      const lastdot = this.fileName1.lastIndexOf('.');
      const ext1 = this.fileName1.substring(this.fileName1.lastIndexOf('.') + 1);
      this.extnsn1 = ext1;

      if ((allowed_types1).includes(ext1)) {
        // alert("pass")
        this.fileTest1 = true;

        $(".fileError1").text("");
        $(".fileError1").hide();

      }
      else {
        this.filetype1 = fileEvent.target.files[0].type;
        this.fileTest1 = false;
        // alert("f")

        $(".fileError1").show();
        // alert(fileEvent.target.files[0].type)
        $(".fileError1").text(ext1 + "File type not allowed.")
        $(".fileError1").text('Only  pdf file type are  allowed')
        return false;

      }
      const reader1 = new FileReader();
      let self1 = this;
      reader1.onload = (e: any) => {
        console.log(e)

        console.log(e.target);

        console.log(e.target.result);

        e.target.result.replace("data:application/pdf;base64,", "");

        self1.AttachIProcess = e.target.result.split(',')[1];
        console.log(self1.AttachIProcess)
      };

      // reader1.readAsDataURL(file1);
    }
  }



  //ext ::  crt ,txt,.key
  SearchMerchantProfile(merchantId) {
    let env= this.scndreactiveForm.value.secondSection.Environment;
    if(env == undefined || env == "" ){
      alert("Please select the environment");
      return false;
    }
    $(".overlay").show();
    this.spinnerService.show();

   //  let json = [merchantId];
    let json = {
      email:merchantId,
      env:this.scndreactiveForm.value.secondSection.Environment
    }

    this.merchantSrvc.getMerchantDetailRevamp(json).subscribe((data: any) => {
      let mDetail = JSON.parse(data._body);
      console.log(mDetail[0])
      console.log(mDetail[0].apps)

      console.log(data._body)
      this.appList = mDetail[0].apps



      if (mDetail.length > 0) {
        this.beSrvc.setUserData(mDetail[0]);
        console.log(mDetail[0])
        this.spinnerService.hide();

        // this.router.navigate(["/UserDetails"]);
      } else {

        alert("Record not found.Validate the merchant email");
        this.spinnerService.hide();

      }

      // $(".overlay").hide();
    },
      err => {
        $(".overlay").hide();
        console.log('err', err);
        this.spinnerService.hide();

      });

  }


  //fetch app detail
  getAppDetail(event, index) {
    //Clear IP array on app change
    this.ipListArray = [];
    // this.urlListArray=[];
    this.nodalAcnt = false;
    this.selectedApp = event.target.value;
    let env= this.scndreactiveForm.value.secondSection.Environment;
    console.log(this.selectedApp);
    this.spinnerService.show();
    let json = {
      email: this.scndreactiveForm.value.secondSection.searchByEmail,
      appName: this.selectedApp,
      env : env
    }
    this.merchantSrvc.getMerchantAppDetailRevamp(json).subscribe((data: any) => {
  //  this.beSrvc.getMerchantAppDetail(json).subscribe((data: any) => {
      let response = JSON.parse(data._body);
      console.log(response)
      let attr = response.attributes;
      for (let i in attr) {
        if (attr[i].name == "jiraId") {
          this.appJiraId = attr[i].value;
          this.getAppDetailFromDB(this.appJiraId);
         // break;
        }
        if (attr[i].name == "KVM_MERCHANT_CONFIG_KEY") {
          this.kvmConfigKey = attr[i].value;
         // this.getAppDetailFromDB(this.appJiraId);
         // break;
        }
        if (attr[i].name == "AGGRID") {
          this.kvmAGGRID = attr[i].value;
         // this.getAppDetailFromDB(this.appJiraId);
         // break;
        }
        if (attr[i].name == "merchantId") {
          this.kvmAGGRID = attr[i].value;
         // this.getAppDetailFromDB(this.appJiraId);
         // break;
        }
        //AGGRID
      }
      this.userAppDetail[0] = response;

      this.credentials[0] = this.userAppDetail[0].credentials;
      console.log(this.credentials[0][0]["apiProducts"][0]['apiproduct'])
    //  this.apiList = this.credentials[0][0]["apiProducts"][0]['apiproduct'];
    let tempArr = response.credentials[0].apiProducts;
    this.apiList =[];
    for(let i in tempArr){
      this.apiList.push(tempArr[i].apiproduct)
    }
      console.log("product List= "+ this.apiList);
      this.spinnerService.hide();
    },
      err => {
        this.spinnerService.hide();
        console.log('err', err);

      });

  }
  getAppDetailFromDB(jiraId) {
    let json = { jiraId: jiraId };
    this.spinnerService.show();
    this.merchantSrvc.getMOAByJiraId(json).subscribe((data: any) => {
      console.log(data._body);
      this.spinnerService.hide();
      if (data._body == "" || data._body == null) {
        alert("No record found in local DB");
        this.appLocalDBData = null;
        return false;
      }
      let response = JSON.parse(data._body);
      this.appLocalDBData = response;

    },
      err => {
        this.spinnerService.hide();
        console.log('err', err);
      });
  }

  //getProductName

  getProductName(event, index) {  //19/1/21
    this.selectedAPI = event.target.value;
    console.log(this.selectedAPI);
    if (this.selectedAPI.includes('Select Product') == false) {
      this.getDetailEnable = false;
    }
    else {
      this.getDetailEnable = true;
    }
    if (this.selectedAPI == "Composite") {
      this.nodalAcnt = true;
    //  this.scndreactiveForm.get('secondSection.apiList').clearValidators()
    //  this.scndreactiveForm.get('secondSection.apiList').updateValueAndValidity()

    
     
    } else {
      // const regURL = "(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?";
    const regURL = /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[-;:&=\+\$,\w]+@)?[A-Za-z0-9.-]+|(?:www.|[-;:&=\+\$,\w]+@)[A-Za-z0-9.-]+)((?:\/[\+~%\/.\w-_]*)?\??(?:[-\+=&;%@.\w_]*)#?(?:[\w]*))?)/;


     // this.scndreactiveForm.get('secondSection.apiList').setValidators([Validators.required, Validators.pattern(regURL)])
    //  this.scndreactiveForm.get('secondSection.apiList').updateValueAndValidity()
      
      this.nodalAcnt = false;
    }

  }
  getAppProductDetail() {
    //Clear IP array on app change
    this.ipListArray = [];
    // this.urlListArray=[];
    if(this.selectedAPI == "Composite"){
      this.selectedApp = this.kvmConfigKey;
    }
    let json ={};
     json = {
      "key": this.selectedApp,
      "product": this.selectedAPI,
      "env": this.scndreactiveForm.value.secondSection.Environment,
      "kvmAGGRID": this.kvmAGGRID
    }
    
    this.getKVMAppDetails(json);
  }

  getKVMAppDetails(json) {

    this.spinnerService.show();
    this.merchantSrvc.getKVMAppDetails(json).subscribe((data: any) => {
      console.log(data._body);
      this.spinnerService.hide();
      if (data._body == "") {
        alert("Product KVM data not found");
        return false;
      }
      let response = JSON.parse(data._body);
      this.kvmData = response;
      let strIplist = "";
      let strURLlist = "";

      if (this.selectedAPI == "Composite") {
        strIplist = this.kvmData.validIpList;
      }else  if(this.selectedAPI == "EazyPay" && this.kvmData.authenticationType == "apikey_ip"){
        strIplist = this.kvmData.validIpList;
      } else
      {
        strIplist = this.kvmData.ipList;
      }
      if((this.selectedAPI == "CIB")){
        this.kvmCallbackURL=this.kvmData.publickey.callbackUrl;
        
      }else{
        this.kvmCallbackURL=this.kvmData.callbackUrl;
      }
      

      if (this.ipListArray.length > 0) {
        let newArray = strIplist.split(",");
        this.ipListArray = this.ipListArray.concat(newArray);
      }else {
        this.ipListArray = strIplist.split(",");
      }

      // if(this.urlListArray.length>0){
      //   let newArray1 = strURLlist.split(",");
      //   this.urlListArray = this.urlListArray.concat(newArray1)
      // }
      // else {
      //   this.urlListArray = strURLlist.split(",");
      // }


    },
      err => {
        this.spinnerService.hide();
        console.log('err', err);
      });
  }
  UpdateAppDetail() {
    let selectedProduct = this.selectedAPI;
    let certificateChecked = false;
    let ipChecked = false;
    let urlChecked = false;
    let updateKeys=[];
    if ($("#checkbox3:checked").length > 0) {
      certificateChecked = true;
      updateKeys.push("KEY");
    } if ($("#checkbox4:checked").length > 0) {
      ipChecked = true;
      updateKeys.push("IP");

    }
    if ($("#checkbox5:checked").length > 0) {
    
    updateKeys.push("URL");
    this.updateURL=this.scndreactiveForm.value.secondSection.dynamicURLLists
    // this.urlListArray.push(this.scndreactiveForm.value.secondSection.dynamicURLLists)


      urlChecked = true;
    }
    if (!certificateChecked && !ipChecked && !urlChecked) {
      alert("Please select IP/Certificate or CallbackURL option to update.");
      return false;
    }
    if (this.selectedApp == undefined || this.selectedAPI == undefined) {
      alert("Please select App and it's Product");
      return false;
    }
    if (this.kvmData && this.kvmData == undefined) {
      alert("App's KVM detail not found");
      return false;
    }
    let json = {

      "bUserId": this.scndreactiveForm.value.secondSection.buID,  // Current data
      "bUserName": this.scndreactiveForm.value.secondSection.BusinessUserName, // Current data
      "bUserEmail": this.scndreactiveForm.value.secondSection.BusinessUserEmail, // Current data
      "bUserHId": this.scndreactiveForm.value.secondSection.BusinessUserHeadID, // Current data
      "merchantName": "", // data from db
      "description": "", //keep empty
      "relationManagerId": "", //local data
      "requestDate": Date.now(),    //today date
      "apiProduct": selectedProduct,
      "apiProductServices": "", //local data
      "ipList": "",              //Current or KVM data
      "callBackUrl":  this.scndreactiveForm.value.secondSection.dynamicURLLists,       //KVM
      "ndaSign": "true",
      "apiUrl": "",
      "certificate": "",//->attachment
      "remarks": "",
      "apiName": "",
      "encryptRequired": "",
      "encryptMode": "",
      "clientCode": "",
      "merchantId": this.kvmAGGRID,
      "status": "Pending",
      "merchantEmail": this.scndreactiveForm.value.secondSection.searchByEmail,  //local db
      "Environment": this.scndreactiveForm.value.secondSection.Environment, //Current
      "noteFile": this.scndreactiveForm.value.secondSection.noteFile,
      "noteNumber":  this.scndreactiveForm.value.secondSection.noteNumber,
      "publicKeyValue": "", //KVM data
      "operationType": "UPDATE",
      "appName": this.selectedApp,
      "authenticationType": "", //KVM data
      "apiKey": "",              // NA
      "enableEncryption": "",  //KVM data
      "isNodal": "",           //KVM data
      "code": "",              //for CIB
      "deleteResponseCode": "", //KVM data
      "sendAdditionalHeaders": "",//KVM data
      "merchantHeaderKeys": "",//KVM data
      "merchantHeaderValues": "",//KVM data
      "callbackRoutingType": "",//KVM data
      "spikeArrestThreshold": "",//KVM data
      "sslType": "", //, String sslType //KVM data
      "buUnitHead":this.scndreactiveForm.value.secondSection.buUnitHead,
      "buTeamFPR":this.scndreactiveForm.value.secondSection.buTeamFPR,
      "dptName":this.scndreactiveForm.value.secondSection.dptName,
      "otherFile":this.scndreactiveForm.value.secondSection.otherFile


    }
   


    if (this.appLocalDBData && this.appLocalDBData !== null) {
      json["apiProductServices"] = this.appLocalDBData.domainApi;
      json["apiUrl"] = this.appLocalDBData.apiUrl;
      json["merchantName"] = this.appLocalDBData.merchantName;
    //  json["merchantId"] = this.appLocalDBData.merchantId;
      json["relationManagerId"] = this.appLocalDBData.relManager;
      json["apiKey"] = this.appLocalDBData.apiKey;

    } else {
      console.log("App local entry not found");
    }

    if (selectedProduct == "Composite") {
      json["authenticationType"] = this.kvmData.authenticationType;
      json["enableEncryption"] = this.kvmData.enablemodeEncryption;
      json["isNodal"] = this.kvmData.isNodal;
      json["encryptMode"] = this.kvmData.mode;
      //json["mode"]= this.kvmData.mode;
      json["publicKeyValue"] = this.kvmData.publicKey;
      json["ipList"] = this.kvmData.validIpList;

    } else if (selectedProduct == "CIB") {
      //code 1 for IP 2 for key and 3 for both
      // json["code"]= "3";
      json["callBackUrl"] = this.kvmData.publickey.callbackUrl;
      json["encryptMode"] = this.kvmData.publickey.mode;
      //json["mode"]= this.kvmData.mode;
      json["publicKeyValue"] = this.kvmData.publickey.publicKey;
      json["ipList"] = this.kvmData.ipList;

    } else if (selectedProduct == "EazyPay") {
      json["authenticationType"] = this.kvmData.authenticationType;
      json["callbackRoutingType"] = this.kvmData.callbackRoutingType;
      json["callBackUrl"] = this.kvmData.callbackUrl;
      json["deleteResponseCode"] = this.kvmData.deleteResponseCode;
      //need cutomization
      json["ipList"] = this.kvmData.ipList;
      if(this.kvmData.authenticationType == "apikey_ip"){
        json["ipList"] = this.kvmData.validIpList;
      }
      json["ipList"] = this.kvmData.ipList;
      json["merchantHeaderKeys"] = this.kvmData.merchantHeaderKeys;
      json["merchantHeaderValues"] = this.kvmData.merchantHeaderValues;
      json["encryptMode"] = this.kvmData.mode;
      json["publicKeyValue"] = this.kvmData.publicKey;
      json["sendAdditionalHeaders"] = this.kvmData.sendAdditionalHeaders;
      json["spikeArrestThreshold"] = this.kvmData.spikeArrestThreshold;
      json["sslType"] = this.kvmData.sslType;

    } else {

    }

    /* Create form data */
    const formData = new FormData();
    formData.append("bUserId", json["bUserId"]); formData.append("bUserName", json["bUserName"]);
    formData.append("bUserEmail", json["bUserEmail"]); formData.append("bUserHId", json["bUserHId"]);
    formData.append("merchantName", json["merchantName"]); formData.append("description", json["description"]);
    formData.append("relationManagerId", json["relationManagerId"]);
    formData.append("requestDate", this.datepipe.transform(new Date(json["requestDate"]), 'dd-MMM-yyyy'));
    formData.append("apiProduct", json["apiProduct"]);
    formData.append("apiProductServices", json["apiProductServices"]);
    // formData.append("ipList", json["ipList"]);
    // formData.append("callBackUrl", json["callBackUrl"]);
    formData.append("ndaSign", json["ndaSign"]); formData.append("apiUrl", json["apiUrl"]);
    formData.append("remarks", json["remarks"]); formData.append("apiName", json["apiName"]);
    formData.append("encryptRequired", json["encryptRequired"]); formData.append("encryptMode", json["encryptMode"]);
    formData.append("clientCode", json["clientCode"]); formData.append("merchantId", json["merchantId"]);
    formData.append("status", json["status"]); formData.append("merchantEmail", json["merchantEmail"]);
  
    formData.append("buUnitHead", json["buUnitHead"]);
    formData.append("buTeamFPR", json["buTeamFPR"]);
    formData.append("dptName", json["dptName"]);
    




    formData.append("Environment", json["Environment"]);
    if (this.scndreactiveForm.value.secondSection.Environment == "PROD") {
      if ((this.AttachIProcess !== "" && this.scndreactiveForm.value.secondSection.noteNumber !== "")) {

        let C: any = (<HTMLInputElement>document.getElementById("noteFile")).files;
        for (let J = 0; J < C.length; J++) {
          formData.append("noteFile", C[J]); //34
        }
        formData.append("noteNumber", json["noteNumber"]); //1
      }
     // if(this.otherFile !== ""){
      let d: any = (<HTMLInputElement>document.getElementById("otherFile2")).files;
      if(d.length > 0){
          let extention = d[0].name.split('.').pop();
          
          console.log("extention", extention);
          
          if (extention.toLowerCase() == "zip") {
          for (let k = 0; k < d.length; k++) {
            formData.append("otherFile", d[k]);
          } 
        }
      }else{
        formData.append("otherFile", "");
      }
       
       
        
           

    //  }
      


    }
    if (this.scndreactiveForm.value.secondSection.Environment == "UAT") {
      formData.append("noteFile", "")
      formData.append("noteNumber", ""); //1
      formData.append("otherFile", "");

    }
    //formData.append("publicKeyValue", json["publicKeyValue"]);
    formData.append("operationType", json["operationType"]); formData.append("appName", json["appName"]);
    formData.append("authenticationType", json["authenticationType"]); formData.append("apiKey", json["apiKey"]);
    formData.append("enableEncryption", json["enableEncryption"]); 
    formData.append("isNodal", this.scndreactiveForm.value.secondSection.nodalAccount);

    //formData.append("code", json["code"]);
    formData.append("deleteResponseCode", json["deleteResponseCode"]);
    formData.append("sendAdditionalHeaders", json["sendAdditionalHeaders"]); formData.append("merchantHeaderKeys", json["merchantHeaderKeys"]);
    formData.append("merchantHeaderValues", json["merchantHeaderValues"]); formData.append("callbackRoutingType", json["callbackRoutingType"]);
    formData.append("spikeArrestThreshold", json["spikeArrestThreshold"]); formData.append("sslType", json["sslType"]);
    if (certificateChecked) {
      let b: any = (<HTMLInputElement>document.getElementById("certificate2")).files;
      console.log(b.length);
      for (let k = 0; k < b.length; k++) {
        formData.append("certificate", b[k]);
      }
      formData.append("publicKeyValue", "");
    } else {
      formData.append("certificate", "");
      formData.append("publicKeyValue", json["publicKeyValue"]);
    }
    if (ipChecked) {
      formData.append("ipList", this.ipListArray.toString()); // ip list from array
    } else {
      formData.append("ipList", json["ipList"]);
    }
    // this.urlListArray
    if (urlChecked) {   
      if( this.scndreactiveForm.value.secondSection.dynamicURLLists && this.scndreactiveForm.value.secondSection.dynamicURLLists!=""){
      formData.append("callBackUrl", this.scndreactiveForm.value.secondSection.dynamicURLLists);

      }
      else{

        alert("Callback URL is mandatory for update");
        return false;
        /* this.urlListArray.push(this.kvmData.callbackUrl)

        formData.append("callBackUrl", this.urlListArray.toString()); */ // ip list from array
      }
   
    } else {
      formData.append("callBackUrl", json["callBackUrl"]);
    }
    if (certificateChecked && ipChecked) {
      formData.append("code", "3");
    } else if (ipChecked) {
      formData.append("code", "1");
    } else if (certificateChecked) {
      formData.append("code", "2");
    } else {
      formData.append("code", "0");
    }
    
    formData.append("updateKeys", updateKeys.toString());
    /* Submit data  */
    this.HttpClient.post<any>(
      // this.restUrl + "saveMerchantOnboardRevamp2",
      this.restUrl+"saveMerchantOnboardRevamp23",
      formData
    ).subscribe(
      res => {
        console.log(res);
        if (res && res.message) {
          alert(res.message);
        } else {
          alert(res.message);
        }

      }, err => {
        console.log('err', err);
      },
    );
  }
  deleteRemoveObjectFromCart($e) {
    console.log($e.target.getAttribute("id"))
    this.ipListArray.splice($e.target.getAttribute("id"), 1);
    console.log(this.ipListArray)
    console.log(this.ipListArray)
  }
alphanumericUnderscore(event){
var inp = String.fromCharCode(event.keyCode);
// Allow numbers, alpahbets, space, underscore
// if (/[a-zA-Z0-9-_ ]/.test(inp)) {
  //Allow numbers, alpahbets, underscore
if (/[A-Za-z0-9_]/.test(inp)) {

  return true;
} else {
  event.preventDefault();
  return false;
}
  }
  merchantIDValidation(e){
console.log(this.selectedApiProduct)
let charCode = (e.which) ? e.which : e.keyCode;

if(this.selectedApiProduct=="EazyPay" || this.selectedApiProduct=="EazyPay 1.0" || this.selectedApiProduct=="EazyPay 2.0" ){
  this.textareaLength=6
  if (charCode > 31 && (charCode < 48 || charCode > 57)) {
    return false;
  } 
}
  else{
    this.textareaLength=null;
    var inp = String.fromCharCode(e.keyCode);
      //Allow numbers, alpahbets, underscore
    if (/[A-Za-z0-9]/.test(inp)) {
      return true;
    } else {
      e.preventDefault();
      return false;
    }
  }
}

selfDomain(){
  console.log(1);
let e =  this.reactiveForm.value.basicDetailsSection.MerchantEmail;

let index = e.toLowerCase().indexOf("icicibank");
if(index > -1){
  console.log(2);
  this.contain_selfdomain = "Invalid";
}else{
  console.log(3);
  this.contain_selfdomain = '';
}
}


// 15feb22
emailMatchValidator(control: AbstractControl) {
  if (control.value.includes("icicibank")) {
    // this.ICICBANK="Invalid";
    return  {invalidFormat: "Merchant Email can not be icici bank email."};
 } else {
 

   return {  };
 }
// }
}

// 4march 22
upload(fileEvent: any) {

  const file1 = fileEvent.target.files[0];
    const allowed_types2 = ['zip'];
    if (fileEvent.target.files && fileEvent.target.files[0]) {
      this.otherFile = fileEvent.target.files[0].name;
      this.filetype1 = fileEvent.target.files[0].type;
      const lastdot = this.otherFile.lastIndexOf('.');
      const ext1 = this.otherFile.substring(this.otherFile.lastIndexOf('.') + 1);
      this.otherFilextnsn = ext1;

      if ((allowed_types2).includes(ext1)) {
        this.otherFilextnsnMatch="";

      }
      else{
this.otherFilextnsnMatch= "Only zip file are allowed.";


      }
        // alert("pass") 
}

}

}


