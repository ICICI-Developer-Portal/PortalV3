import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-engine',
  templateUrl: './billing-engine.component.html',
  styleUrls: ['./billing-engine.component.css']
})
export class BillingEngineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
