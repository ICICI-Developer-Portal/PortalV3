import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-newpartner',
  templateUrl: './newpartner.component.html',
  styleUrls: ['./newpartner.component.css']
})
export class NewpartnerComponent implements OnInit {
  
  newpartner: FormGroup;
  submitted = false;
  

  constructor(private formBuilder: FormBuilder )
  { }

  ngOnInit() {
   
   
    this.newpartner = this.formBuilder.group({
      
      Name: ['', Validators.required],
      MobileNumber: ['', Validators.required],

      EmailID: ['', [Validators.required, Validators.email]],
      Location: ['', [Validators.required]],
      Remarks: ['', Validators.required]
  }, {
      
  });
}

// convenience getter for easy access to form fields
get f() { return this.newpartner.controls; }

onSubmit() {
  this.submitted = true;

  // stop here if form is invalid
  if (this.newpartner.invalid) {
      return;
  }

  alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.newpartner.value))
}
  }


