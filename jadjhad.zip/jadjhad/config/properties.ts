export const WARN = {
  DELETE: "Are you sure to delete"
};
