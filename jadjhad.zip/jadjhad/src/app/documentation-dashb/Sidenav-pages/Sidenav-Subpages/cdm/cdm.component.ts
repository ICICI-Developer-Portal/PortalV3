import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cdm',
  templateUrl: './cdm.component.html',
  //styleUrls: ['./cdm.component.css']
})
export class CdmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
