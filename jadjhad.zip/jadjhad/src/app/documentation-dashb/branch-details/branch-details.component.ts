//import { Component, OnInit, TemplateRef, Pipe, ɵConsole } from "@angular/core";
import { Component, OnInit, TemplateRef, ViewChild, ViewChildren, ElementRef, QueryList, EventEmitter, Output, Input } from '@angular/core';

import { DashboardService, LoginService } from "src/app/services";
import { NgxXml2jsonService } from "ngx-xml2json";
import { BsModalRef, BsModalService } from "ngx-bootstrap";
import { DomSanitizer } from "@angular/platform-browser";
import { ActivatedRoute } from "@angular/router";
import { Ng4LoadingSpinnerService } from "ng4-loading-spinner";
import { CONSTANTS } from 'config/application-constant';
import { Router } from "@angular/router";
import { ToasterService, Toast } from 'angular2-toaster';

declare var $: any;
@Component({
  selector: "app-branch-details",
  templateUrl: "./branch-details.component.html"
  //styleUrls: ['./branch-details.component.css']
})
export class BranchDetailsComponent implements OnInit {
  id: any;
  resp: any;
  description: any;
  branchId: any;
  obj: any;
  image:any;
  file:any;
  faq:any = false;
  faqEazypay:any= false;
  eazypay:any ;
  compositpay:any;
  faqObj:any;
  faqHeader:any;
  faqObjQues:any=[];
  faqObjQues_eazy:any=[];
  faqObjAns:any=[];
  faqObjAns_eazy:any=[];
  faqObjList:any;
  faqHeaderList:any;
  

  /** @class BranchDetailsComponent
   * @constructor
   */
  constructor(
    private route: ActivatedRoute,
    private adm: LoginService,
    private ngxXml2jsonService: NgxXml2jsonService,
    private modalService: BsModalService,
    private sanitizer: DomSanitizer,
    private spinnerService: Ng4LoadingSpinnerService,
    private router: Router,
    private toasterService: ToasterService,
    private dashboardService: DashboardService
  ) {
    this.route.params.subscribe(params => {
      this.branchId = params["id"];
      this.newApplication();
      let num = this.branchId;
      if(num === "201" || num === 201 ){
        this.faq= false;
        this.faqEazypay= true;
        this.eazypay= true;
        this.compositpay= false;
        
      }else if(num === "207" || num === 207){
        this.faq= true;
        this.faqEazypay= false;
        this.compositpay= true;
        this.eazypay= false;
      }else{
        this.faq= false;
        this.eazypay= false;
        this.compositpay= false;
        this.faqEazypay= false;
      }
      if(num === "177" || num === 177){
        this.image = "https://developer.icicibank.com/assets/images/BBPS.png";
      }
    });
  }
  constants = CONSTANTS;
  ngOnInit() {
    this.spinnerService.hide();
    this.adm.faq().subscribe((data:any)=> {
      this.faqObjList = data._body;
      this.faqObjList= this.faqObjList.replace(/\\n/g, "\\\\n")
      this.faqObj = JSON.parse(this.faqObjList);
     for (var i  in this.faqObj){
       if(this.faqObj[i][0] ==='Eazypay'){
          this.faqObjQues_eazy.push(this.faqObj[i][1])
          this.faqObjAns_eazy.push(this.faqObj[i][2])
          this.faqObjAns_eazy= this.faqObjAns_eazy.map(function(str) {
            return str.replace(/\\n/g, '\n')
          });
       }else if(this.faqObj[i][0] ==='CompositeAPI'){
          this.faqObjQues.push(this.faqObj[i][1])
          this.faqObjAns.push(this.faqObj[i][2])
          this.faqObjAns= this.faqObjAns.map(function(str) {
            return str.replace(/\\n/g, '\n')
          });
      }
      
      }
      //this.faqHeaderList = JSON.parse(this.faqObjList)
     // this.faqHeader = this.faqHeaderList["1"][0]

     $('ul li a[data-toggle="tab"]').removeClass('active');
     $('ul li a[data-toggle="tab"]').removeClass('show');
    
     $('ul li a[data-toggle="dropdown"]').removeClass('active');
     $('ul li a[data-toggle="dropdown"]').removeClass('show');
     $('ul li .documetationClass').addClass('active');
  },
  err => {
    console.log('err', err);
   // this.router.navigate(['error']);
    this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    
  },)

  }
 
  /** get branch node details
   * @class BranchDetailsComponent
   * @method newApplication
   */
  newApplicationOld() {
    this.spinnerService.show();
    this.adm.api_description(this.branchId).subscribe((data: any) => {
      var response = data._body;
      this.spinnerService.hide();
      this.obj = JSON.parse(response);
      this.resp = this.obj[0].TAB_NAME;
      this.description = this.obj[0].DESCRIPTION;
      this.image = this.obj[0].IMAGE_URL;
      this.file = this.obj[0].FILE_URL;
     // console.log("image=="+this.image+"file==="+this.file);
      if(this.branchId === "177" || this.branchId === 177){
        this.image = "https://developer.icicibank.com/assets/images/BBPS.png";
      }


      //test 
      const b64toBlob = (b64Data, contentType='', sliceSize=512) => {
        const byteCharacters = atob(b64Data);
        const byteArrays = [];
      
        for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
          const slice = byteCharacters.slice(offset, offset + sliceSize);
      
          const byteNumbers = new Array(slice.length);
          for (let i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
          }
      
          const byteArray = new Uint8Array(byteNumbers);
          byteArrays.push(byteArray);
        }
      
        const blob = new Blob(byteArrays, {type: contentType});
        return blob;
      }
      const contentType = 'image/png';
      const b64Data ="";
      const blob = b64toBlob(b64Data, contentType);
      const blobUrl = URL.createObjectURL(blob);

     /*  const img = document.createElement('img');
      img.src = blobUrl;
      document.body.appendChild(img); */
 
    // this.image = this.sanitizer.bypassSecurityTrustUrl(blobUrl);
    },
    err => {
      console.log('err', err);
     // this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  newApplication() {
    this.spinnerService.show();
    this.adm.api_description(this.branchId).subscribe((data: any) => {
      var response = data._body;
      this.spinnerService.hide();
      this.obj = JSON.parse(response);
      this.resp = this.obj[0].TAB_NAME;
      this.description = this.obj[0].DESCRIPTION;
      this.image = this.obj[0].IMAGE_URL.trim();
      this.file = this.obj[0].FILE_URL.trim();
      console.log("image=="+this.image+"file==="+this.file);
      if(this.branchId === "177" || this.branchId === 177){
        this.image = "https://developer.icicibank.com/assets/images/BBPS.png";
      }
   //   this.image= "/u1/APIGateway/developerPortalDocsUpload/isan.jpg";
  // this.image=  "/u1/APIGateway/developerPortalDocsUpload/IFITechnew.png";
      let index = this.image.indexOf("https");
      if(index > -1){

        
      }else if(this.image && this.image !== "" && this.image !== " "){
           let json = {
              path:this.image
            }
            let that = this;
            let filename =  this.image.substring(this.image.lastIndexOf('/') + 1);
            this.dashboardService.downloadImage(json).subscribe((data: any) => {
              console.log(data);

              const b64toBlob = (b64Data, contentType='', sliceSize=512) => {
                const byteCharacters = atob(b64Data);
                const byteArrays = [];
              
                for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                  const slice = byteCharacters.slice(offset, offset + sliceSize);
              
                  const byteNumbers = new Array(slice.length);
                  for (let i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                  }
              
                  const byteArray = new Uint8Array(byteNumbers);
                  byteArrays.push(byteArray);
                }
              
                const blob = new Blob(byteArrays, {type: contentType});
                return blob;
              }
              const contentType = 'image/png';
              const b64Data =data._body;
              const blob = b64toBlob(b64Data, contentType);
              const blobUrl = URL.createObjectURL(blob);
              this.image = this.sanitizer.bypassSecurityTrustUrl(blobUrl);
               
            },
            err => {
              console.log('err', err);
            
            });
      }
    },
    err => {
      console.log('err', err);
     // this.router.navigate(['error']);
      this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
 
   /** get branch node details
   * @class BranchDetailsComponent
   * @method downloadFile
   */
  downloadFileOld() {
    //a
    let dwldLink = document.createElement("a");
    
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }

    if(this.faqEazypay){
      this.file = "https://developer.icicibank.com/assets/documents/Eazypay.zip";
    }
    if(this.branchId === "177" || this.branchId === 177 ){
      this.file = "https://developer.icicibank.com/assets/documents/BBPS.pdf";
    }
    dwldLink.setAttribute("href", this.file);
    //dwldLink.setAttribute("download", fileName + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  } 
  downloadFile() {

    if(this.faqEazypay){
      this.file = "https://developer.icicibank.com/assets/documents/Eazypay.zip";
    }
    if(this.branchId === "177" || this.branchId === 177 ){
      this.file = "https://developer.icicibank.com/assets/documents/BBPS.pdf";
    }
    let path = this.file;
    let filename =  path.substring(path.lastIndexOf('/') + 1);
    let index = path.indexOf("https");
    if(index > -1){
      this.adm.downloadFromURL(path).subscribe((data: any) => {
        console.log(data);
        let certificate = data._body;
        console.log(data._body);
        var blob = new Blob([certificate], {
          type: "text/pdf"
        });
        saveAs(blob,filename);
      },
      err => {
        console.log('err', err);
       
      });
    
    }else
    {
        let json = {
              path:path
            }

            this.dashboardService.getDocFileDownload(json).subscribe((data: any) => {
              const b64toBlob = (byteString) => {
      
                var ia = new Uint8Array(byteString.length);
                for (var i = 0; i < byteString.length; i++) {
                  ia[i] = byteString.charCodeAt(i);
                }
                return new Blob([ia], { type: "octet/stream" });
              }
              let b64data = data._body;
              const byteCharacters = atob(b64data);
              const blob = b64toBlob(byteCharacters);
              const blobUrl = URL.createObjectURL(blob);
              const a = document.createElement('a')
              a.href = blobUrl;
              a.download = filename;
              a.click();
             

            },
            err => {
              console.log('err', err);
            
            });
          
    }
  } 
  downloadfileURL(){
    if(this.faqEazypay){
      this.file = "https://developer.icicibank.com/assets/documents/Eazypay.zip";
    }
    if(this.branchId === "177" || this.branchId === 177 ){
      this.file = "https://developer.icicibank.com/assets/documents/BBPS.pdf";
    }
    let url = this.file
    var fileName = url.substring(url.lastIndexOf("/") + 1);
    this.adm.downloadFromURL(url).subscribe((data: any) => {
      console.log(data);
      let certificate = data._body;
      
      var blob = new Blob([certificate], {
        type: "text/plain"
      });
      saveAs(blob,fileName);
    },
    err => {
      console.log('err', err);
     
    });
  }

   /** get branch node details
   * @class BranchDetailsComponent
   * @method downloadFAQ
   */
  downloadFAQ() {
    
    let dwldLink = document.createElement("a");
    
    let isSafariBrowser =
      navigator.userAgent.indexOf("Safari") != -1 &&
      navigator.userAgent.indexOf("Chrome") == -1;
    if (isSafariBrowser) {
      dwldLink.setAttribute("target", "_blank");
    }
    dwldLink.setAttribute("href", "https://developer.icicibank.com/assets/documents/UPI Merchant Integrations FAQs - Consolidated.docx");
    //dwldLink.setAttribute("download", fileName + ".csv");
    dwldLink.style.visibility = "hidden";
    document.body.appendChild(dwldLink);
    dwldLink.click();
    document.body.removeChild(dwldLink);
  } 
  toastrmsg(type ,title) {
    var toast: Toast = {
      type: type,
      title:"",
      body:title,
      showCloseButton: true 
    }; 
    this.toasterService.pop(toast);
  }     
}
