import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { DashboardService } from 'src/app/services';

@Component({
  selector: 'app-db-transaction-dashboard',
  templateUrl: './db-transaction-dashboard.component.html',
  styleUrls: ['./db-transaction-dashboard.component.css']
})
export class DbTransactionDashboardComponent implements OnInit {
  ApiTransationData:[];
  constructor(
    private router: Router,
    private dashboardService: DashboardService,
    private HttpClient: HttpClient,
  ) { }

  ngOnInit() {
    var json="";
    this.dashboardService.getApiTransations().subscribe((data: any) => {
      console.log(data)
      this.ApiTransationData = JSON.parse(data._body);
      //  console.log(treeData );
     
    },
      err => {
        console.log('err', err);
        //this.router.navigate(['error']);
        //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      });
  }


}
