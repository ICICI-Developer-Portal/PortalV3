import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild, ElementRef, TemplateRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Toast, ToasterService } from 'angular2-toaster';
// import { DataTableResource } from 'angular7-data-table';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { BsModalRef, BsModalService } from 'ngx-bootstrap';
import { DashboardService, LoginService } from 'src/app/services';
import { Config } from '../config/config';
declare var $: any;

@Component({
  selector: 'app-api-upload',
  templateUrl: './api-upload.component.html',
  styleUrls: ['./api-upload.component.css']
})
export class ApiUploadComponent implements OnInit {
  apiUrl: string;
  userForm1: FormGroup;
  userForm2: FormGroup;
  userForm3: FormGroup;
  userForm4: FormGroup;
  userForm5: FormGroup;
  userForm6: FormGroup;

  addBranch: FormGroup;
  addRoot: FormGroup;
  domain: any = [];
  subDomain: any = {};
  rootSubDomain: any = [];
  API_LEVEL: any;
  level2_subdomain: any;
  api_parent: any;
  api_gparent: any="";
  API_ID: any ;
  API_REQ_ID:any;
  API_RESP_ID:any;
  API_SAMPLEPKT_ID:any;
  API_FILE_URL:any ="";
  yesNo = ["Yes", "No"];
  mOrO =["M","O"];
  selected;
  modalRef: BsModalRef;
  apiResponseParam = []; // used for storing 
  reqDetailsApi = [];
  countDetail = 0;
  countReqDetail = 0;
  details = '';
  TOTAL_TABLE_DATA:any = [];
  dType:any = ["OBJECT","VARCHAR2","VARCHAR1","NUMBER","DATE","VARCHAR1","NVARCHAR2","CHAR","DATE(YYYYMMDD)"];
  constructor(private router: Router,
    private dashboardService: DashboardService,
    private toasterService: ToasterService,
    private spinnerService: Ng4LoadingSpinnerService,
    private fb: FormBuilder,
    private modalService: BsModalService,
    private HttpClient: HttpClient,
    private config: Config,) {
    this.userForm2 = fb.group({
      details: fb.array([]),
    });
    this.apiUrl = config.apiUrl;
  }

  ngOnInit() {
    this.getMenuTree();
    this.getApiId();
    this.dbAdminAccess();
    this.userForm1 = new FormGroup({
      'apiDomain': new FormControl("", Validators.required),
      'apiSubdomain': new FormControl("", Validators.required),
      'apiID': new FormControl(""),
      'apiName': new FormControl("", Validators.required),
      "apiDesc": new FormControl("", Validators.required),
      'fileUpload': new FormControl("", Validators.required),//comment
      "SANDBOX_URL": new FormControl("", Validators.required),
      'Environment': new FormControl("", Validators.required),
      'Display': new FormControl("", Validators.required),
      'information': new FormControl("")

    });

    this.userForm2 = new FormGroup({
      "respID": new FormControl(""),
      "apiID": new FormControl("", Validators.required),
      "respName": new FormControl("", Validators.required),
      "respDesc": new FormControl("", Validators.required),
      "respType": new FormControl("", Validators.required),
      // "details":new FormControl(null, Validators.required),
      // 'Remarks': new FormControl(null, Validators.required),
    });

    this.userForm3 = new FormGroup({
      "reqId": new FormControl(""),
      "apiId": new FormControl("", Validators.required),
      "reqName": new FormControl("", Validators.required),
      "reqType": new FormControl("", Validators.required),
      "reqDesc": new FormControl("", Validators.required),
      "reqMandatory": new FormControl("", Validators.required)
    });

    this.userForm4 = new FormGroup({
      "packetId": new FormControl(""),
      "apiId": new FormControl("", Validators.required),
      "sampleRequest": new FormControl("", Validators.required),
      "type": new FormControl("", Validators.required),
    });

    this.userForm5 = new FormGroup({
      "apiId": new FormControl(""),
      "fieldName": new FormControl(null, Validators.required),
      "apiName": new FormControl(""),
      // 'Remarks': new FormControl(null, Validators.required),
    });
    this.userForm6 = new FormGroup({
      "API_ID": new FormControl(""),
      "API_NAME": new FormControl(null, Validators.required),
      "SANDBOX_URL": new FormControl(""),
      // 'Remarks': new FormControl(null, Validators.required),
    });
    this.addBranch = new FormGroup({
      'apiDomain': new FormControl("", Validators.required),
      'apiSubdomain': new FormControl("", Validators.required),
      'tab_name': new FormControl("", Validators.required),
      'child_count': new FormControl("", Validators.required),
      'apiDesc': new FormControl("", Validators.required),
      'imageUpload': new FormControl(""),//comment
      'docsUpload': new FormControl(""),//comment
      'Environment': new FormControl("", Validators.required),
      'Display': new FormControl("", Validators.required),//comment
      // 'Remarks': new FormControl(null, Validators.required),
    });
    this.addRoot = new FormGroup({
      "ID":  new FormControl(""),
      "TAB_NAME":  new FormControl("", Validators.required),
      "CHILD_COUNT": new FormControl("", Validators.required), //level 1
      "DESCRIPTION":  new FormControl("", Validators.required), //level 1
      "IMAGE_URL": new FormControl(""), //level 1
      "FILE_URL": new FormControl(""), //level 1
      "ENVIRONMENT": new FormControl("", Validators.required), //level 1
      "DISPLAY":  new FormControl("", Validators.required),//level 1
    });
  }

  dbAdminAccess(){
//
    let json = {
      username:localStorage.getItem("username")
    };
    this.spinnerService.show();
    this.dashboardService.hasDBAdminAccess(json).subscribe((data: any) => {
      let _data = JSON.parse(data._body);
      console.log(" response"+ _data);
      this.spinnerService.hide();
      
    },
    err => {
      this.spinnerService.hide();
      console.log('err', err);
      //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);

  }
  /** get menu tree data
     * @class SidebarComponent
     * @method getMenuTree
     */
  getMenuTree() {
    this.dashboardService.getMenuTreeData().subscribe((data: any) => {
      let treeData = JSON.parse(data._body);
      //  console.log(treeData );
      this.spinnerService.show();
      for (let i = 0; i < treeData.length; i++) {
        if (treeData[i].CHILD_COUNT !== "0" && treeData[i].TYPE == "root") {
          this.domain.push(treeData[i].TAB_NAME);
        } else {
          console.log("else treeData" + treeData[i].TAB_NAME);
        }

        if (treeData[i].CHILD_COUNT !== "0") {

          this.createUnorderedList(
            treeData[i].TAB_NAME,
            "",
            "",
            treeData[i].children,
            treeData[i].TYPE,
            treeData[i].LEVEL
          );
        }

      }
      this.spinnerService.hide();
      console.log(this.subDomain);
    },
      err => {
        console.log('err', err);
        //this.router.navigate(['error']);
        //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      });
  }

  createUnorderedList(domain, subDomain, subDomain2, childrenArr, nodeType, level) {
    if (level === "1") {
      // this.l1.push(domain);
      this.subDomain[domain] = [];
    }
    if (level === "2") {
      // this.l2.push(domain); 
      if (domain in this.subDomain) {
        this.subDomain[domain].push(subDomain);
      }
    }
    if (level >= "3") {
      // this.l3.push(domain);
      if (domain in this.subDomain) {
        this.subDomain[domain].push(subDomain + "/" + subDomain2);
      }
    }


    for (var i = 0; i < childrenArr.length; i++) {
      if (childrenArr[i].CHILD_COUNT !== "0" && childrenArr[i].LEVEL === "2") {
        this.createUnorderedList(
          domain,
          childrenArr[i].TAB_NAME,
          '',
          childrenArr[i].children,
          childrenArr[i].TYPE,
          childrenArr[i].LEVEL
        );
      } else if (childrenArr[i].CHILD_COUNT !== "0" && childrenArr[i].LEVEL === "3") {
        this.createUnorderedList(
          domain,
          subDomain,
          childrenArr[i].TAB_NAME,
          childrenArr[i].children,
          childrenArr[i].TYPE,
          childrenArr[i].LEVEL
        );
      }
      else if (childrenArr[i].CHILD_COUNT !== "0" && childrenArr[i].LEVEL === "4") {
        this.createUnorderedList(
          domain,
          subDomain,
          subDomain2 + "/" + childrenArr[i].TAB_NAME,
          childrenArr[i].children,
          childrenArr[i].TYPE,
          childrenArr[i].LEVEL
        );
      }
      /*  console.log(this.l1);
       console.log(this.l2);
       console.log(this.l3); */
    }
  }
  onChangeRoot(event) {
    let val = event.target.value;
    console.log(val);
    this.rootSubDomain = this.subDomain[val];

  }
  apiDetailsSubmission($even) {
    console.log(this.userForm1.value);

    let t1 = {
      "tableName": "API_DETAIL",
      "records": [{
        "API_DOMAIN": this.userForm1.value.apiDomain, //level 1
        "API_SUB_DOMAIN": this.level2_subdomain, //level2 subdomain
        "API_ID": this.API_ID,// need id from srvc
        "API_NAME": this.userForm1.value.apiName,
        "API_DESC": this.userForm1.value.apiDesc,
        "SANDBOX_URL": this.userForm1.value.SANDBOX_URL,
        "API_LEVEL": "1", //1
        "ENVIRONMENT": this.userForm1.value.Environment, //drpdwn
        "ERRORCODE": "",// need to clearificatn from db..
        "INFORMATION": this.userForm1.value.information// no th required
      }]
    };
    
    /*=========== Api docs upload  */
    var formData = new FormData();
    let b: any = (<HTMLInputElement>document.getElementById("fileUpload")).files;
    for (let k = 0; k < b.length; k++) {
      formData.append("file1", b[k]);
    }
    this.HttpClient.post<any>(
      this.apiUrl+"getFileUpload",
      formData

    ).subscribe(
      res => {
        console.log(res);
        if(res && res.status){
          this.API_FILE_URL = res.data;
          console.log(res.message);
          // create data
          let t2 = {
            "tableName": "PORTAL_MENU_TREE",
            "records": [{
              "ID": "",// get last from getMenuTree from service call
              "TAB_NAME": this.userForm1.value.apiName,//API name
              "TYPE": "api",
              "PARENT_ID": "", //call getMenu tree to fetch parent_ID on the basis of parent name
              "PARENT": this.api_parent, //immediate parent
              "G_PARENT":this.api_gparent,
              "CHILD_COUNT": "0",
              "POSITION": "",  // get from service call // 1- let count = (select * from getMenuTree where PARENT_ID = PARENT_ID(that u get above ) ) + 1;
              "API_ID": this.API_ID,// kept 1 for all root and branch
              "STATUS": "active",
              "DESCRIPTION": this.userForm1.value.apiDesc,
              "API_LEVEL": this.API_LEVEL,
              "IMAGE_URL": "",
              "FILE_URL": this.API_FILE_URL,  // file need to be uploaded and path saved in DB
              "ENVIRONMENT": this.userForm1.value.Environment,
              "DISPLAY": this.userForm1.value.Display
      
            }]
          };
           this.TOTAL_TABLE_DATA[0] = t1;
           this.TOTAL_TABLE_DATA[1] = t2;
           console.log(this.TOTAL_TABLE_DATA);
        }else{
          alert(res.message);
        }
      },err => {
        console.log('err', err);
      });
/* =============================================== */
 
  }
  onSubdomainChange(subDomain) {
    // Set API_LEVEL and also get paret id from portal menu tree
    if (subDomain && subDomain !== undefined && subDomain !== "") {
      let _sobdomain = subDomain.split("/");
      let count = _sobdomain.length;
      console.log("API level==" + parseInt(count + 2));
      console.log("API immediate parent==" + _sobdomain[count - 1]);
      this.API_LEVEL = parseInt(count + 2);
      this.level2_subdomain = _sobdomain[0];
      this.api_parent = _sobdomain[count - 1];
      this.api_gparent = _sobdomain[count - 2];
      console.log("this.api_gparent=="+ this.api_gparent);
      if(this.api_gparent == undefined || this.api_gparent == ""){
        this.api_gparent = this.userForm1.value.apiDomain;
      }
      console.log("this.api_gparent 2=="+ this.api_gparent);
      // call getMenu tree to fetch parent_ID on the basis of parent
    }
  }

  addNewDetails() {
    const add = this.userForm2.get('details') as FormArray;
    add.push(
      this.fb.group({
        respName: [],
        respDesc: [],
        respType: []

      })
    );
  }

  addDetails() {
    if (this.userForm2.valid) {
      // this.apiResponseParam.push( this.userForm2.value);
      this.userForm2.controls["apiID"].setValue(this.API_ID); // API ID obtained in first tab
      let obj = {
        "RESP_ID":this.userForm2.get("respID").value, // get last id from API_RES_PARAMETERR table and keep incrementing
        "API_ID":this.userForm2.get("apiID").value,
        "RESP_NAME":this.userForm2.get("respName").value,
        "RESP_DESC":this.userForm2.get("respDesc").value,
        "RESP_TYPE":this.userForm2.get("respType").value
    }
      this.apiResponseParam.push(obj);
      this.countDetail = this.apiResponseParam.length;
      console.log(this.apiResponseParam);
      this.userForm2.reset();
      this.userForm2.controls["apiID"].setValue(this.API_ID);
      this.API_RESP_ID =  this.API_RESP_ID + 1;
      this.userForm2.controls["respID"].setValue(this.API_RESP_ID);
    } else {
      alert("Please insert required data !!!");
    }
  }



  addReqDetails() {
    if (this.userForm3.valid) {
      this.userForm3.controls["apiId"].setValue(this.API_ID); // API ID obtained in first tab
      let obj = {
        "REQ_ID": this.userForm3.get("reqId").value,//get last  id API_REQ_PARAMETER table 
        "API_ID":this.userForm3.get("apiId").value,
        "REQ_NAME": this.userForm3.get("reqName").value,
        "REQ_TYPE": this.userForm3.get("reqType").value,
        "REQ_DESC": this.userForm3.get("reqDesc").value,
        "REQ_MAND": this.userForm3.get("reqMandatory").value // drpdwn

        };
      this.reqDetailsApi.push(obj);
      this.countDetail = this.reqDetailsApi.length;
      console.log(this.reqDetailsApi);
      this.userForm3.reset();
      this.userForm3.controls["apiId"].setValue(this.API_ID);
      this.API_REQ_ID =  this.API_REQ_ID + 1;
      this.userForm3.controls["reqId"].setValue(this.API_REQ_ID);
    } else {
      alert("Please insert data in required field!!!");
    }
  }

  // this mathed is get the index of the element of array and splice that form the array as compare the index and splice
  removeDetails(index) {
    this.apiResponseParam.splice(index, 1);
    this.countDetail = this.apiResponseParam.length;
  }

  removeReqDetails(index) {
    this.reqDetailsApi.splice(index, 1);
    this.countReqDetail = this.reqDetailsApi.length;
  }
// navogate to second tab
  nextTab2($e) {
    $e.preventDefault();
    this.apiDetailsSubmission($e);
    $('#nav-tab a[href="#nav-profile"]').tab('show');
  }

  // Navigate to thirst tab
  nextTab3($e) {
    $e.preventDefault();
    //insert table data 
    let t3 =    {
      "tableName":"API_RES_PARAMETER",
      "records": this.apiResponseParam
    }
    this.TOTAL_TABLE_DATA[2] = t3;
    console.log("with t3" + this.TOTAL_TABLE_DATA);
   
    $('#nav-tab a[href="#tab3"]').tab('show');
  }
  //============ navigate to 4th tab
  nextTab4($e) {
    $e.preventDefault();
    let t4 =    {
      "tableName":"API_REQ_PARAMETER",
      "records": this.reqDetailsApi
    }
    this.TOTAL_TABLE_DATA[3] = t4;
    console.log("with t4" + this.TOTAL_TABLE_DATA);
    $('#nav-tab a[href="#nav-tab4"]').tab('show');
  }
  //===============navigate to 5th tab

  nextTab5($e) {
    $e.preventDefault();
    let t5 =    {
      "tableName":"API_SAMPLE_PACKET",
      "records": [{
        "PACKET_ID":this.userForm4.get("packetId").value, // from service call
        "API_ID":this.API_ID, // from tab1
        "SAMPLE_REQUEST":this.userForm4.get("sampleRequest").value,//
        "REQ_TYPE":this.userForm4.get("type").value
        
    
    }]
    };
    this.TOTAL_TABLE_DATA[4] = t5;
    console.log("with t5" + this.TOTAL_TABLE_DATA);
    this.userForm5.controls["apiName"].setValue(this.userForm1.get("apiName").value);
    this.userForm6.controls["API_NAME"].setValue(this.userForm1.get("apiName").value);
    $('#nav-tab a[href="#nav-tab6"]').tab('show');
  }

  nextTab6($e) {

    $e.preventDefault();

    let t7 = {

      "tableName": "API_SAMPLE_RESP_TBL",

      "records": [

        {

          "API_ID": this.userForm6.get("API_ID").value,

          "API_NAME": this.userForm6.get("API_NAME").value,
          "SANDBOX_URL": "",

          "SAMPLE_RESP_PACKET": this.userForm6.get("SANDBOX_URL").value

        }

      ]

    };

    this.TOTAL_TABLE_DATA[6] = t7;

    console.log("with t7" + this.TOTAL_TABLE_DATA);

   // this.userForm6.controls["API_NAME"].setValue(this.userForm1.get("apiName").value);

    $('#nav-tab a[href="#nav-tab5"]').tab('show');

  }

  OpenModel1(viewDetail: TemplateRef<any>) {
    this.modalRef = this.modalService.show(viewDetail, { backdrop: "static", class: 'modal-lg' });
  }
  
  SubmitAll(){
    $("#approveSubmitButton").prop("disabled", true) ;
    setTimeout(() => {
      $("#approveSubmitButton").prop("disabled", false) ;
       }, 10000);
    
    let t6 =    {
      "tableName":"ADD_PARAMETERS_TABLE",
      "records":[{
        "API_ID":this.API_ID,
        "FIELD_NAMES":this.userForm5.get("fieldName").value,
        "API_NAME":this.userForm1.get("apiName").value
    
    }]
    };
    this.TOTAL_TABLE_DATA[5] = t6;
    console.log("with t6" + this.TOTAL_TABLE_DATA);

    console.log(this.userForm1.value,this.userForm2.value,this.userForm3.value
      ,this.userForm4.value,this.userForm5.value);

    if(this.userForm1.valid && this.userForm4.valid && this.userForm5.valid){

        let json = JSON.stringify(this.TOTAL_TABLE_DATA);
        this.spinnerService.show();
        this.dashboardService.insertApiData(json).subscribe((data: any) => {
          let _data = JSON.parse(data._body);
          console.log("Insertion response"+ _data);
          this.spinnerService.hide();
          if(_data.success){
            alert(_data.message);
              
          }else{
            alert(_data.message);
          }
        },
        err => {
          this.spinnerService.hide();
          console.log('err', err);
          //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
        },);

      }

  }
  next(){
    
  }
  getApiId(){
    let json = {
      table: "API_DETAIL"
    }
    this.spinnerService.show();
    this.dashboardService.getLastTabId(json).subscribe((data: any) => {
      let _data = JSON.parse(data._body);
      console.log(_data);
      this.spinnerService.hide();
      if(_data.status){
          this.API_ID = parseInt(_data.message) + 1;
          this.userForm1.controls["apiID"].setValue(this.API_ID);
          this.userForm2.controls["apiID"].setValue(this.API_ID);
          this.userForm3.controls["apiId"].setValue(this.API_ID);
          this.userForm4.controls["apiId"].setValue(this.API_ID);
          this.userForm5.controls["apiId"].setValue(this.API_ID);
          this.userForm6.controls["API_ID"].setValue(this.API_ID);
          this.getResponseId();
          this.getRequestId();
          this.getPacketId();
          
      }else{
          this.API_ID = "";
          console
      }
    },
    err => {
      this.spinnerService.hide();
      console.log('err', err);
      //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  getRequestId(){
    let json = {
      table: "API_REQ_PARAMETER"
    }
    this.dashboardService.getLastTabId(json).subscribe((data: any) => {
      let _data = JSON.parse(data._body);
      console.log(_data);
      if(_data.status){
          this.API_REQ_ID = parseInt(_data.message) + 1;
          this.userForm3.controls["reqId"].setValue( this.API_REQ_ID);
          
      }else{
          this.API_REQ_ID = "";
      }
    },
    err => {
      console.log('err', err);
      //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  
 
  getResponseId(){
    let json = {
      table: "API_RES_PARAMETER"
    }
    this.dashboardService.getLastTabId(json).subscribe((data: any) => {
      let _data = JSON.parse(data._body);
      console.log(_data);
      if(_data.status){
          this.API_RESP_ID = parseInt(_data.message) + 1;
          this.userForm2.controls["respID"].setValue(this.API_RESP_ID);
          
      }else{
          this.API_RESP_ID = "";
         
      }
    },
    err => {
      console.log('err', err);
      //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  getPacketId(){
    let json = {
      table: "API_SAMPLE_PACKET"
    }
    this.dashboardService.getLastTabId(json).subscribe((data: any) => {
      let _data = JSON.parse(data._body);
      console.log(_data);
      if(_data.status){
          this.API_SAMPLEPKT_ID = parseInt(_data.message) + 1;
          this.userForm4.controls["packetId"].setValue(this.API_SAMPLEPKT_ID);
      }else{
          this.API_SAMPLEPKT_ID = "";
         
      }
    },
    err => {
      console.log('err', err);
      //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
    },);
  }
  OpenModel(addBranchForm: any,addRootForm: any) {

    this.modalRef = this.modalService.show(addBranchForm,addRootForm);
  }


  //================Branch Data ===================
  branch_parent:any = "";
  branch_gparent:any = "";
  BRANCH_IMAGE_URL:any = "";
  BRANCH_FILE_URL:any  = "";
  BRANCH_LEVEL:any  = "";
  rootSubDomain_branch:any=[];

  onChangeRoot_branch(event) {
    let val = event.target.value;
    console.log(val);
    this.rootSubDomain_branch = this.subDomain[val];

  }
  
  onBranchSubdomainChange(subDomain){
    if (subDomain && subDomain !== undefined && subDomain !== "") {
      if(subDomain == "newSubdomain"){
          this.branch_parent = this.addBranch.value.apiDomain;
          this.branch_gparent = "";
          this.BRANCH_LEVEL = 2;
      }else{
        let _sobdomain = subDomain.split("/");
        let count = _sobdomain.length;
        this.BRANCH_LEVEL = parseInt(count + 2);
        this.branch_parent = _sobdomain[count - 1];
        this.branch_gparent=_sobdomain[count - 2];
        // call getMenu tree to fetch parent_ID on the basis of parent
      }
      if(this.branch_gparent == undefined ){
        this.branch_gparent = "";
      }
     
      console.log("this.BRANCH_LEVEL" + this.BRANCH_LEVEL);
      console.log("this.branch_parent" + this.branch_parent);
    }
  }
  branchDetailsSubmission() {
    
    if(this.addBranch.valid){
      console.log("valid");
      let branchData = [{
        "tableName": "PORTAL_MENU_TREE",
        "records": [{
          "ID": "",// get last from getMenuTree from service call
          "TAB_NAME": this.addBranch.value.tab_name,//API name
          "TYPE": "branch",
          "PARENT_ID": "", //call getMenu tree to fetch parent_ID on the basis of parent name
          "PARENT": this.branch_parent, //immediate parent
          "G_PARENT": this.branch_gparent, 
          "CHILD_COUNT": this.addBranch.value.child_count,
          "POSITION": "",  // get from service call // 1- let count = (select * from getMenuTree where PARENT_ID = PARENT_ID(that u get above ) ) + 1;
          "API_ID": "1",// kept 1 for all root and branch
          "STATUS": "active",
          "DESCRIPTION":  this.addBranch.value.apiDesc,
          "API_LEVEL": this.BRANCH_LEVEL,
          "IMAGE_URL": this.BRANCH_IMAGE_URL, 
          "FILE_URL": this.BRANCH_FILE_URL,  // file need to be uploaded and path saved in DB
          "ENVIRONMENT": this.addBranch.value.Environment,
          "DISPLAY": this.addBranch.value.Display
  
        }]
      }];
      console.log(branchData);
      let json = JSON.stringify(branchData);
      console.log(json);
      this.spinnerService.show();
     this.dashboardService.insertBranchData(json).subscribe((data: any) => {
        let _data = JSON.parse(data._body);
        console.log("Insertion response"+ _data);
        this.spinnerService.hide();
        if(_data.success){
          alert(_data.message);
            
        }else{
          alert(_data.message);
        }
      },
      err => {
        this.spinnerService.hide();
        console.log('err', err);
        //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      },); 
    }
  }
  uploadFile(dType){
     /*=========== Api docs upload  */
     var formData = new FormData();
     let b: any ;
     if(dType == "IMAGE"){
      b = (<HTMLInputElement>document.getElementById("imageUpload")).files;
     }else if(dType == "DOC"){
      b = (<HTMLInputElement>document.getElementById("docsUpload")).files;
     }
     if(b.length <= 0){
       alert("Please select the file.");
       return false;
     }
     for (let k = 0; k < b.length; k++) {
       formData.append("file1", b[k]);
     }
     this.spinnerService.show();
     this.HttpClient.post<any>(
       this.apiUrl+"getFileUpload",
       formData
 
     ).subscribe(
       res => {
         console.log(res);
         this.spinnerService.hide();
         if(res && res.status){
          if(dType == "IMAGE"){
            this.BRANCH_IMAGE_URL = res.data;
            console.log(" this.BRANCH_IMAGE_URL==="+ this.BRANCH_IMAGE_URL);
            alert(res.message);
           }else if(dType == "DOC"){
            this.BRANCH_FILE_URL = res.data;
            alert(res.message);
           }
           
          }else{
            alert(res.message);
          }
        },err => {
          this.spinnerService.hide();
          console.log('err', err);
        });

  }
   //================Root Data ===================
   
   ROOT_IMAGE_URL:any = "";
   ROOT_FILE_URL:any  = "";
  uploadRootFile(dType){
    /*=========== Api docs upload  */
    var formData = new FormData();
    let b: any ;
    if(dType == "IMAGE"){
     b = (<HTMLInputElement>document.getElementById("IMAGE_URL")).files;
    }else if(dType == "DOC"){
     b = (<HTMLInputElement>document.getElementById("FILE_URL")).files;
    }
    console.log(b);
    console.log(b.length);
    if(b.length <= 0){
      alert("Please select the file.");
      return false;
    }
    for (let k = 0; k < b.length; k++) {
      formData.append("file1", b[k]);
    }
    this.spinnerService.show();
    this.HttpClient.post<any>(
      this.apiUrl+"getFileUpload",
      formData

    ).subscribe(
      res => {
        console.log(res);
        this.spinnerService.hide();
        if(res && res.status){
         if(dType == "IMAGE"){
           this.ROOT_IMAGE_URL = res.data;
           alert(res.message);
          }else if(dType == "DOC"){
           this.ROOT_FILE_URL = res.data;
           alert(res.message);
          }
          
         }else{
           alert(res.message);
         }
       },err => {
         this.spinnerService.hide();
         console.log('err', err);
       });

 }
 
  rootDetailsSubmission(){
    let t1 = {
      "tableName": "PORTAL_MENU_TREE",
      "records": [{
        "ID": "", //calculated from backend 
        "TAB_NAME": this.addRoot.value.TAB_NAME, //level 1
        "TYPE": "root", //level 1
        "PARENT_ID" :0,
        "PARENT":"none",
        "POSITION":"",//calculated from backend
        "API_ID":"1",//
        "STATUS":"active",
        "API_LEVEL":"1",
        "CHILD_COUNT": this.addRoot.value.CHILD_COUNT, //level 1
        "DESCRIPTION": this.addRoot.value.DESCRIPTION, //level 1
        "IMAGE_URL": this.ROOT_IMAGE_URL, //level 1
        "FILE_URL": this.ROOT_FILE_URL, //level 1
        "ENVIRONMENT": this.addRoot.value.ENVIRONMENT, //level 1
        "DISPLAY": this.addRoot.value.DISPLAY //level 1
      
      }]

    };
    console.log(t1);
    if(this.addRoot.valid){
      let json = JSON.stringify(t1);
      this.spinnerService.show();
      this.dashboardService.insertRootData(json).subscribe((data: any) => {
        let _data = JSON.parse(data._body);
        console.log("Insertion response"+ _data);
        this.spinnerService.hide();
        if(_data.success){
          alert(_data.message);
            
        }else{
          alert(_data.message);
        }
      },
      err => {
        this.spinnerService.hide();
        console.log('err', err);
        //this.toastrmsg('error',"Something went wrong. Please try again in some time.");
      },);
    }
    
      

  }
}

