import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ApiDetailDashboardComponent } from './api-detail-dashboard.component';

describe('ApiDetailDashboardComponent', () => {
  let component: ApiDetailDashboardComponent;
  let fixture: ComponentFixture<ApiDetailDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ApiDetailDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ApiDetailDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
